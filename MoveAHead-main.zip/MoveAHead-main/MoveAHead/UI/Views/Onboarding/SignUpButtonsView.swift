//
//  SignUpButtonsView.swift
//  MoveAHead
//
//  Created by Felix Parey on 06/06/24.
//

import SwiftUI

struct SignUpButtonsView: View {
    
    @Binding var firstTimeAppLaunched: Bool
    
    
    var body: some View {
        VStack{
            AppleButton(firstTimeAppLaunched: $firstTimeAppLaunched)
            // GoogleButton(firstTimeAppLaunched: $firstTimeAppLaunched)
            // MailButton(firstTimeAppLaunched: $firstTimeAppLaunched)
        }
       
    }
}

#Preview{
    SignUpButtonsView(firstTimeAppLaunched: .constant(true))
}
