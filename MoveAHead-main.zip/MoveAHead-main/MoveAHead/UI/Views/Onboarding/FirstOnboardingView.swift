//
//  FirstOnboardingView.swift
//  MoveAHead
//
//  Created by Felix Parey on 06/06/24.
//

import SwiftUI

struct FirstOnboardingView: View {
    
    @Environment(ThemeManager.self) private var themeManager
    @State var viewModel: OnboardingView.ViewModel
    var body: some View {

        Spacer()
        VStack(alignment: .leading, spacing: 30){
            ForEach(OnboardingView.ViewModel.onboardingContent){ content in
                HStack(spacing: 20){
                    Image(systemName: content.iconName)
                        .font(.largeTitle)
                        .foregroundStyle(.accent)
                        .frame(width: 45)
                    VStack(alignment: .leading){
                        Text(content.heading)
                            .foregroundStyle(themeManager.selectedTheme.bodyTextColor)
                            .font(.headline)
                            .fontWeight(.bold)
                        Text(content.text)
                            .font(.body)
                            .foregroundStyle(.primary.opacity(0.8))
                    }
                }
            }
        }
        .padding()
        
        Spacer()
        Spacer()
        Spacer()
        
        VStack{
            Button {
                viewModel.onboardingState = .SingIn
            } label: {
                Text("Continue")
                    .font(.title3)
                    .fontWeight(.semibold)
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 55)
                    .background(.accent, in: RoundedRectangle(cornerRadius: 15))
                    .padding(.horizontal)
            }
        }
    }
}
