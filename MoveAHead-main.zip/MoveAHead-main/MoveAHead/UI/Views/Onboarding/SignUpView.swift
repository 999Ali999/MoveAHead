//
//  SignUpView.swift
//  MoveAHead
//
//  Created by Felix Parey on 06/06/24.
//

import SwiftUI

struct SignUpScreen: View {
    
    @Environment(ThemeManager.self) private var themeManager
    @Binding var firstTimeAppLaunched: Bool
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        
        Spacer()
        
        Image(.lyricaLogo)
            .resizable()
            .scaledToFit()
            .containerRelativeFrame(.vertical) { size, _ in
                size * 0.15
            }
        
        VStack(alignment: .leading, spacing: 10) {
            
            Text("Create an account to:")
                .font(.title2)
                .fontWeight(.bold)
            
            ForEach(OnboardingView.ViewModel.accountBenefits, id: \.self){ benefit in
                HStack(spacing: 5){
                    Image(systemName: "checkmark")
                        .foregroundStyle(.accent)
                    Text(benefit)
                }
                .font(.headline)
            }
        }
        .padding(.top, 10)
        
        Spacer()
        
        Button {
            firstTimeAppLaunched = false
            dismiss()
        } label: {
            Text("Start to make a songs!")
                .font(.title3)
                .fontWeight(.semibold)
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .frame(height: 55)
                .background(.accent, in: RoundedRectangle(cornerRadius: 15))
                .padding(.horizontal)
        }
        
        SignUpButtonsView(firstTimeAppLaunched: $firstTimeAppLaunched)
    }
}

#Preview{
    SignUpScreen(firstTimeAppLaunched: .constant(true))
        .environment(ThemeManager.shared)
}
