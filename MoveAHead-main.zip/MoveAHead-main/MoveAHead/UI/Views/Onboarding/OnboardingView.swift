//
//  OnboardingView.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 13/05/24.
//

import SwiftUI
import _AuthenticationServices_SwiftUI

struct OnboardingView: View {
    
    @Environment(ThemeManager.self) private var themeManager
    @State var viewModel: ViewModel
    @Binding var firstTimeAppLaunched: Bool
    
    var body: some View {
        ZStack {
            themeManager.selectedTheme.bodyBackgroundColor
                .ignoresSafeArea()
            
            VStack {
                OnboardingTitle(viewModel: viewModel)
                switch viewModel.onboardingState{
                case .Info: FirstOnboardingView(viewModel: viewModel)
                case .SingIn: SignUpScreen(firstTimeAppLaunched: $firstTimeAppLaunched)
                }
            }
        }
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                AccountSkipButton(viewModel: viewModel, firstTimeAppLaunched: $firstTimeAppLaunched)
            }
        }
    }
}

#Preview {
    OnboardingView(viewModel: .init(onboardingState: .Info), firstTimeAppLaunched: .constant(true))
        .environment(ThemeManager.shared)
}
