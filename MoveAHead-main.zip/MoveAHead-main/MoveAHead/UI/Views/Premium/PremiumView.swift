//
//  PremiumView.swift
//  MoveAHead
//
//  Created by Felix Parey on 21/06/24.
//

import SwiftUI



struct PremiumView: View {
    
    @State var viewModel: PremiumViewModel = .init()
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        ZStack{
            BodyBackgroundView()
            VStack{
                Spacer()
                Image(.lyricaPremiumLogo)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 150, height: 150)
                    Spacer()
                switch viewModel.premiumScreenType {
                case .Info:
                    PremiumInformationView(viewModel: viewModel)
                case .Purchase:
                    PremiumPurchaseView(viewModel: viewModel)
                }
                Spacer()
                PremiumProgressButton(viewModel: viewModel)
                    .onChange(of: viewModel.premiumScreenType) { oldValue, newValue in
                        print(newValue)
                    }
            }
        }
        .overlay(alignment: .top) {
            HStack{
                if viewModel.premiumScreenType == .Purchase {
                    BackButton {
                        viewModel.premiumScreenType = .Info
                    }
                }
                Spacer()
                CloseButton {
                    dismiss()
                }
            }
            .padding(10)
        }
        .onDisappear {
            viewModel.premiumScreenType = .Info
            viewModel.selectedSubscriptionType = .Annual
        }
    }
}

#Preview {
    PremiumView()
}
