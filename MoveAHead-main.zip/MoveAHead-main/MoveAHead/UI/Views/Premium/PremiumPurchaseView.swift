//
//  PremiumPurchaseView.swift
//  MoveAHead
//
//  Created by Felix Parey on 21/06/24.
//

import SwiftUI

struct PremiumPurchaseView: View {
    
    @State var viewModel: PremiumViewModel
    @State private var selected: Bool = false
    @Environment(ThemeManager.self) private var themeManager
    
    var body: some View {
       
        VStack(alignment: .leading){
                Text("Select the plan that suits you most")
                    .font(.headline)
                    .bold()
                    .padding(.horizontal)
                    .foregroundStyle(themeManager.selectedTheme.bodyTextColor)
                ForEach(viewModel.subscriptionOptionDetails){ details in
                    SubscriptionOptionButton(viewModel: viewModel, subscriptionType: details.subscriptionType, title: details.title, monthlyPrice: details.monthlyPrice, isRecommended: details.isRecommended)
                }
            }
    }
}

#Preview {
    PremiumPurchaseView(viewModel: .init())
        .environment(ThemeManager.shared)
}
