//
//  PremiumInformationView.swift
//  MoveAHead
//
//  Created by Felix Parey on 21/06/24.
//

import SwiftUI


struct PremiumInformationView: View {
    
    @State var viewModel: PremiumViewModel
    @Environment(ThemeManager.self) private var themeManager
    
    var body: some View {
            
        VStack(alignment: .leading){
            Text("Features included in Lyrica Premium:")
                .font(.headline)
                .bold()
                .padding(.horizontal)
                .foregroundStyle(themeManager.selectedTheme.bodyTextColor)
                ForEach(viewModel.premiumInfos){ info in
                    PremiumBenefitItem(iconName: info.iconName, title: info.title, description: info.description)
                }
            }
    }
}

#Preview {
    PremiumInformationView(viewModel: .init())
        .environment(ThemeManager.shared)
}
