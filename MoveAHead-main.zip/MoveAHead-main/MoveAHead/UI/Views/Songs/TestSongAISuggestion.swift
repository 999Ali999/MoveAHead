//
//  TestSongAISuggestion.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 17/05/24.
//

import SwiftUI

struct TestSongAISuggestion: View {
    @State var viewModel = EditSongView.ViewModel(song: Song(id: UUID().uuidString, createdOn: Date.now, name: "Song Name", songFolderId: UUID().uuidString))
    
    var body: some View {
        EmptyView()
        
    }
}

#Preview {
    TestSongAISuggestion()
}
