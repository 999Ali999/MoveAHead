//
//  SongListView.swift
//  MoveAHead
//
//  Created by Felix Parey on 18/05/24.
//

import SwiftUI

struct SongsView: View {
    @EnvironmentObject var navigationModel: NavigationModel
    @Environment(ThemeManager.self) private var themeManager
    @StateObject var viewModel: ViewModel
    
    @State private var isShowFilters = false
    
    init(songFolder: SongFolder) {
        self._viewModel = StateObject(wrappedValue: ViewModel(songFolder: songFolder))
    }
    
    var body: some View {
        ZStack {
            themeManager.selectedTheme.bodyBackgroundColor
                .ignoresSafeArea()
            ScrollView {
                if isShowFilters {
                    TagsFilter(tags: viewModel.tags, selectedTags: $viewModel.selectedTags)
                        .padding(.horizontal)
                }
                
                ForEach(viewModel.songs) { songFolderItem in
                    Button {
                        navigationModel.path.append(.songEdit(songFolderId: viewModel.songFolder.id, songFolderItem: songFolderItem))
                    } label: {
                        DeleteGestureViewSong(onDelete: {
                            viewModel.removeSong(songId: songFolderItem.id)
                        }) {
                            SongListItem(id: songFolderItem.id, name: songFolderItem.name, description: songFolderItem.description, createdOn: songFolderItem.createdOn, totalLines: songFolderItem.totalLines)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
            .searchable(text: $viewModel.searchText)
            .scrollIndicators(.hidden)
            .listStyle(.plain)
            .toolbar {
                ToolbarItem {
                    Button {
                        withAnimation {
                            isShowFilters.toggle()
                            viewModel.selectedTags.removeAll()
                        }
                    } label: {
                        Label("Show filter", systemImage: "line.3.horizontal.decrease.circle")
                    }
                }
                ToolbarItemGroup(placement: .bottomBar) {
                    Spacer()
                    Button {
                        let emptySongFolderItem = SongFolderItem()
                        navigationModel.path.append(.songEdit(songFolderId: viewModel.songFolder.id, songFolderItem: emptySongFolderItem))
                    } label: {
                        Label("Add Song", systemImage: "square.and.pencil")
                    }
                }
            }
        }
        .navigationTitle(viewModel.songFolder.name)
    }
}
