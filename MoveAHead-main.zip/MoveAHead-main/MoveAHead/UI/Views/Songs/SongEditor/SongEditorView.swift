//
//  SwiftUIView.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 07/06/24.
//

import SwiftUI

struct SongEditorView: View {
    @Environment(ThemeManager.self) private var themeManager
    @StateObject var songEditorViewModel: SongEditorViewModel
    
    @FocusState private var focused: Bool
    @State private var scrollViewOffset: CGFloat = 0
    
    init(songFolderId: String, songFolderItem: SongFolderItem) {
        self._songEditorViewModel = StateObject(wrappedValue: SongEditorViewModel(songFolderId: songFolderId, songFolderItem: songFolderItem))
    }
    
    var body: some View {
        ZStack {
            themeManager.selectedTheme.bodyBackgroundColor
                .ignoresSafeArea()
            ScrollView {
                TextField("Name", text: $songEditorViewModel.name)
                    .largeTextField()
                    .padding(.vertical, 0)
                    .focused($focused)
                    .disabled(songEditorViewModel.editMode != .Edit)
                    .onChange(of: focused) {
                        if focused {
                            songEditorViewModel.clearActiveSection()
                        }
                    }
                    .onSubmit {
                        if let section = songEditorViewModel.sections.first {
                            songEditorViewModel
                                .setActiveSection(to: section.id)
                        }
                    }
                
                SongEditorSectionList(songEditorViewModel: songEditorViewModel)
            }
            .padding(.bottom, scrollViewOffset)
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem {
                Button {
                    songEditorViewModel.isSettingsShown.toggle()
                } label: {
                    Image(systemName: "slider.horizontal.3")
                }
            }
        }
        .toast(isShowing: $songEditorViewModel.isShowingTagAddedToast, message: songEditorViewModel.addedTagMessage ?? "")
        .sheet(isPresented: $songEditorViewModel.isSettingsShown) {
            SongSettingsView(songEditorViewModel: songEditorViewModel, isSettingsShown: $songEditorViewModel.isSettingsShown)
        }
        /*
        .overlay(alignment: .bottom) {
            ToolbarSheets(songEditorViewModel: songEditorViewModel)
        }
        */
        .sheet(isPresented: $songEditorViewModel.showSheet) {
            switch songEditorViewModel.selectedSheet {
            case .generate:
                GenerateLineSheet(songEditorViewModel: songEditorViewModel)
            case .restyle:
                NewRestyleSheet(songEditorViewModel: songEditorViewModel)
            case .rhyme:
                RhymeSheet(songEditorViewModel: songEditorViewModel)
            case .none:
                EmptyView()
            }
        }
        /*
        .onChange(of: songEditorViewModel.showSheet) {
            withAnimation(.default) {
                scrollViewOffset = songEditorViewModel.showSheet ? ToolbarSheetHeight + 80 : 0
            }
        }
        */
        .onAppear {
            Task {
                await songEditorViewModel.initSong()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.8){
                    focused.toggle()
                }
            }
        }
    }
}

