//
//  LargeTextFieldStyle.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 07/06/24.
//

import Foundation
import SwiftUI

struct LargeTextFieldStyle: ViewModifier {
    func body(content: Content) -> some View {
        content
            .font(.title)
            .bold()
            .truncationMode(.tail)
            .padding()
    }
}

extension View {
    func largeTextField() -> some View {
        self.modifier(LargeTextFieldStyle())
    }
}
