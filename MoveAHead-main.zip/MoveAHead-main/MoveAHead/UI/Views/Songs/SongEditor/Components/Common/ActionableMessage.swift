//
//  ActionableMessage.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 10/06/24.
//

import SwiftUI

struct ActionableMessage: View {
    var body: some View {
        Text("This action consumes tokens for using AI. Subscribe to an increased amount of tokens every day.")
            .font(.footnote)
            .foregroundStyle(.lightGray)
            .multilineTextAlignment(.center)
            .padding(.top, 1)
            .padding(.horizontal)
            .frame(maxWidth: 300)
    }
}

#Preview {
    ActionableMessage()
}
