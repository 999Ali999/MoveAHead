//
//  SectionEditor.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 07/06/24.
//

import SwiftUI

enum SectionField: Hashable {
    case title
    case content
}

struct SectionEditor: View {
    @Environment(ThemeManager.self) private var themeManager
    
    @ObservedObject var songEditorViewModel: SongEditorView.SongEditorViewModel
    var section: SongEditorView.SectionEditorViewModel
    
    @State var dynamicHeight: CGFloat = 0
    @FocusState private var focused: SectionField?
    
    // TODO: briefly - this is for the correct focus on the section title if the transition to the section occurred by pressing enter on the song title or when the transition occurred by clicking on the section.
    @State private var directlyTappedToSection = false
    
    @State private var isTagAddedShowingToast = false
    @State private var addedTag = ""
    
    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                TextField("Section title", text: Binding(
                    get: { section.title },
                    set: { songEditorViewModel.updateTitle($0, for: section.id) }
                ))
                .mediumTextField()
                .padding(.bottom, 5)
                .focused($focused, equals: .title)
                .disabled(songEditorViewModel.editMode != .Edit)
                .onSubmit {
                    // Automatic switching to section content.
                    focused = .content
                }
                
                // TODO: Custom Text Editor
                CustomTextEditor(tag: self.getSectionIndex(section.id) ?? 0, attributedText: Binding(
                    get: { section.text },
                    set: { songEditorViewModel.updateText($0, for: section.id) }
                ), highlightedRange: Binding(
                    get: { section.highlightedRange ?? NSRange(location: 0, length: 0) },
                    set: { songEditorViewModel.updateHighlightedRanges($0, for: section.id) }
                ), highlightedText: Binding(
                    get: { section.highlightedText },
                    set: { songEditorViewModel.updateHighlightedText($0, for: section.id) }
                ), selectedRange: Binding(get: { section.selectedRange }, set: { songEditorViewModel.updateSelectedRange($0, for: section.id) }), dynamicHeight: $dynamicHeight, editMode: $songEditorViewModel.editMode, font: defaultEditorFont, keyboardToolbarContent: keyboardToolbarContent, onTagAdded: { tag in
                    songEditorViewModel.addTag(tag, addedTagMessage: "Tag added.")
                })
                .frame(minHeight: dynamicHeight)
                .padding(.horizontal, 12)
                .padding(.bottom, 15)
                .focused($focused, equals: .content)

                /*
                .onTapGesture {
                    songEditorViewModel.setActiveSection(to: section.id)
                }
                */
            }
            .overlay {
                /*
                HStack {
                    RoundedRectangle(cornerRadius: 2)
                        .frame(width: 2)
                        .foregroundColor(songEditorViewModel.activeSectionID == section.id ? .gray.opacity(0.5) : .clear)
                    
                    if songEditorViewModel.activeSectionID == section.id {
                        VStack {
                            Image(systemName: "arrow.down.to.line")
                                .frame(width: 10, height: 10)
                                .foregroundColor(.gray.opacity(0.5))
                            Spacer()
                            Image(systemName: "arrow.up.to.line")
                                .frame(width: 10, height: 10)
                                .foregroundColor(.gray.opacity(0.5))
                        }
                        .padding(.horizontal, 4)
                    }
                    
                    Spacer()
                }
                */
            }
            
            // Transparent overlay to capture taps
            if songEditorViewModel.activeSectionID != section.id {
                Color.clear
                    .contentShape(Rectangle())
                    .onTapGesture {
                        directlyTappedToSection = true
                        songEditorViewModel.setActiveSection(to: section.id)
                        songEditorViewModel.updateHighlightedRanges(nil, for: section.id)
                    }
            }
        }
        .background {
            // TODO: additional background effect (s) for active section
            /*
            if songEditorViewModel.activeSectionID == section.id {
                Color.black.opacity(0.3)
            }
            */
        }
        .animation(.default, value: songEditorViewModel.activeSectionID)
        .onChange(of: songEditorViewModel.activeSectionID) {
            if songEditorViewModel.activeSectionID == section.id, !directlyTappedToSection {
                focused = .title
            }
            else if songEditorViewModel.activeSectionID == section.id {
                directlyTappedToSection = false
            }
        }
        .onAppear {
            if songEditorViewModel.activeSectionID == section.id {
                focused = .title
            }
        }
    }
    
    private func getSectionIndex(_ sectionId: UUID?) -> Int? {
        return self.songEditorViewModel.sections.firstIndex(where: { $0.id == sectionId })
    }
    
    private func keyboardToolbarContent() -> AnyView {
        AnyView (
            ZStack {
                KeyboardToolbar(
                    onSectionTap: {
                        songEditorViewModel.addSection()
                    },
                    onHashtagTap: {
                        songEditorViewModel.insertHashtag()
                    },
                    onGenerateTap: {
                        songEditorViewModel.openSheet(.generate)
                    },
                    onRhymeTap: {
                        songEditorViewModel.openSheet(.rhyme)
                    },
                    onRestyleTap: {
                        songEditorViewModel.openSheet(.restyle)
                    }
                )
                .environment(themeManager)
            }
                .frame(height: 48)
                .background(themeManager.selectedTheme.bodyBackgroundColor)
        )
    }
    
    private func insertTextAtCursor(text: String, tag: Int) {
        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let textView = windowScene.windows.first?.rootViewController?.view.viewWithTag(tag) as? UITextView else {
            return
        }

        if let selectedRange = textView.selectedTextRange {
            let cursorPosition = textView.offset(from: textView.beginningOfDocument, to: selectedRange.start)
            if let newPosition = textView.position(from: textView.beginningOfDocument, offset: cursorPosition) {
                textView.selectedTextRange = textView.textRange(from: newPosition, to: newPosition)
            }
            textView.insertText(text)
        } else {
            textView.text += text
        }
    }
}
