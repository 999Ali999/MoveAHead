//
//  RoundedbackgroundLayoutManager.swift
//  MoveAHead
//
//  Created by Santiago Torres Alvarez on 25/05/24.
//

import Foundation
import UIKit

class RoundedBackgroundLayoutManager: NSLayoutManager {
    override func drawBackground(forGlyphRange glyphsToShow: NSRange, at origin: CGPoint) {
        super.drawBackground(forGlyphRange: glyphsToShow, at: origin)
        
        guard let textStorage = self.textStorage else { return }
        
        textStorage.enumerateAttribute(.backgroundColor, in: glyphsToShow, options: []) { value, range, _ in
            if let _ = value as? UIColor {
                let glyphRange = self.glyphRange(forCharacterRange: range, actualCharacterRange: nil)
                let container = self.textContainer(forGlyphAt: glyphRange.location, effectiveRange: nil)
                
                var rect = self.boundingRect(forGlyphRange: glyphRange, in: container!)
                rect = rect.insetBy(dx: -2, dy: 0)
                
                let path = UIBezierPath(roundedRect: rect, cornerRadius: 8)
                UIColor.accent.setFill()
                path.fill()
            }
        }
    }
}
