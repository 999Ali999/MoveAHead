//
//  PressableButtonStyle.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 10/06/24.
//

import SwiftUI

struct PressableButtonStyle: ButtonStyle {
    @Environment(ThemeManager.self) private var themeManager
    
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .background(configuration.isPressed ? Color.accentColor : themeManager.selectedTheme.gray2)
            .cornerRadius(10)
            .animation(.easeInOut, value: configuration.isPressed)
    }
}
