//
//  ToolbarSheets.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 08/06/24.
//

import SwiftUI

let ToolbarSheetHeight: CGFloat = 340

struct ToolbarSheets: View {
    @Environment(ThemeManager.self) private var themeManager
    
    @ObservedObject var songEditorViewModel: SongEditorView.SongEditorViewModel
    
    var body: some View {
        ZStack {
            switch songEditorViewModel.selectedSheet {
            case .generate:
                GenerateLineSheet(songEditorViewModel: songEditorViewModel)
            case .restyle:
                NewRestyleSheet(songEditorViewModel: songEditorViewModel)
            case .rhyme:
                RhymeSheet(songEditorViewModel: songEditorViewModel)
            case .none:
                EmptyView()
            }
        }
    }
}
