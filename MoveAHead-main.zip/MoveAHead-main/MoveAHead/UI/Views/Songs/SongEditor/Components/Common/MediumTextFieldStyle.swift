//
//  MediumTextFieldStyle.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 07/06/24.
//

import Foundation
import SwiftUI

struct MediumTextFieldStyle: ViewModifier {
    @Environment(ThemeManager.self) private var themeManager
    
    func body(content: Content) -> some View {
        content
            .font(.title2)
            .bold()
            .truncationMode(.tail)
            .padding(.horizontal)
            .foregroundColor(themeManager.selectedTheme.bodyTextColor.opacity(0.6))
    }
}

extension View {
    func mediumTextField() -> some View {
        self.modifier(MediumTextFieldStyle())
    }
}
