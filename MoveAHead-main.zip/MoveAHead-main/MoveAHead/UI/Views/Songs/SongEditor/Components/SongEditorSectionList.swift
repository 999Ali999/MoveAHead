//
//  SectionList.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 07/06/24.
//

import SwiftUI

struct SongEditorSectionList: View {
    @ObservedObject var songEditorViewModel: SongEditorView.SongEditorViewModel
    
    var body: some View {
        VStack(spacing: 0) {
            ForEach(songEditorViewModel.sections) { section in
                SectionEditor(songEditorViewModel: songEditorViewModel, section: section)
                    .transition(.move(edge: .bottom))
            }
            .animation(.default, value: songEditorViewModel.sections)
        }
    }
}
