//
//  Toolbar.swift
//  MoveAHead
//
//  Created by Yuliia on 31/05/24.
//

import SwiftUI

struct KeyboardToolbar: View {
    @Environment(ThemeManager.self) private var themeManager
    
    var onSectionTap: () -> Void
    var onHashtagTap: () -> Void
    var onGenerateTap: () -> Void
    var onRhymeTap: () -> Void
    var onRestyleTap: () -> Void

    var body: some View {
        HStack {
            Button {
                onSectionTap()
            } label: {
                Image(systemName: "text.badge.plus")
                    .font(.title3)
                    .fontWeight(.regular)
                    .foregroundStyle(.accent)
            }
            
            Spacer()
            
            Button {
                onHashtagTap()
            } label: {
                Image(systemName: "number")
                    .font(.title3)
                    .fontWeight(.regular)
            }
            
            Spacer()
            
            Button {
                onGenerateTap()
            } label: {
                Image(systemName: "text.line.last.and.arrowtriangle.forward")
                    .font(.title3)
                    .fontWeight(.regular)
            }
            
            Spacer()
            
            Button {
                onRhymeTap()
            } label: {
                Image(systemName: "music.mic")
                    .font(.title3)
                    .fontWeight(.regular)
            }
            .disabledButton()
            
            Spacer()
            
            Button {
                onRestyleTap()
            } label: {
                Image(systemName: "pencil.and.outline")
                    .font(.title3)
                    .fontWeight(.regular)
                    .foregroundStyle(.accent)
            }
        }
        .padding(.horizontal)
        .padding(.vertical, 15)
        .background(themeManager.selectedTheme.gray1)
    }
}

#Preview {
    KeyboardToolbar(onSectionTap: {}, onHashtagTap: {}, onGenerateTap: {}, onRhymeTap: {}, onRestyleTap: {})
        .environment(ThemeManager.shared)
}

func hideKeyboard() {
    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
}

struct DisabledButtonModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .foregroundColor(.gray)
            .disabled(true)
    }
}

extension View {
    func disabledButton() -> some View {
        self.modifier(DisabledButtonModifier())
    }
}
