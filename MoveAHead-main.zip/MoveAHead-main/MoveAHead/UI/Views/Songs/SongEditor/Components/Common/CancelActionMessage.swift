//
//  CancelActionMessage.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 10/06/24.
//

import SwiftUI

struct CancelActionMessage: View {
    var body: some View {
        Text("To cancel the action, close this window.")
            .multilineTextAlignment(.center)
            .padding()
    }
}

#Preview {
    CancelActionMessage()
}
