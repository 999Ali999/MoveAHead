//
//  CustomTextEditor.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 07/06/24.
//
//
//  Created by Santiago Torres Alvarez on 25/05/24.
//

import SwiftUI
import UIKit

struct CustomTextEditor: UIViewRepresentable {
    var tag: Int
    @Binding var attributedText: NSAttributedString
    @Binding var highlightedRange: NSRange?
    @Binding var highlightedText: String?
    @Binding var selectedRange: NSRange?
    @Binding var dynamicHeight: CGFloat
    @Binding var editMode: SongEditorView.SongEditorViewModel.EditMode

    var font: UIFont
    var keyboardToolbarContent: () -> AnyView
    
    var onTagAdded: (_ tag: String) -> Void

    var textView = CustomUITextView()
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    func makeUIView(context: Context) -> UITextView {
        textView.tag = tag
        textView.delegate = context.coordinator
        textView.isEditable = true
        textView.isSelectable = true
        textView.isScrollEnabled = false
        textView.backgroundColor = .clear
        textView.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        textView.setContentCompressionResistancePriority(.defaultLow, for: .vertical)
        // TODO: better to increase of padding of other components to align to there.
        /*
        textView.textContainer.lineFragmentPadding = 0
        */
        textView.textContainerInset = UIEdgeInsets.zero
        textView.attributedText = attributedText
        textView.text = attributedText.string
        
        context.coordinator.initKeyboardToolbar(for: textView)
        context.coordinator.initHighlightTapRecognizer(for: textView)
    
        DispatchQueue.main.async {
            context.coordinator.adjustHeight(textView)
        }

        return textView
    }
    
    func shouldEnableTapGesture() -> Bool {
        return editMode == .HighlightParagraph
    }
    
    func updateUIView(_ uiView: UITextView, context: Context) {
        guard let textView = uiView as? CustomUITextView else { return }
        
        let storeSelectedRange = textView.selectedRange
        if textView.attributedText.string != attributedText.string {
            textView.attributedText = attributedText
            textView.text = attributedText.string
            
            context.coordinator.adjustHeight(textView)
        }
        textView.selectedRange = storeSelectedRange
        
        if let selectedRange = self.selectedRange {
            textView.selectedRange = selectedRange
        }

        textView.highlightedRange = highlightedRange
        textView.highlightedText = highlightedText
        
        self.updateFont(textView)
        self.updateEditable(textView)
        
        context.coordinator.updateHashtags(textView)
        context.coordinator.updateTapGestureState(editMode)
    }
    
    private func updateFont(_ uiView: CustomUITextView) {
        uiView.font = font
        uiView.textColor = UIColor { (traitCollection) -> UIColor in
            return traitCollection.userInterfaceStyle == .dark ? UIColor.white : UIColor.black
        }
        
        if let highlightedRange = self.highlightedRange, highlightedRange.length > 0 {
            let attributedText = NSMutableAttributedString(string: uiView.text)
            
            uiView.attributedText.enumerateAttributes(in: NSRange(location: 0, length: attributedText.length)) { attribute, range,_  in
                attributedText.addAttributes(attribute, range: range)
            }
            
            attributedText.addAttribute(.foregroundColor, value: UIColor { (traitCollection) -> UIColor in
                return traitCollection.userInterfaceStyle == .dark ? UIColor.white : UIColor.black
            }, range: NSRange(location: 0, length: attributedText.length))
            
            attributedText.addAttribute(.foregroundColor, value: UIColor.white, range: highlightedRange)
            
            uiView.attributedText = attributedText
        }
    }
    
    private func updateEditable(_ uiView: CustomUITextView) {
        uiView.isEditable = editMode == .Edit
        uiView.isSelectable = uiView.isEditable
        
    }
    
    class Coordinator: NSObject, UITextViewDelegate, UIGestureRecognizerDelegate {
        var parent: CustomTextEditor
        var tapGesture: UITapGestureRecognizer?
        
        init(_ parent: CustomTextEditor) {
            self.parent = parent
            super.init()
        }
        
        func initKeyboardToolbar(for textView: UITextView) {
            let keyboardToolbarUIHostingController = UIHostingController(rootView: self.parent.keyboardToolbarContent())
            
            let view = UIHostingController<AnyView>(rootView: AnyView(EmptyView()))
            view.rootView = self.parent.keyboardToolbarContent()
            
            let keyboardToolbarView = keyboardToolbarUIHostingController.view!
            keyboardToolbarView.translatesAutoresizingMaskIntoConstraints = false
            keyboardToolbarView.sizeToFit()
            keyboardToolbarView.backgroundColor = .clear
            textView.inputAccessoryView = keyboardToolbarUIHostingController.view
            NSLayoutConstraint.activate([
                keyboardToolbarView.centerXAnchor.constraint(equalTo: textView.inputAccessoryView!.centerXAnchor),
                keyboardToolbarView.centerYAnchor.constraint(equalTo: textView.inputAccessoryView!.centerYAnchor),
            ])
        }
        
        func initHighlightTapRecognizer(for textView: UITextView) {
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTapGesture(_:)))
            tapGesture.delegate = self
            tapGesture.isEnabled = false
            textView.addGestureRecognizer(tapGesture)
            self.tapGesture = tapGesture
        }

        func updateTapGestureState(_ editState: SongEditorView.SongEditorViewModel.EditMode) {
            if let tapGesture = self.tapGesture {
                tapGesture.isEnabled = editState == .HighlightParagraph
            }
        }
        
        func textViewDidChange(_ textView: UITextView) {
            self.parent.attributedText = textView.attributedText
            self.updateHashtags(textView)
            DispatchQueue.main.async {
                self.adjustHeight(textView)
            }
        }
        
        func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
            if text == " " || text == "\n" {
                // Check if the space follows a hashtag
                let textBeforeChange = (textView.text as NSString).substring(to: range.location)
                let hashtagPattern = "#\\b(\\w+)$"
                let regex = try! NSRegularExpression(pattern: hashtagPattern, options: [])
                let matches = regex.matches(in: textBeforeChange, options: [], range: NSRange(location: 0, length: textBeforeChange.utf16.count))

                if !matches.isEmpty {
                    // Schedule removal of the tagged text after 1 second
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                        self.animateDeletionOfTaggedText(textView)
                    }
                }
            }

            return true
        }

        func textViewDidChangeSelection(_ textView: UITextView) {
            self.parent.selectedRange = textView.selectedRange
        }
        
        func updateHashtags(_ textView: UITextView) {
            guard let text = textView.text else { return }
            
            let mutableAttributedText = NSMutableAttributedString(attributedString: textView.attributedText)
            let hashtagPattern = "#\\b(\\w+)"
            let regex = try! NSRegularExpression(pattern: hashtagPattern, options: [])
            let matches = regex.matches(in: text, options: [], range: NSRange(location: 0, length: text.utf16.count))
            
            // Clear all previous hashtag highlights
            mutableAttributedText.removeAttribute(.backgroundColor, range: NSRange(location: 0, length: text.utf16.count))
            
            for match in matches {
                let matchRange = match.range
                mutableAttributedText.addAttributes([
                    .backgroundColor: UIColor.clear
                ], range: matchRange)
            }
            
            let storeSelectedRange = textView.selectedRange
            textView.attributedText = mutableAttributedText
            textView.selectedRange = storeSelectedRange
        }
        
        // Animate deletion of the tagged text
        func animateDeletionOfTaggedText(_ textView: UITextView) {
            guard let text = textView.text else { return }

            let mutableAttributedText = NSMutableAttributedString(attributedString: textView.attributedText)
            let hashtagPattern = "#\\b(\\w+)"
            let regex = try! NSRegularExpression(pattern: hashtagPattern, options: [])
            let matches = regex.matches(in: text, options: [], range: NSRange(location: 0, length: text.utf16.count))

            for match in matches {
                let matchRange = match.range

                // Check if the character after the match range is a space or return
                let endLocation = matchRange.location + matchRange.length
                if endLocation < text.count {
                    let index = text.index(text.startIndex, offsetBy: endLocation)
                    if text[index] != " " && text[index] != "\n" {
                        continue
                    }
                }

                // Animate the deletion
                let startIndex = text.index(text.startIndex, offsetBy: matchRange.location)
                let endIndex = text.index(startIndex, offsetBy: matchRange.length)
                let range = startIndex..<endIndex

                // Create a UILabel to animate
                let label = UILabel()
                label.text = String(text[range])
                label.font = textView.font
                label.textColor = UIColor.black
                label.backgroundColor = UIColor.white
                label.frame = textView.layoutManager.boundingRect(forGlyphRange: matchRange, in: textView.textContainer)
                label.frame.origin.x += textView.textContainerInset.left
                label.frame.origin.y += textView.textContainerInset.top
                label.frame = label.frame.insetBy(dx: -2, dy: 0)
                label.layer.masksToBounds = true
                label.layer.cornerRadius = 8
                textView.addSubview(label)

                UIView.animate(withDuration: 0.5, animations: {
                    label.alpha = 0.0
                }) { _ in
                    label.removeFromSuperview()

                    // Remove the tagged text after animation completes
                    mutableAttributedText.replaceCharacters(in: matchRange, with: "")
                    // textView.attributedText = mutableAttributedText
                    self.parent.attributedText = mutableAttributedText
                    
                    // Move the cursor to the position of the deleted text
                    let newCursorPosition = NSRange(location: matchRange.location, length: 0)
                    textView.selectedRange = newCursorPosition
                    
                    // Extract the matched hashtag text
                    let matchedText = (text as NSString).substring(with: matchRange)
                    
                    self.parent.onTagAdded(matchedText)
                }
            }
        }
        
        open func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
            return self.parent.editMode == .Edit
        }
        
        @objc func handleTapGesture(_ gesture: UITapGestureRecognizer) {
            guard let textView = gesture.view as? CustomUITextView else { return }
            
            let location = gesture.location(in: textView)
            
            if let position = textView.closestPosition(to: location), let range = textView.tokenizer.rangeEnclosingPosition(position, with: .paragraph, inDirection: UITextDirection(rawValue: UITextLayoutDirection.right.rawValue)) {
                
                if let nsRange = textView.nsRange(from: range), let text = textView.text, let range = Range(nsRange, in: text), nsRange.length > 0 {
                    let substring = textView.text[range]
                    let extractedText = String(substring)
                    
                    textView.highlightedRange = nsRange
                    
                    self.parent.highlightedRange = nsRange
                    self.parent.highlightedText = extractedText
                }
            }
        }
        
        func adjustHeight(_ textView: UITextView) {
            self.parent.dynamicHeight = textView.sizeThatFits(
                CGSize(width: textView.frame.width, height: .greatestFiniteMagnitude)
            ).height
        }
    }
}

// TODO: old implementation without animatable highlighting

class CustomUITextView: UITextView {
    public var highlightedRange: NSRange? {
        didSet {
            setNeedsDisplay()
        }
    }
    
    public var highlightedText: String?
    
    public override func draw(_ rect: CGRect) {
        super.draw(rect)
        
        guard let range = highlightedRange else { return }
        guard textRange(from: beginningOfDocument, to: beginningOfDocument) != nil else { return }
        guard range.length > 0 else {
            return
        }
        
        let glyphRange = layoutManager.glyphRange(forCharacterRange: range, actualCharacterRange: nil)
        let boundingRect = layoutManager.boundingRect(forGlyphRange: glyphRange, in: textContainer)
        let path = UIBezierPath(roundedRect: boundingRect.insetBy(dx: -2, dy: 0), cornerRadius: 5)

        UIColor.accent.setFill()
        path.fill(with: .normal, alpha: 1.0)
    }
}

// TODO: new implementation with animatable highlighting
/*
class CustomUITextView: UITextView {
    public var highlightedRange: NSRange? {
        didSet {
            animateHighlightChange()
        }
    }
    
    public var highlightedText: String?
    
    override init(frame: CGRect, textContainer: NSTextContainer?) {
        let textStorage = NSTextStorage()
        let layoutManager = RoundedBackgroundLayoutManager()
        
        textStorage.addLayoutManager(layoutManager)
        
        let container = NSTextContainer(size: CGSize(width: frame.size.width, height: CGFloat.greatestFiniteMagnitude))
        container.widthTracksTextView = true
        layoutManager.addTextContainer(container)
        
        super.init(frame: frame, textContainer: container)
    }
    
    required init?(coder: NSCoder) {
        let textStorage = NSTextStorage()
        let layoutManager = RoundedBackgroundLayoutManager()
        
        textStorage.addLayoutManager(layoutManager)
        
        let container = NSTextContainer(size: CGSize(width: 0, height: CGFloat.greatestFiniteMagnitude))
        container.widthTracksTextView = true
        layoutManager.addTextContainer(container)
        
        super.init(coder: coder)
        self.textStorage.setAttributedString(textStorage)
    }
    
    private var highlightLayer: CAShapeLayer?
    private var lastRange: NSRange?
    private var lastHighlightedText: String?

    private func animateHighlightChange() {
        // TODO: skip updating where we have similar input range
        if let range = highlightedRange, lastRange == range {
            return
        }
 
        lastRange = highlightedRange
        lastHighlightedText = highlightedText
        
        // Remove any existing highlight layer
        highlightLayer?.removeFromSuperlayer()

        guard let range = highlightedRange else { return }
        guard textRange(from: beginningOfDocument, to: beginningOfDocument) != nil else {
            return
        }
        guard range.length > 0 else {
            return
        }

        let glyphRange = layoutManager.glyphRange(forCharacterRange: range, actualCharacterRange: nil)
        let boundingRect = layoutManager.boundingRect(forGlyphRange: glyphRange, in: textContainer)

        // Create a new CAShapeLayer
        let path = UIBezierPath(roundedRect: boundingRect.insetBy(dx: -2, dy: 0), cornerRadius: 8)
        let newLayer = CAShapeLayer()
        newLayer.path = path.cgPath
        newLayer.fillColor = UIColor.clear.cgColor
        
        // TODO: set negative position to draw the layer below text
        newLayer.zPosition = -1

        // Add the layer to the view's layer
        layer.addSublayer(newLayer)
        highlightLayer = newLayer

        // Create and add the animation
        let animation = CABasicAnimation(keyPath: "fillColor")
        animation.fromValue = UIColor.clear.cgColor
        animation.toValue = UIColor.accent.cgColor
        animation.duration = 0.2
        animation.timingFunction = .init(name: .easeInEaseOut)
        newLayer.add(animation, forKey: "fillColorAnimation")

        // Set the final color
        newLayer.fillColor = UIColor.accent.cgColor
    }
}

*/
