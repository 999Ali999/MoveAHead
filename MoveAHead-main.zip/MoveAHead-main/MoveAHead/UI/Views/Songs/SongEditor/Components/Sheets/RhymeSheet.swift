//
//  RestyleSheet.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 04/06/24.
//

import SwiftUI

struct RhymeSheet: View {
    @Environment(ThemeManager.self) private var themeManager
    @ObservedObject var songEditorViewModel: SongEditorView.SongEditorViewModel

    var body: some View {
        Sheet(
            titleView: {
                Image(systemName: "music.mic")
                    .font(.title3)
                    .foregroundStyle(.accent)
                Text("Rhyme")
                    .font(.title2)
                    .fontWeight(.semibold)
            },
            headerButtons: {
                CloseButton(action: {
                    self.close()
                })
            },
            bodyContent: {
                VStack {
                    Text("Tap a sentence to restyle")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .truncationMode(.tail)
                        .foregroundColor(themeManager.selectedTheme.lightGray)
                }
            }
        )
        .presentationDetents([.height(ToolbarSheetHeight)])
        .presentationBackgroundInteraction(.enabled(upThrough: .height(ToolbarSheetHeight)))
        .onDisappear {
            self.close()
        }
    }

    func close() {
        songEditorViewModel.closeSheet()
    }
}
