//
//  RestyleSheet.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 04/06/24.
//

import SwiftUI

struct RestyleSheet: View {
    @Environment(ThemeManager.self) private var themeManager
    @ObservedObject var songEditorViewModel: SongEditorView.SongEditorViewModel

    var body: some View {
        Sheet(
            titleView: {
                Image(systemName: "text.line.last.and.arrowtriangle.forward")
                    .font(.title3)
                    .foregroundStyle(.accent)
                Text("Restyle")
                    .font(.title2)
                    .fontWeight(.semibold)
            },
            headerButtons: {
                RefreshButton(action: {
                    songEditorViewModel.restyleLine()
                })
                CloseButton(action: {
                    self.close()
                })
            },
            bodyContent: {
                VStack {
                    if !songEditorViewModel.isRequestingToAI, songEditorViewModel.restyleResult.isEmpty {
                        Text("Tap a sentence to restyle")
                            .font(.title2)
                            .fontWeight(.semibold)
                            .truncationMode(.tail)
                            .foregroundColor(themeManager.selectedTheme.lightGray)
                    }
                    else if songEditorViewModel.isRequestingToAI {
                        ActionToAIProgress()
                            .padding()
                    }
                    else if !songEditorViewModel.isRequestingToAI, !songEditorViewModel.restyleResult.isEmpty {
                        ScrollView {
                            VStack(alignment: .leading) {
                                ForEach(songEditorViewModel.restyleResult, id: \.self) { line in
                                    Button {
                                        songEditorViewModel.replaceRestyleLine(line)
                                    } label: {
                                        HStack {
                                            Text(line)
                                                .truncationMode(.tail)
                                                .lineLimit(1)
                                                .foregroundStyle(songEditorViewModel.restyleSelectedTextOption == line ? .white : themeManager.selectedTheme.bodyTextColor)
                                                .padding(.horizontal)
                                        }
                                        .frame(maxWidth: .infinity)
                                        .frame(height: 45)
                                        .background {
                                            songEditorViewModel.restyleSelectedTextOption == line ?
                                                Color.accentColor : themeManager.selectedTheme.gray1
                                        }
                                    }
                                    .padding(.horizontal)
                                    .buttonStyle(PressableButtonStyle())
                                }
                            }
                        }
                    }
                }
                .animation(.default, value: songEditorViewModel.isRequestingToAI)
            }
        )
        .presentationDetents([.height(ToolbarSheetHeight)])
        .presentationBackgroundInteraction(.enabled(upThrough: .height(ToolbarSheetHeight)))
        .onDisappear {
            self.close()
        }
    }
    
    func close() {
        songEditorViewModel.cancelRestyleLineTask()
        songEditorViewModel.closeSheet()
    }
}
