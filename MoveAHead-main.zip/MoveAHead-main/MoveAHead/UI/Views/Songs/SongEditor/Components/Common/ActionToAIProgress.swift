//
//  ActionToAIProgress.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 10/06/24.
//

import SwiftUI

struct ActionToAIProgress: View {
    var body: some View {
        VStack {
            Spacer()
            ProgressView()
            Spacer()
            CancelActionMessage()
            ActionableMessage()
        }
    }
}

#Preview {
    ActionToAIProgress()
}
