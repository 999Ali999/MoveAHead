//
//  AppSettingsView.swift
//  MoveAHead
//
//  Created by Felix Parey on 07/06/24.
//

import SwiftUI

struct SettingsView: View {
    
    @Environment(ThemeManager.self) private var themeManager
    @Environment(AlbumsView.ViewModel.self) private var albumsViewModel
    @EnvironmentObject var authModel: AuthModel
    @State private var sheetPresented = false
    @AppStorage("colorSchemeNumber") private var colorSchemeNumber: Int?
    @State private var subscriptionSheetShown: Bool = false
    @State private var signOutConfirmDialogShown = false
    
    var body: some View {
        NavigationView {
            ZStack {
                themeManager.selectedTheme.bodyBackgroundColor
                    .ignoresSafeArea()
                
                Form{
                    Group{
                        Section("General Settigns") {
                            Picker("Appearance", selection: $colorSchemeNumber) {
                                Button("System"){
                                    colorSchemeNumber = nil
                                }
                                .tag(nil as Int?)
                                Button("Light"){
                                    colorSchemeNumber = 1
                                }
                                .tag(1 as Int?)
                                Button("Dark"){
                                    colorSchemeNumber = 2
                                }
                                .tag(2 as Int?)
                            }
                        }
                        Section("Account"){
                            if authModel.isSignedIn {
                                Button("Sign out", role: .destructive) {
                                    signOutConfirmDialogShown = true
                                }
                            } else {
                                Button("Create an account or sign in") {
                                    sheetPresented = true
                                }
                                .sheet(isPresented: $sheetPresented){
                                    OnboardingView(viewModel: .init(onboardingState: .SingIn), firstTimeAppLaunched: .constant(true))
                                        .padding(.top)
                                        .background(themeManager.selectedTheme.bodyBackgroundColor)
                                }
                            }
                        }
                        Section {
                            Button {
                                subscriptionSheetShown = true
                            } label: {
                                Text("Become Premium")
                                    .fontWeight(.semibold)
                                    .foregroundStyle(.white)
                                    
                            }
                            .sheet(isPresented: $subscriptionSheetShown, content: {
                                PremiumView()
                            })

                        }
                        .listRowBackground(PremiumViewModel().premiumGradient)
                    }
                    .listRowBackground(themeManager.selectedTheme.gray1)
                }
            }
            .scrollContentBackground(.hidden)
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .alert(isPresented: $signOutConfirmDialogShown) {
                Alert(
                    title: Text("Sign Out Confirmation"),
                    message: Text("You are about to sign out from your cloud account. The application will be disconnected and old stored local data will be restored. Do you want to proceed?"),
                    primaryButton: .default(Text("Yes"), action: {
                        Task {
                            await authModel.logout()
                            try! await PredefinedFoldersImpl.shared.refreshPredefinedFolders()
                            albumsViewModel.fetchSongFolders()
                        }
                    }),
                    secondaryButton: .cancel(Text("Cancel"))
                )
            }
        }
        .preferredColorScheme(themeManager.setColorScheme(number: colorSchemeNumber))
    }
}

#Preview {
    SettingsView()
        .environment(ThemeManager.shared)
}
