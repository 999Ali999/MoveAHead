//
//  AlbumsView.swift
//  MoveAHead
//
//  Created by Felix Parey on 21/05/24.
//

import SwiftUI

struct AlbumsView: View {
    @EnvironmentObject var navigationModel: NavigationModel
    @Environment(ThemeManager.self) private var themeManager
    @State var viewModel: ViewModel
    @State private var isHalfSheetPresented = false

    var body: some View {
        ZStack {
            themeManager.selectedTheme.bodyBackgroundColor
                .ignoresSafeArea()
            
            ScrollView {
                LazyVStack(spacing: 10) {
                    ForEach(viewModel.songFolders) { songFolder in
                        Button {
                            navigationModel.path.append(.songList(songFolder: songFolder))
                        } label: {
                            DeleteGestureView(onDelete: {
                                viewModel.removeSongFolder(songFolder: songFolder)
                            }) {
                                AlbumItem(symbolName: songFolder.icon, folderName: songFolder.name, songsCount: songFolder.totalSongs)
                            }
                            .disabled(viewModel.isPredefinedFolder(songFolder))
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .searchable(text: $viewModel.textSearch)
            .onChange(of: viewModel.textSearch) {
                // viewModel.search()
            }
            .task {
                viewModel.fetchSongFolders()
            }
            .sheet(isPresented: $viewModel.isAddSongFolderPopupPresented, content: {
                NewSongFolderPopupView(viewModel: viewModel)
            })
            .sheet(isPresented: $viewModel.showSettingsCover, content: {
                SettingsView()
                    .environment(viewModel)
            })
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button() {
                        viewModel.showSettingsCover = true
                    } label: {
                        Label("Settings", systemImage: "gearshape")
                    }
                }
                ToolbarItemGroup(placement: .bottomBar) {
                    Button {
                        viewModel.showAddSongFolderPopup()
                    } label: {
                        Label("Add Folder", systemImage: "folder.badge.plus")
                    }
                    Spacer()
                    Button {
                        let emptySongFolderItem = SongFolderItem()
                        navigationModel.path.append(.songEdit(songFolderId: "", songFolderItem: emptySongFolderItem))
                    } label: {
                        Label("Add Song", systemImage: "square.and.pencil")
                    }
                }
            }
        }
//        .toolbar {
//            ToolbarItem {
//                Button {
//                    isHalfSheetPresented.toggle()
//                } label: {
//                    Image(systemName: "quote.opening")
//                }
//            }
//        }
//        .sheet(isPresented: $isHalfSheetPresented) {
//            InspireViewSheet(isPresented: $isHalfSheetPresented)
//                .presentationDetents([.fraction(0.4)])
//                .presentationBackground(themeManager.selectedTheme.gray1)
//                .presentationBackgroundInteraction(.enabled(upThrough: .fraction(0.4)))
//        }
        .navigationTitle("Albums")
    }
        
}
