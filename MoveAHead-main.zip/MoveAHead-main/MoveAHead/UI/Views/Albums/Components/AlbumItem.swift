//
//  FolderItem.swift
//  MoveAHead
//
//  Created by Felix Parey on 21/05/24.
//

import SwiftUI

struct AlbumItem: View {
    @Environment(ThemeManager.self) private var themeManager
    var symbolName: String?
    var folderName: String?
    var songsCount: Int?
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 15)
                .foregroundStyle(themeManager.selectedTheme.gray1)
            HStack {
                Image(systemName: symbolName ?? "folder")
                    .foregroundStyle(.accent)
                Text(folderName ?? "New Folder")
                    .foregroundStyle(themeManager.selectedTheme.bodyTextColor)
                Spacer()
                Text("\(songsCount ?? 0)")
                    .foregroundStyle(themeManager.selectedTheme.bodyTextColor)
                    .padding(10)
                    .clipShape(Circle())
            }
        }
        .containerRelativeFrame(.vertical) { size, _ in
            size * 0.075
        }
        .frame(height: 150)
        .padding(.horizontal)
    }
}

#Preview {
    AlbumItem()
        .environment(ThemeManager.shared)
        .preferredColorScheme(.dark)
}
