//
//  InspireViewSheet.swift
//  MoveAHead
//
//  Created by Santiago Torres Alvarez on 10/06/24.
//

import Foundation

import SwiftUI

struct InspireViewSheet: View {
    @EnvironmentObject var navigationModel: NavigationModel
    @Environment(ThemeManager.self) private var themeManager
    
    @State private var showButtons = false
    @State private var selectedPhrase: String? = nil
    @Binding var isPresented: Bool

    let phrases = [
        "When silence speaks louder than words",
        "Finding light in the darkest corners, When a candle is lit a shadow is created",
        "Building bridges from broken dreams",
        "Listening to the heart's hidden whispers",
        "Tracing paths that never existed",
        "Sailing on a sea of endless possibilities",
        "Discovering magic in the mundane",
        "Uncovering stories in forgotten places",
        "Turning scars into constellations",
        "Dancing with shadows of the past",
        "Chasing sunsets in a concrete jungle",
        "Writing letters to the future self im a super long sentence omaigad",
        "Breathing life into old memories",
        "Finding freedom in letting go",
        "Seeing beauty in imperfection",
        "Creating worlds from fleeting thoughts",
        "Learning to fly without wings",
        "Hearing songs in the city's heartbeat",
        "Weaving dreams into reality",
        "Exploring the spaces between moments",
        "Turning whispers into roars",
        "Painting pictures with words",
        "Navigating life by the stars",
        "Finding harmony in chaos",
        "Dreaming with eyes wide open"
    ]
    
    var body: some View {
        VStack {
            // Fixed Header
            HStack {
                Image(systemName: "quote.opening")
                    .frame(width: 40, height: 40)
                    .padding(.leading, 10)
                    .foregroundColor(Color.accentColor)
                
                Text("Inspire Cards")
                    .font(.title2)
                    .foregroundStyle(.white)
                
                Spacer()
            }
            .padding(.top, 10)
            
            // Scrollable and Animated Content
            VStack {
                ScrollViewReader { proxy in
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 20) {
                            ForEach(phrases, id: \.self) { phrase in
                                Text(phrase)
                                    .font(.system(size: 24, weight: .semibold))
                                    .foregroundColor(themeManager.selectedTheme.bodyTextColor)
                                    .padding()
                                    .background(RoundedRectangle(cornerRadius: 10).fill(themeManager.selectedTheme.bodyBackgroundColor))
                                    .frame(width: 340, height: 200)
                                    .id(phrase)
                                    .onTapGesture {
                                        withAnimation {
                                            selectedPhrase = phrase
                                            showButtons = true
                                        }
                                    }
                            }
                        }
                        .padding(.horizontal, 20)
                    }
                    .scrollTargetBehavior(.viewAligned)
                    .scrollTargetLayout()
                    .contentMargins(0.2, for: .scrollContent)
                    .containerRelativeFrame(.horizontal)
                    //                    .onChange(of: selectedPhrase) { phrase in
                    //                        if let phrase = phrase {
                    //                            proxy.scrollTo(phrase, anchor: .center)
                    //                        }
                    //                    }
                }
                
                if showButtons, let selectedPhrase = selectedPhrase {
                    HStack {
                        Button(action: {
                            withAnimation {
                                showButtons = false
                                self.selectedPhrase = nil
                            }
                        }) {
                            Text("Cancel")
                                .padding()
                                .background(Color.gray)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .frame(height: 50)
                        }
                        
                        Button(action: {
                            isPresented.toggle()
                            let emptySongFolderItem = SongFolderItem(name: selectedPhrase)
                            navigationModel.path.append(.songEdit(songFolderId: "", songFolderItem: emptySongFolderItem))
                        }) {
                            Text("New Note")
                                .padding()
                                .background(Color.accentColor)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .frame(height: 50)
                        }
                    }
                    .transition(.opacity)
                    .animation(.easeInOut, value: showButtons)
                    .offset(y: -20)
                }
            }
        }
    }
}
