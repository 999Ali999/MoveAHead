//
//  NewSongFolderView.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 13/05/24.
//

import SwiftUI
import CoreHaptics

struct NewSongFolderPopupView: View {
    
    @Environment(ThemeManager.self) private var themeManager
    @State var viewModel: AlbumsView.ViewModel
    @FocusState var isFocused
    
    // Haptic feedback engine
    @State private var engine: CHHapticEngine?
    
    var body: some View {
        NavigationStack {
            ZStack{
                themeManager.selectedTheme.bodyBackgroundColor
                    .ignoresSafeArea()
                VStack {
                    TextField("New Folder", text: $viewModel.addingSongFolderName)
                        .padding(15)
                        .background(themeManager.selectedTheme.gray1, in: RoundedRectangle(cornerRadius: 15))
                        .padding()
                        .focused($isFocused)
                        .onReceive(NotificationCenter.default.publisher(for: UITextField.textDidBeginEditingNotification)) { obj in
                            if let textField = obj.object as? UITextField {
                                textField.selectedTextRange = textField.textRange(from: textField.beginningOfDocument, to: textField.endOfDocument)
                            }
                        }
                    
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 5), spacing: 15) {
                        ForEach(AlbumsView.ViewModel.icons, id: \.self) { iconName in
                                ZStack {
                                    Circle()
                                        .containerRelativeFrame(.horizontal) { size, _ in
                                            size * 0.15
                                        }
                                        .foregroundColor(viewModel.addingSongIcon == iconName ? .accent : themeManager.selectedTheme.gray1)
                                    
                                    Image(systemName: iconName)
                                        .font(.title3)
                                        .foregroundColor(viewModel.addingSongIcon == iconName ? .white : themeManager.selectedTheme.bodyTextColor)
                                }
                                .onTapGesture {
                                    if viewModel.addingSongIcon == iconName {
                                        viewModel.addingSongIcon = nil
                                    } else {
                                        viewModel.addingSongIcon = iconName
                                    }
                                }
                        }
                    }
                    .padding(.horizontal, 10)
                    Spacer()
                }
            }
            .toolbar{
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done"){
                        viewModel.addSongFolder()
                    }
                }
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel"){
                        viewModel.hideAddSongFolderPopup()
                    }
                }
            }
            .scrollDismissesKeyboard(.immediately)
            .onAppear{
                isFocused.toggle()
            }
        }
    }
}

#Preview {
    NewSongFolderPopupView(viewModel: AlbumsView.ViewModel())
}
