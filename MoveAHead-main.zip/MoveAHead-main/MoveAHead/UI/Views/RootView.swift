//
//  RootView.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 13/05/24.
//

import SwiftUI
import AuthenticationServices

struct RootView: View {
    
    @EnvironmentObject var navigationModel: NavigationModel
    @EnvironmentObject var authModel: AuthModel
    @Binding var albumsViewModel: AlbumsView.ViewModel
    @Binding var firstTimeAppLaunched: Bool
    
    var body: some View {
        NavigationStack(path: $navigationModel.path) {
            if firstTimeAppLaunched {
                OnboardingView(viewModel: .init(onboardingState: .Info), firstTimeAppLaunched: $firstTimeAppLaunched)
                    .environment(albumsViewModel)
            } else {
                if authModel.isAuthenticated {
                    AlbumsView(viewModel: albumsViewModel)
                        .environmentObject(navigationModel)
                        .navigationDestination(for: NavigationModel.NavigationDestination.self) { destination in
                            switch destination {
                            case .songList(let songFolder):
                                SongsView(songFolder: songFolder)
                                    .environmentObject(navigationModel)
                            case .songEdit(let songFolderId, let songFolderItem):
                                SongEditorView(songFolderId: songFolderId, songFolderItem: songFolderItem)
                                    .environmentObject(navigationModel)
                            }
                        }
                }
            }
        }
    }
}
