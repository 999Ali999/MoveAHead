//
//  KeyboardResponder.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 04/06/24.
//

import SwiftUI
import Combine

class KeyboardResponder: ObservableObject {
    @Published var isKeyboardVisible: Bool = false
    
    private var notificationCenter: NotificationCenter
    private var cancellables = Set<AnyCancellable>()
    
    init(notificationCenter: NotificationCenter = .default) {
        self.notificationCenter = notificationCenter
        self.subscribeToKeyboardEvents()
    }
    
    private func subscribeToKeyboardEvents() {
        notificationCenter.publisher(for: UIResponder.keyboardWillShowNotification)
            .map { _ in true }
            .assign(to: \.isKeyboardVisible, on: self)
            .store(in: &cancellables)
        
        notificationCenter.publisher(for: UIResponder.keyboardWillHideNotification)
            .map { _ in false }
            .assign(to: \.isKeyboardVisible, on: self)
            .store(in: &cancellables)
    }
}
