//
//  Debouncer.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 08/06/24.
//

import Foundation

class Debouncer {
    private var task: Task<Void, Never>? = nil
    private let delay: TimeInterval
    
    init(delay: TimeInterval) {
        self.delay = delay
    }
    
    func debounce(action: @escaping () -> Void) {
        // Cancel the previous task if it's still pending
        task?.cancel()
        
        // Create a new task
        task = Task {
            // Delay for the specified interval
            try? await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
            
            // Execute the action if the task hasn't been cancelled
            if !Task.isCancelled {
                action()
            }
        }
    }
    
    func kill() {
        if let task = task, !task.isCancelled {
            task.cancel()
        }
    }
    
    deinit {
        // Cancel any pending task when the debouncer is deallocated
        task?.cancel()
    }
}

