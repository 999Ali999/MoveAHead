//
//  AiModalView.swift
//  MoveAHead
//
//  Created by Yuliia on 21/05/24.
//

import SwiftUI

struct Sheet<TitleView: View, HeaderButtons: View, BodyContent: View>: View {
    
    let titleView: TitleView
    let headerButtons: HeaderButtons
    let bodyContent: BodyContent
    
    init(@ViewBuilder titleView: () -> TitleView, @ViewBuilder headerButtons: () -> HeaderButtons, @ViewBuilder bodyContent: () -> BodyContent) {
        self.titleView = titleView()
        self.headerButtons = headerButtons()
        self.bodyContent = bodyContent()
    }
    
    var body: some View {
        ZStack(alignment: .top) {
            
            BodyBackgroundView()
            
            VStack {
                HStack {
                    titleView
                    Spacer()
                    headerButtons
                }
                .padding()
                
                Spacer()
                bodyContent
                Spacer()
            }
        }
    }
}
