//
//  NewSheet.swift
//  MoveAHead
//
//  Created by Felix Parey on 14/06/24.
//


import SwiftUI


struct GeneratedTextCard: View {
    
    @ObservedObject var songEditorViewModel: SongEditorView.SongEditorViewModel
    @Environment(ThemeManager.self) private var themeManager
    var text: String
    
    var body: some View {
        if songEditorViewModel.selectedSheet == .generate {
            ZStack{
                Text(text)
                    .fixedSize(horizontal: false, vertical: true)
                    .allowsTightening(true)
                    .foregroundStyle(songEditorViewModel.generateSelectedTextOption == text ? .white : themeManager.selectedTheme.bodyTextColor)
                    .font(.body)
                    .padding(.vertical, 10)
                    .padding(.horizontal)
                    .frame(maxWidth: .infinity)
                    .background(RoundedRectangle(cornerRadius: 15)
                        .foregroundStyle(songEditorViewModel.generateSelectedTextOption == text ? .accent : themeManager.selectedTheme.gray1))
            }
            .containerRelativeFrame(.horizontal, count: 1, spacing: 0)
            
        } else if songEditorViewModel.selectedSheet == .restyle {
            ZStack{
                Text(text)
                    .fixedSize(horizontal: false, vertical: true)
                    .allowsTightening(true)
                    .foregroundStyle(songEditorViewModel.restyleSelectedTextOption == text ? .white : themeManager.selectedTheme.bodyTextColor)
                    .font(.body)
                    .padding(.vertical, 10)
                    .padding(.horizontal)
                    .frame(maxWidth: .infinity)
                    .background(RoundedRectangle(cornerRadius: 15)
                        .foregroundStyle(songEditorViewModel.restyleSelectedTextOption == text ? .accent : themeManager.selectedTheme.gray1))
            }
            .containerRelativeFrame(.horizontal, count: 1, spacing: 0)
        } else{
            Text("Nothing")
        }
    }
}

struct NewRestyleSheet: View {
    
    @ObservedObject var songEditorViewModel: SongEditorView.SongEditorViewModel
    @Environment(ThemeManager.self) private var themeManager
    @State private var sheetHeight: CGFloat = 0.0
    @State private var updateViewNumber: Int = 0
    
    var body: some View {
        ZStack {
            BodyBackgroundView()
            VStack {
                HStack {
                    Image(systemName: "pencil.and.outline")
                        .font(.title2)
                        .foregroundStyle(.accent)
                    Text("Restyle")
                        .font(.title2)
                    Spacer()
                    RefreshButton {
                        songEditorViewModel.restyleLine()
                    }
                    CloseButton {
                        songEditorViewModel.cancelRestyleLineTask()
                        songEditorViewModel.closeSheet()
                    }
                }
                .padding([.horizontal, .top])
                
                if !songEditorViewModel.isRequestingToAI, songEditorViewModel.restyleResult.isEmpty{
                    Text("Tap a line of your text to restyle")
                        .foregroundStyle(themeManager.selectedTheme.bodyTextColor)
                        .font(.title3)
                        .fontWeight(.medium)
                        .padding()
                } else if songEditorViewModel.isRequestingToAI {
                    ActionToAIProgress()
                        .padding()
                }else{
                    
                    VStack{
                        ScrollView(.horizontal){
                            HStack(spacing: 10){
                                ForEach(songEditorViewModel.restyleResult, id: \.self){ line in
                                    GeneratedTextCard(songEditorViewModel: songEditorViewModel, text: line)
                                        .onTapGesture {
                                            songEditorViewModel.replaceRestyleLine(line)
                                        }
                                }
                            }
                            .scrollTargetLayout()
                        }
                        .scrollTargetBehavior(.viewAligned)
                        .scrollIndicators(.never)
                        .contentMargins(.horizontal, 30, for: .scrollContent)
                        
                        //                        Text(songEditorViewModel.originalRestyleLine ?? "No text found")
                        //                            .foregroundStyle(.secondary)
                        //                            .multilineTextAlignment(.center)
                        //                            .fixedSize(horizontal: false, vertical: true)
                        
                        Button {
                            // Replacing with original Line
                            songEditorViewModel.replaceRestyleLine(songEditorViewModel.originalRestyleLine ?? "")
                        } label: {
                            Text("Revert back")
                        }
                        .padding(.vertical, 10)
                    }
                }
                
            }
        }
        .background{
            GeometryReader{ geo in
                Color.clear
                    .task{
                        sheetHeight = geo.size.height
                    }
                    .onChange(of: songEditorViewModel.isRequestingToAI) { oldValue, newValue in
                        sheetHeight = geo.size.height
                        print("CHnaged")
                    }
            }
        }
        .presentationDetents([.height(sheetHeight)])
        .presentationBackgroundInteraction(.enabled(upThrough: .height(sheetHeight)))
        .onDisappear{
            close()
        }
    }
    
    func close() {
        songEditorViewModel.closeSheet()
        sheetHeight = 0.0
    }
}

//
//#Preview {
//    NewSheet(songEditorViewModel: , symbolName: "pencil.and.outline", featureName: "Restyle")
//        .environment(ThemeManager.shared)
//}

struct BodyBackgroundView: View {
    
    @Environment(ThemeManager.self) private var themeManager
    
    var body: some View {
        themeManager.selectedTheme.bodyBackgroundColor
            .ignoresSafeArea()
    }
}
