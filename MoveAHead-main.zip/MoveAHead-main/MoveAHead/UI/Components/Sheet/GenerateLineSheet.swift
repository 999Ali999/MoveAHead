//
//  GenerateLineSheet.swift
//  MoveAHead
//
//  Created by Felix Parey on 21/06/24.
//

import SwiftUI

struct GenerateLineSheet: View {
    
    @ObservedObject var songEditorViewModel: SongEditorView.SongEditorViewModel
    @Environment(ThemeManager.self) private var themeManager
    @State private var sheetHeight: CGFloat = 0.0
    var body: some View {
        Sheet {
            
            Image(systemName: "text.line.last.and.arrowtriangle.forward")
                .font(.title2)
                .foregroundStyle(.accent)
            Text("Generate Next Line")
                .font(.title2)
            
        } headerButtons: {
            
            RefreshButton {
                songEditorViewModel.generateNextLines()
            }
            
            CloseButton {
                songEditorViewModel.cancelGenerateNextLinesTask()
                songEditorViewModel.closeSheet()
            }
            
        } bodyContent: {
            if !songEditorViewModel.isRequestingToAI, songEditorViewModel.generateResult.isEmpty{
                
                
                Button {
                    //TODO: Replace with real previous Text
                    songEditorViewModel.generateNextLines()
                    
                } label: {
                    Text("Generate Next Line")
                        .foregroundStyle(.white)
                        .font(.title3)
                        .fontWeight(.medium)
                        .padding()
                        .background(Color.accent, in: RoundedRectangle(cornerRadius: 15))
                }
                .padding()
                
                    
            } else if songEditorViewModel.isRequestingToAI {
                ActionToAIProgress()
                    .padding()
            }else{
                VStack{
                    ScrollView(.horizontal){
                        HStack(spacing: 10){
                            ForEach(songEditorViewModel.generateResult, id: \.self){ line in
                                GeneratedTextCard(songEditorViewModel: songEditorViewModel, text: line)
                                    .onTapGesture {
                                        songEditorViewModel.insertGeneratedLine(line)
                                    }
                            }
                        }
                        .scrollTargetLayout()
                    }
                    .scrollTargetBehavior(.viewAligned)
                    .scrollIndicators(.never)
                    .contentMargins(.horizontal, 30, for: .scrollContent)
                }
            }
        }
        .background{
            GeometryReader{ geo in
                Color.clear
                    .task{
                        sheetHeight = geo.size.height
                    }
                    .onChange(of: songEditorViewModel.isRequestingToAI) { oldValue, newValue in
                        sheetHeight = geo.size.height
                        print("CHnaged")
                    }
            }
        }
        .presentationDetents([.height(sheetHeight)])
        .presentationBackgroundInteraction(.enabled(upThrough: .height(sheetHeight)))
        .onDisappear{
            close()
        }
    }
    func close() {
        songEditorViewModel.closeSheet()
        sheetHeight = 0.0
    }
}
