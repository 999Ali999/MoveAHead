//
//  DeleteGestureView.swift
//  MoveAHead
//
//  Created by Santiago Torres Alvarez on 22/05/24.
//

import SwiftUI

struct DeleteGestureView<Content: View>: View {
    var onDelete: () -> Void
    @ViewBuilder let content: Content
    
    var body: some View {
        SwipeAction(cornerRadius: 15, direction: .trailing) {
            content
        } actions: {
            Action(tint: .blue, icon: "star.fill"){
                print("Favorites")
            }
            Action(tint: .red, icon: "trash.fill"){
                onDelete()
            }
        }
        .frame(height: 50)
    }
}


struct DeleteGestureViewSong<Content: View>: View {
    var onDelete: () -> Void
    @ViewBuilder let content: Content
    
    var body: some View {
        SwipeActionSong(cornerRadius: 12, direction: .trailing) {
            content
        } actions: {
            Action(tint: .blue, icon: "star.fill"){
                print("Favorites")
            }
            Action(tint: .red, icon: "trash.fill"){
                onDelete()
            }
        }
        .frame(height: 120)
    }
}



struct SwipeAction<Content: View>: View {
    var cornerRadius: CGFloat = 0
    var direction: SwipeDirection = .trailing
    @ViewBuilder var content: Content
    @ActionBuilder var actions: [Action]
    //VIEW PROPERTIES
    @Environment(\.colorScheme) private var scheme
    @Environment(ThemeManager.self) private var themeManager
    //VIEW IDENTIFIERS
    let viewID = "CONTENTVIEW"
    //Update:
//    Just replace viewID = UUID() with "CONTENTVIEW", since UUID is regenerated whenever the view is removed!
    
    @State private var isEnabled: Bool = true
    @State private var scrollOffset: CGFloat = .zero
    
    var body: some View{
        ScrollViewReader{
            scrollProxy in
            ScrollView(.horizontal){
                LazyHStack(spacing:3){
                    content
                    //To Take FUll Available Space
                        .containerRelativeFrame(.horizontal)
                    //SETS BG OF WHOLE THING
                        .background(themeManager.selectedTheme.gray1)
                        .background{
                            if let firstAction = actions.first {
                                Rectangle()
                                    .fill(firstAction.tint)
                                    .opacity(scrollOffset == .zero ? 0 : 1)
                            }
                        }
                        .id(viewID)
                        .transition(.identity)
                        .overlay {
                            GeometryReader{
                                let minX = $0.frame(in: .scrollView(axis: .horizontal)).minX
                                
                                Color.clear
                                    .preference(key: OffsetKey.self, value: minX)
                                    .onPreferenceChange(OffsetKey.self){
                                        scrollOffset = $0
                                    }
                             }
                        }
                    
                    ActionButton{
                        withAnimation(.snappy){
                            scrollProxy.scrollTo(viewID, anchor: direction == .trailing ? .topLeading : .topTrailing)
                        }
                    }
                    .opacity(scrollOffset == .zero ? 0 : 1)
                }
             
                .scrollTargetLayout()
                .visualEffect { content, geometryProxy in
                    content
                        .offset(x: scrolOffset(geometryProxy))
                }
               
               
            }
          
            .scrollIndicators(.hidden)
            .scrollTargetBehavior(.viewAligned)
            .background{
                if let lastAction = actions.last {
                    Rectangle()
                        .fill(lastAction.tint)
                        .opacity(scrollOffset == .zero ? 0 : 1)
                }
            }
            .clipShape(.rect(cornerRadius: cornerRadius))
            .padding(.trailing)
            .padding(.leading)
        }
        .allowsHitTesting(isEnabled)
        .transition(CustomTransition())
    }
    
    //ACTION BUTTON
    @ViewBuilder
    func ActionButton(resetPosition: @escaping () -> ()) -> some View {
        //100 width each action button
        Rectangle()
            .fill(.clear)
            .frame(width: CGFloat(actions.count) * 100 - 10)
            .overlay(alignment: direction.alignment){
                HStack(spacing: 0){
                    ForEach(actions) { button in
                        Button(action: {
                            Task {
                                isEnabled = false
                                resetPosition()
                                try? await Task.sleep(for: .seconds(0.25))
                                button.action()
                                try? await Task.sleep(for: .seconds(0.1))
                                isEnabled = true
                            }
                        }, label: {
                            Image(systemName: button.icon)
                                .font(button.iconFont)
                                .foregroundStyle(button.iconTint)
                                .frame(width: 100)
                                .frame(maxHeight: .infinity)
                                .contentShape(.rect)
                        })
                        .buttonStyle(.plain)
                        .background(button.tint)
                    }
                }
            }
    }
    
    //STOPS THE SCROLL ON THE LEFT
    func scrolOffset(_ proxy: GeometryProxy) -> CGFloat {
        let minX = proxy.frame(in:.scrollView(axis: .horizontal)).minX
        
        return direction == .trailing ? (minX > 0 ? -minX : 0 ) : (minX < 0 ? -minX : 0)
    }
}




struct SwipeActionSong<Content: View>: View {
    var cornerRadius: CGFloat = 0
    var direction: SwipeDirection = .trailing
    @ViewBuilder var content: Content
    @ActionBuilder var actions: [Action]
    //VIEW PROPERTIES
    @Environment(\.colorScheme) private var scheme
    @Environment(ThemeManager.self) private var themeManager
    //VIEW IDENTIFIERS
    let viewID = "CONTENTVIEW"
    //Update:
//    Just replace viewID = UUID() with "CONTENTVIEW", since UUID is regenerated whenever the view is removed!
    
    @State private var isEnabled: Bool = true
    @State private var scrollOffset: CGFloat = .zero
    
    var body: some View{
        ScrollViewReader{
            scrollProxy in
            ScrollView(.horizontal){
                LazyHStack(spacing:3){
                    content
                    //To Take FUll Available Space
                        .containerRelativeFrame(.horizontal)
                    //SETS BG OF WHOLE THING
                        .background(themeManager.selectedTheme.gray1)
                        .background{
                            if let firstAction = actions.first {
                                Rectangle()
                                    .fill(firstAction.tint)
                                    .opacity(scrollOffset == .zero ? 0 : 1)
                            }
                        }
                        .id(viewID)
                        .transition(.identity)
                        .overlay {
                            GeometryReader{
                                let minX = $0.frame(in: .scrollView(axis: .horizontal)).minX
                                
                                Color.clear
                                    .preference(key: OffsetKey.self, value: minX)
                                    .onPreferenceChange(OffsetKey.self){
                                        scrollOffset = $0
                                    }
                             }
                        }
                    
                    ActionButton{
                        withAnimation(.snappy){
                            scrollProxy.scrollTo(viewID, anchor: direction == .trailing ? .topLeading : .topTrailing)
                        }
                    }
                    .opacity(scrollOffset == .zero ? 0 : 1)
                }
             
                .scrollTargetLayout()
                .visualEffect { content, geometryProxy in
                    content
                        .offset(x: scrolOffset(geometryProxy))
                }
               
               
            }
          
            .scrollIndicators(.hidden)
            .scrollTargetBehavior(.viewAligned)
            .background{
                if let lastAction = actions.last {
                    Rectangle()
                        .fill(lastAction.tint)
                        .opacity(scrollOffset == .zero ? 0 : 1)
                }
            }
            .clipShape(.rect(cornerRadius: cornerRadius))
            .padding(.trailing)
            .padding(.leading)
        }
        .allowsHitTesting(isEnabled)
        .transition(CustomTransition())
    }
    
    //ACTION BUTTON
    @ViewBuilder
    func ActionButton(resetPosition: @escaping () -> ()) -> some View {
        //100 width each action button
        Rectangle()
            .fill(.clear)
            .frame(width: CGFloat(actions.count) * 100 - 10)
            .overlay(alignment: direction.alignment){
                HStack(spacing: 0){
                    ForEach(actions) { button in
                        Button(action: {
                            Task {
                                isEnabled = false
                                resetPosition()
                                try? await Task.sleep(for: .seconds(0.25))
                                button.action()
                                try? await Task.sleep(for: .seconds(0.1))
                                isEnabled = true
                            }
                        }, label: {
                            Image(systemName: button.icon)
                                .font(button.iconFont)
                                .foregroundStyle(button.iconTint)
                                .frame(width: 100)
                                .frame(maxHeight: .infinity)
                                .contentShape(.rect)
                        })
                        .buttonStyle(.plain)
                        .background(button.tint)
                    }
                }
            }
    }
    
    //STOPS THE SCROLL ON THE LEFT
    func scrolOffset(_ proxy: GeometryProxy) -> CGFloat {
        let minX = proxy.frame(in:.scrollView(axis: .horizontal)).minX
        
        return direction == .trailing ? (minX > 0 ? -minX : 0 ) : (minX < 0 ? -minX : 0)
    }
}






//Custum Transition

struct CustomTransition: Transition {
    func body(content: Content, phase: TransitionPhase) -> some View{
        content
            .mask {
                GeometryReader {
                    let size = $0.size
                    
                    Rectangle()
                        .offset(y: phase == .identity ? 0 : -size.height)
                }
                .containerRelativeFrame(.horizontal)
            }
    }
    
}


enum SwipeDirection {
    case leading
    case trailing
    var alignment: Alignment {
        switch self {
        case .leading:
            return .leading
        case .trailing:
            return .trailing
        }
    }
}


struct OffsetKey: PreferenceKey {
    static var defaultValue: CGFloat = .zero
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat){
        value = nextValue()
    }
}


struct Action: Identifiable{
    private(set) var id: UUID = .init()
    var tint: Color
    var icon: String
    var iconFont: Font = .title2
    var iconTint: Color = .white
    var isEnabled: Bool = true
    var action: () -> ()
}

@resultBuilder
struct ActionBuilder {
    static func buildBlock(_ components: Action...) -> [Action] {
        return components
    }
}

//
//#Preview {
//    DeleteGestureView(onDelete: {}) {
//        Text("Preview")
//    }
//}
