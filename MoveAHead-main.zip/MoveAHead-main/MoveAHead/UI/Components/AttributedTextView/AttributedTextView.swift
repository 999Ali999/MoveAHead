import SwiftUI
import UIKit
import Combine

public enum AttributedTextMode {
    case HighlightParagraph
    case Edit
}

public class AttributedUITextView: UITextView {
    public var highlightColor: UIColor? {
        didSet {
            setNeedsDisplay()
        }
    }
    
    public var highlightedRange: NSRange? {
        didSet {
            setNeedsDisplay()
        }
    }
    
    public override func draw(_ rect: CGRect) {
        super.draw(rect)
        
        guard let range = highlightedRange else {
            return
        }
        
        guard textRange(from: beginningOfDocument, to: beginningOfDocument) != nil else { return }
        
        let glyphRange = layoutManager.glyphRange(forCharacterRange: range, actualCharacterRange: nil)
        let boundingRect = layoutManager.boundingRect(forGlyphRange: glyphRange, in: textContainer)
        
        let path = UIBezierPath(roundedRect: boundingRect.insetBy(dx: 0, dy: 0), cornerRadius: 5)
        
        if let highlightColor = highlightColor {
            highlightColor.setFill()
        }
        
        path.fill(with: .normal, alpha: 1.0)
    }
}

extension UIColor {
    func inverseColor() -> UIColor {
        var alpha: CGFloat = 1.0
        var red: CGFloat = 0, green: CGFloat = 0, blue: CGFloat = 0
        getRed(&red, green: &green, blue: &blue, alpha: &alpha)
        return UIColor(red: 1 - red, green: 1 - green, blue: 1 - blue, alpha: alpha)
    }
}

extension UIColor {
    var redComponent: CGFloat { return CIColor(color: self).red }
    var greenComponent: CGFloat { return CIColor(color: self).green }
    var blueComponent: CGFloat { return CIColor(color: self).blue }
    var alphaComponent: CGFloat { return CIColor(color: self).alpha }
}

struct AttributedTextView: UIViewRepresentable {
    @Binding var attributedText: NSAttributedString
    @Binding var dynamicHeight: CGFloat
    @Binding var highlightedRange: NSRange?
    @Binding var highlightColor: UIColor?
    @Binding var mode: AttributedTextMode
    @Binding var isFocused: Bool
    
    var font: UIFont
    
    var renderKeyboardToolbar: () -> AnyView
    
    var onSizeAdjusted: () -> Void
    var onToolBarButtonTap: () -> Void
    var onParagraphSelected: (_ selectedRange: NSRange?) -> Void
    
    public var textView = AttributedUITextView()
    public var keyboardToolbarHostingController: UIHostingController<AnyView>?
    
    class Coordinator: NSObject, UITextViewDelegate, UIGestureRecognizerDelegate {
        var parent: AttributedTextView
        public var cancellables = Set<AnyCancellable>()
        
        init(parent: AttributedTextView) {
            self.parent = parent
            super.init()
            
            self.subscribeToContextChanges()
        }
        
        func subscribeToContextChanges() {
            
        }
        
        func textViewDidChange(_ textView: UITextView) {
            DispatchQueue.main.async {
                self.parent.attributedText = textView.attributedText
                self.adjustHeight(textView)
            }
        }
        
        func adjustHeight(_ textView: UITextView) {
            self.parent.dynamicHeight = textView.sizeThatFits(
                CGSize(width: textView.frame.width, height: .greatestFiniteMagnitude)
            ).height
            
            self.parent.onSizeAdjusted()
        }
        
        open func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
            return self.parent.mode == .Edit
        }
        
        open func textViewDidBeginEditing(_ textView: UITextView) {
            DispatchQueue.main.async {
                self.parent.isFocused = true
            }
        }
        
        open func textViewDidEndEditing(_ textView: UITextView) {
            DispatchQueue.main.async {
                self.parent.isFocused = false
            }
        }
        
        open func textViewDidChangeSelection(_ textView: UITextView) {}
        
        @objc func handleTapGesture(_ gesture: UITapGestureRecognizer) {
            guard let textView = gesture.view as? AttributedUITextView else { return }
            
            if self.parent.mode != .HighlightParagraph {
                return
            }
            
            let location = gesture.location(in: textView)
            if let position = textView.closestPosition(to: location),
               let range = textView.tokenizer.rangeEnclosingPosition(position, with: .paragraph, inDirection: UITextDirection(rawValue: UITextLayoutDirection.right.rawValue)) {
                let nsRange = textView.nsRange(from: range)
                DispatchQueue.main.async {
                    self.parent.highlightedRange = nsRange
                    self.parent.onParagraphSelected(nsRange)
                    
                    textView.highlightedRange = nsRange
                    
                    // Invert text color within the highlighted range
                    if let highlightColor = textView.highlightColor {
                        let mutableAttributedString = NSMutableAttributedString(attributedString: textView.attributedText)
                    
                        mutableAttributedString.enumerateAttributes(in: nsRange!, options: []) { attributes, range, _ in
                            if let originalColor = attributes[.foregroundColor] as? UIColor {
                                let invertedColor = UIColor(red: 1 - originalColor.redComponent, green: 1 - originalColor.greenComponent, blue: 1 - originalColor.blueComponent, alpha: originalColor.alphaComponent)
                                
                                // TODO: inverting color here doesn't work.
                                mutableAttributedString.addAttributes([.strokeWidth: -3.0, .strokeColor: UIColor.white], range: range)
                            }
                        }
                        textView.attributedText = mutableAttributedString
                    }
                }
            }
        }
        
        @objc func showGenerateSheet() {
            self.parent.onToolBarButtonTap()
        }
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
    
    func makeUIView(context: Context) -> UITextView {
        textView.isEditable = false
        textView.isScrollEnabled = false
        textView.delegate = context.coordinator
        textView.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        textView.setContentCompressionResistancePriority(.defaultLow, for: .vertical)
        textView.textContainerInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        textView.backgroundColor = .clear
        
        let tapGesture = UITapGestureRecognizer(target: context.coordinator, action: #selector(context.coordinator.handleTapGesture(_:)))
        tapGesture.delegate = context.coordinator
        
        tapGesture.isEnabled = true
        
        textView.addGestureRecognizer(tapGesture)

        // TODO: temporary disabled (minor)
        // context.coordinator.textViewDidChange(textView)

        let keyboardToolbarUIHostingController = UIHostingController(rootView: renderKeyboardToolbar())
        let keyboardToolbarView = keyboardToolbarUIHostingController.view!
        keyboardToolbarView.translatesAutoresizingMaskIntoConstraints = false
        keyboardToolbarView.sizeToFit()
        keyboardToolbarView.backgroundColor = .clear
        textView.inputAccessoryView = keyboardToolbarUIHostingController.view
        NSLayoutConstraint.activate([
            keyboardToolbarView.centerXAnchor.constraint(equalTo: textView.inputAccessoryView!.centerXAnchor),
            keyboardToolbarView.centerYAnchor.constraint(equalTo: textView.inputAccessoryView!.centerYAnchor),
        ])
        
        textView.attributedText = attributedText
        textView.text = attributedText.string
        
        DispatchQueue.main.async {
            context.coordinator.adjustHeight(textView)
        }
        
        return textView
    }
    
    func updateUIView(_ uiView: UITextView, context: Context) {
        guard let textView = uiView as? AttributedUITextView else { return }
        
        textView.highlightColor = highlightColor
        textView.highlightedRange = highlightedRange
        
        textView.isEditable = mode != .HighlightParagraph
        textView.isSelectable = mode != .HighlightParagraph
        
        textView.font = font
        textView.textColor = UIColor { (traitCollection) -> UIColor in
            return traitCollection.userInterfaceStyle == .dark ? UIColor.white : UIColor.black
        }

        DispatchQueue.main.async {
            if self.isFocused && !uiView.isFirstResponder {
                uiView.becomeFirstResponder()
            } else if !self.isFocused && uiView.isFirstResponder {
                uiView.resignFirstResponder()
            }
        }
        
        /*
         if highlightedRange == nil {
         textView.highlightedRange = nil
         
         let mutableAttributedString = NSMutableAttributedString(attributedString: textView.attributedText)
         mutableAttributedString.removeAttribute(.backgroundColor, range: NSRange(location: 0, length: mutableAttributedString.length))
         mutableAttributedString.removeAttribute(.foregroundColor, range: NSRange(location: 0, length: mutableAttributedString.length))
         textView.attributedText = mutableAttributedString
         }
         */
    }
}

extension UITextView {
    func nsRange(from textRange: UITextRange) -> NSRange? {
        let location = offset(from: beginningOfDocument, to: textRange.start)
        let length = offset(from: textRange.start, to: textRange.end)
        return NSRange(location: location, length: length)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environment(ThemeManager.shared)
    }
}

struct ContentView: View {
    @Environment(ThemeManager.self) private var themeManager
    
    @State private var attributedText: NSAttributedString
    @State private var dynamicHeight: CGFloat = 100
    @State private var highlightedRange: NSRange?
    @State private var highlightColor: UIColor? = UIColor.accent
    @State private var mode: AttributedTextMode = .Edit
    
    init() {
        let initialAttributedString = NSAttributedString(string: "In this tutorial, you’ve learned how to use the UIViewRepresentable protocol to integrate UIKit views with SwiftUI.\n\nWhile SwiftUI is still very new and doesn’t come with all the standard UI components, this backward compatibility allows you to tap into the old framework and utilize any views you need.")
        _attributedText = State(initialValue: initialAttributedString)
    }
    
    var body: some View {
        ScrollView {
            AttributedTextView(attributedText: $attributedText,
                               dynamicHeight: $dynamicHeight,
                               highlightedRange: $highlightedRange,
                               highlightColor: $highlightColor,
                               mode: $mode,
                               isFocused: .constant(false),
                               font: UIFont.systemFont(ofSize: 16),
                               renderKeyboardToolbar: {
                AnyView (
                    ZStack {
                        KeyboardToolbar(onSectionTap: {}, onHashtagTap: {}, onGenerateTap: {}, onRhymeTap: {}, onRestyleTap: {})
                    }
                        .frame(maxWidth: .infinity)
                        .padding()
                )
            },
                               onSizeAdjusted: {},
                               onToolBarButtonTap: {},
                               onParagraphSelected: { _ in })
            .frame(minHeight: dynamicHeight)
            .padding()
            .background(Color.gray.opacity(0.1))
            .cornerRadius(10)
            .padding()
            
            Spacer()
            
            Text(attributedText.string)
                .lineLimit(1)
            Text(dynamicHeight.description)
            Text(highlightedRange?.description ?? "")
            Text(highlightedText ?? "")
            
            // Example of modifying the attributed text
            Button("Update Text") {
                let newString = "Updated attributed string!"
                attributedText = NSAttributedString(string: newString)
            }
            .padding()
            
            Button("Clear") {
                highlightedRange = nil
            }
            .padding()
            
            Button("Switch Mode") {
                if mode == .Edit {
                    mode = .HighlightParagraph
                } else {
                    mode = .Edit
                }
            }
            .padding()
        }
    }
    
    private var highlightedText: String? {
        guard let range = highlightedRange else { return nil }
        guard range.location != NSNotFound && range.length != 0 else { return nil }
        
        let attributedString = attributedText.attributedSubstring(from: range)
        return attributedString.string
    }
}
