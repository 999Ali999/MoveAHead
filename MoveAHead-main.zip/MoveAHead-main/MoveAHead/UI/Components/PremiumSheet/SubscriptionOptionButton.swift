//
//  SubscriptionOptionButton.swift
//  MoveAHead
//
//  Created by Felix Parey on 21/06/24.
//

import SwiftUI

struct RecommendedView: View {
    
    @Environment(ThemeManager.self) private var themeManager
    
    var body: some View {
        HStack(spacing: 5){
            Image(systemName: "star.fill")
                .foregroundStyle(.yellow.gradient)
            Text("Recommended")
                .textCase(.uppercase)
                .foregroundStyle(themeManager.selectedTheme.bodyTextColor)
                
        }
        .font(.footnote)
        .fontWeight(.semibold)
    }
}

struct SubscriptionOptionButton: View {
    
    @State var viewModel: PremiumViewModel
    @Environment(ThemeManager.self) private var themeManager
    
    var subscriptionType: SubscriptionType
    var title: String
    var monthlyPrice: Double
    var annualPrice: Double?
    var isRecommended: Bool
    
    var body: some View {
                HStack{
                    VStack(alignment: .leading, spacing: 5){
                        HStack{
                            Text(title)
                                .font(.title3)
                                .bold()
                                .foregroundStyle(themeManager.selectedTheme.bodyTextColor)
                            Spacer()
                            if subscriptionType == .Annual{
                                Text("Save 16%")
                                    .font(.footnote)
                                    .foregroundStyle(.white)
                                    .padding(5)
                                    .fontWeight(.semibold)
                                    .background(viewModel.selectedSubscriptionType == subscriptionType ? viewModel.premiumGradient : LinearGradient(colors: [.secondary], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 7))
                            }
                            
                        }
                        switch subscriptionType {
                        case .Annual:
                            Text("$\(String(format: "%.2f", monthlyPrice))/month billed annually.\nCompared to $\(String(format: "%.2f", viewModel.subscriptionOptionDetails[1].monthlyPrice))/month when billed monthly")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        case .Monthly:
                            Text("$\(String(format: "%.2f", monthlyPrice))/month billed annually.\nCompared to $\(String(format: "%.2f", viewModel.subscriptionOptionDetails[0].monthlyPrice))/month when billed annually")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        if isRecommended{
                            RecommendedView()
                        }
                        
                    }
                    Spacer()
                }
                .padding(.vertical, 10)
                .padding(.leading, 15)
                .frame(maxWidth: .infinity - 10)
                .background(themeManager.selectedTheme.gray1)
                .clipShape(RoundedRectangle(cornerRadius: 15))
                .overlay {
                    RoundedRectangle(cornerRadius: 15)
                        .stroke(style: .init(lineWidth: 3))
                        .foregroundStyle(viewModel.selectedSubscriptionType == subscriptionType ? viewModel.premiumGradient : LinearGradient(colors: [.clear], startPoint: .topLeading, endPoint: .bottom))
                }
                .onTapGesture {
                    if viewModel.selectedSubscriptionType == self.subscriptionType{
                        
                    } else {
                        viewModel.selectedSubscriptionType = self.subscriptionType
                    }
                }
                .padding(.horizontal)
            
        
        
        
    }
}

//#Preview {
//    SubscriptionOptionButton(title: "Lyrica Annual Plan", description: "ANNUAL_PRICE/year because santi didnt pay back his debts thats why its so expendive", MonthlyPrice: 4.20, annualPrice: 69.69, isSelected: true, isRecommended: true)
//        .environment(ThemeManager())
//}
