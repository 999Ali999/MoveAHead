//
//  PremiumProgressButton.swift
//  MoveAHead
//
//  Created by Felix Parey on 22/06/24.
//

import SwiftUI

struct PremiumProgressButton: View {
    
    @State var viewModel: PremiumViewModel
    
    var body: some View {
        
        VStack{
            if viewModel.premiumScreenType == .Purchase{
                switch viewModel.selectedSubscriptionType {
                case .Annual:
                    Text("Billing starts after 7 day trial for $\(String(format: "%.2f", viewModel.subscriptionOptionDetails[0].annualPrice!))/year until cancelled.")
                        .font(.caption2)
                case .Monthly:
                    Text("Billing starts after 7 day trial for $\(String(format: "%.2f", viewModel.subscriptionOptionDetails[1].monthlyPrice))/month until cancelled.")
                        .font(.caption2)
                }
            }
            Button {
                if viewModel.premiumScreenType == .Info{
                    viewModel.premiumScreenType = .Purchase
                } else {
                    print("Show in app purchase screen")
                }
            } label: {
                Text(viewModel.premiumScreenType == .Info ? "Become a Premium Member" : "Start 7 day free trial now")
                    .foregroundStyle(.white)
                    .fontWeight(.semibold)
                    .frame(maxWidth: .infinity)
                    .frame(height: 55)
                    .background(viewModel.premiumGradient, in: RoundedRectangle(cornerRadius: 15))
                    .padding(.horizontal)
            }
        }

    }
}

#Preview {
    PremiumProgressButton(viewModel: .init())
}
