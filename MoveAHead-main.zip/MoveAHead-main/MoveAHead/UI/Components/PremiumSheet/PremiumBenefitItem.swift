//
//  PremiumBenefitItem.swift
//  MoveAHead
//
//  Created by Felix Parey on 21/06/24.
//

import SwiftUI

struct PremiumBenefitItem: View {
    
    var iconName: String
    var title: String
    var description: String
    
    @Environment(ThemeManager.self) private var themeManager
    
    var body: some View {
        
        HStack(spacing: 15){
            Image(systemName: iconName)
                .foregroundStyle(PremiumViewModel().premiumGradient)
                .font(.title)
                .frame(width: 45)
            
            VStack(alignment: .leading){
                Text(title)
                    .foregroundStyle(themeManager.selectedTheme.bodyTextColor)
                    .font(.headline)
                    .bold()
                Text(description)
                    .foregroundStyle(.secondary)
                    .font(.caption)
            }
            Spacer()
        }
        .padding(12)
        .frame(maxWidth: .infinity)
        .background(themeManager.selectedTheme.gray1, in: RoundedRectangle(cornerRadius: 15))
        .padding(.horizontal)
        
    }
}

#Preview {
    ZStack{
        BodyBackgroundView()
        PremiumBenefitItem(iconName: "mic.fill", title: "Pencil whatever", description: "Santo thinks he is a boy but in reality he is not a boy but rather a girl")
           
    }
    .environment(ThemeManager.shared)
}
