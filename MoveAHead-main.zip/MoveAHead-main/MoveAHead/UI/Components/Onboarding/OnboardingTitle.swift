//
//  OnboardingTitle.swift
//  MoveAHead
//
//  Created by Felix Parey on 06/06/24.
//

import SwiftUI

struct OnboardingTitle: View {
    
    @Environment(ThemeManager.self) private var themeManager
    @State var viewModel: OnboardingView.ViewModel
    
    var body: some View {
        HStack{
            VStack(alignment: .leading, spacing: -5) {
                Text(viewModel.onboardingState == .Info ? "Welcome to" : "Benefits of an")
                    .foregroundStyle(themeManager.selectedTheme.bodyTextColor)
                Text(viewModel.onboardingState == .Info ? "Lyrica" : "Account")
                    .foregroundStyle(.accent)
                    .offset(x: 5.0)
            }
            .font(.system(size: 50))
            .fontWeight(.black)
            
            Spacer()
        }
        .padding(.horizontal)
    }
}

#Preview {
    OnboardingTitle(viewModel: .init(onboardingState: .Info))
}
