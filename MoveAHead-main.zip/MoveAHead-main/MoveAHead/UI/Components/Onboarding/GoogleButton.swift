//
//  GoogleButton.swift
//  MoveAHead
//
//  Created by Felix Parey on 06/06/24.
//

import SwiftUI

struct GoogleButton: View {
    
    @Environment(ThemeManager.self) private var themeManager
    @Binding var firstTimeAppLaunched: Bool
    
    var body: some View {
        Button {
            //TODO: Implement sign in with Google Logic
            firstTimeAppLaunched = false
        } label:{
            HStack{
                Image(.googleLogo)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .padding(.vertical, 20)
                Text("Continue with Google")
            }
                .font(.title3)
                .fontWeight(.semibold)
                .foregroundStyle(.black)
                .frame(maxWidth: .infinity)
                .frame(height: 55)
                .background(.white, in: RoundedRectangle(cornerRadius: 15))
                .padding(.horizontal)
        }
    }
}

#Preview{
    GoogleButton(firstTimeAppLaunched: .constant(true))
}

