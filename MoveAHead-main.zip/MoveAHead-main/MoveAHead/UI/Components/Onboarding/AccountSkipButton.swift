//
//  AccountSkipButton.swift
//  MoveAHead
//
//  Created by Felix Parey on 06/06/24.
//

import SwiftUI

struct AccountSkipButton: View {
    
    @State var viewModel: OnboardingView.ViewModel
    @Binding var firstTimeAppLaunched: Bool
    
    var body: some View {
        Button("Skip") {
            viewModel.alertPresented = true
        }
        .alert("Continue without Account?", isPresented: $viewModel.alertPresented) {
            
            Button("Continue without Sign up", role: .destructive) {
                firstTimeAppLaunched = false
            }
            
            Button("Cancel", role: .cancel) {
            }
            
        } message: {
            Text("When you are not signed up, your data will not be stored across your devices. You can sign in any time later in settings.")
        }

    }
}

#Preview {
    AccountSkipButton(viewModel: .init(onboardingState: .SingIn), firstTimeAppLaunched: .constant(true))
}
