//
//  MailButton.swift
//  MoveAHead
//
//  Created by Felix Parey on 06/06/24.
//

import SwiftUI

struct MailButton: View {
    
    @Environment(ThemeManager.self) private var themeManager
    @Binding var firstTimeAppLaunched: Bool
    
    var body: some View {
        Button{
            
            //TODO: Implement UI for E-Mail
            firstTimeAppLaunched = false
            
        } label:{
            HStack{
                Image(systemName: "envelope")
                Text("Continue with E-Mail")
            }
            .font(.title3)
            .fontWeight(.semibold)
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .frame(height: 55)
            .background(.accent, in: RoundedRectangle(cornerRadius: 15))
            .padding(.horizontal)
        }
        
    }
}

#Preview{
    MailButton(firstTimeAppLaunched: .constant(true))
}
