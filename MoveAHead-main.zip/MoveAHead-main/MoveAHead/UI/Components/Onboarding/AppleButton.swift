//
//  AppleButton.swift
//  MoveAHead
//
//  Created by Felix Parey on 06/06/24.
//

import SwiftUI
import _AuthenticationServices_SwiftUI
import FirebaseAuth

struct AppleButton: View {
    @EnvironmentObject var authModel: AuthModel
    @Environment(AlbumsView.ViewModel.self) private var albumsViewModel
    @Binding var firstTimeAppLaunched: Bool
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        Button {
            Task {
                await authModel.signInWithAppleID()
                firstTimeAppLaunched = false
                dismiss()
            }
        } label: {
            Text("Sign in with Apple")
        }
        .frame(height: 55)
        .clipShape(RoundedRectangle(cornerRadius: 15))
        .padding(.horizontal)
    }
}

#Preview{
    AppleButton(firstTimeAppLaunched: .constant(true))
}
