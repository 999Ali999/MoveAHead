//
//  Toast.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 11/06/24.
//

import SwiftUI

struct ToastView: View {
    @Environment(ThemeManager.self) private var themeManager
    @Environment(\.colorScheme) private var colorScheme
    var message: String

    var body: some View {
        Text(message)
            .foregroundColor(themeManager.selectedTheme.bodyTextColor)
            .padding()
            .background(colorScheme == .light ? .ultraThickMaterial : .ultraThinMaterial)
            .cornerRadius(10)
            .padding(.horizontal, 20)
            .frame(maxWidth: .infinity)
    }
}
import SwiftUI

struct ToastModifier: ViewModifier {
    @Binding var isShowing: Bool
    var message: String

    func body(content: Content) -> some View {
        ZStack {
            content
            if isShowing {
                VStack {
                    
                    withAnimation {
                        ToastView(message: message)
                            .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                }
                .onAppear {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                        withAnimation {
                            self.isShowing = false
                        }
                    }
                }
            }
        }
    }
}

extension View {
    func toast(isShowing: Binding<Bool>, message: String) -> some View {
        self.modifier(ToastModifier(isShowing: isShowing, message: message))
    }
}
