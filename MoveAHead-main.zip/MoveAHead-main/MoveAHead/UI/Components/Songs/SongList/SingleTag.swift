//
//  SingleTag.swift
//  MoveAHead
//
//  Created by Felix Parey on 18/05/24.
//

import SwiftUI

struct SingleTag: View {
    
    @Environment(ThemeManager.self) private var themeManager
    var tag: String
    @Binding var selectedTags: [String]
    
    var body: some View {
        Text(tag)
            .padding(8)
            .foregroundStyle(selectedTags.contains(tag) ? .white : themeManager.selectedTheme.bodyTextColor)
            .background(selectedTags.contains(tag) ? .accent : .gray1, in: RoundedRectangle(cornerRadius: 8))
            .onTapGesture {
            if tag == "All Tags" {
                if let index = selectedTags.firstIndex(of: tag) {
                    selectedTags.remove(at: index)
                } else {
                    selectedTags = []
                    selectedTags.append(tag)
                }
            } else {
                if let index = selectedTags.firstIndex(of: tag) {
                    selectedTags.remove(at: index)
                } else {
                    selectedTags.append(tag)
                }
            }
        }
    }
}

#Preview {
    SingleTag(tag: "Hello", selectedTags: .constant([]))
        .preferredColorScheme(.dark)
}
