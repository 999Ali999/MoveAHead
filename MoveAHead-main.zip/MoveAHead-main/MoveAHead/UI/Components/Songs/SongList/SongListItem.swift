//
//  SongListItem.swift
//  MoveAHead
//
//  Created by Felix Parey on 17/05/24.
//

import SwiftUI

struct SongListItem: View {
    @Environment(ThemeManager.self) private var themeManager
    
    var id: String?
    var name: String?
    var description: String?
    var createdOn: Date?
    var totalLines: Int?
    
    var body: some View {
        VStack(alignment: .leading) {
            Text((name!.isEmpty ? "New Song" : name) ?? "")
                .font(.title2)
                .lineLimit(1)
                .bold()
                .truncationMode(.tail)
            
            HStack(alignment: .top) {
                Text(description ?? "No text yet")
                    .font(.body)
                    .lineLimit(2)
                    .truncationMode(.tail)
                Spacer()
                VStack {
                    Spacer()
                    Text("\(totalLines?.description ?? "") lines")
                        .font(.footnote)
                        .foregroundColor(.gray)
                }
            }
            .padding(.bottom, 4)
            
            Divider()
                .background(Color.white)
                .padding(.bottom, 4)
            
            Text(createdOn ?? Date.now, style: .date)
                .font(.footnote)
                .foregroundColor(.gray)
        }
        .padding(.vertical)
        .background(themeManager.selectedTheme.gray1)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .padding(.horizontal)
    }
}

#Preview {
    SongListItem()
        .preferredColorScheme(.dark)
        .environment(ThemeManager.shared)
}
