//
//  TagsFilter.swift
//  MoveAHead
//
//  Created by Felix Parey on 18/05/24.
//

import SwiftUI

struct TagsFilter: View {
    var tags: [String]
    @Binding var selectedTags: [String]
    
    var body: some View {
        ScrollView(.horizontal) {
            LazyHStack{
                SingleTag(tag: "All Tags", selectedTags: $selectedTags)
                ForEach(tags, id: \.self){ tag in
                    SingleTag(tag: tag, selectedTags: $selectedTags)
                }
            }
        }
    }
}

#Preview {
    TagsFilter(tags: [], selectedTags: .constant([]))
        .preferredColorScheme(.dark)
}
