//
//  ChordList.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 13/05/24.
//

import SwiftUI

struct ChordList: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    ChordList()
}
