//
//  KeyboardToolbar.swift
//  MoveAHead
//
//  Created by Felix Parey on 25/05/24.
//

import SwiftUI

extension View {
    func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}


public enum ToolBarType{
    case AllTools
    case Rhymes
}

struct KeyboardToolbar_: View {
    
    @State var viewModel: EditSongView.ViewModel
    @State var toolBarType: ToolBarType = .AllTools
    @State var foundRhymes: [String]?
    @State var hasTappedWord = false
    
    var body: some View {
        
        if toolBarType == .AllTools{
            Button {
                hideKeyboard()
                viewModel.toolSheetPresented = true
            } label: {
                Label(
                    title: { Text("Add Section") },
                    icon: { Image(systemName: "square.fill.text.grid.1x2") }
                )
                .labelStyle(.iconOnly)
            }
            Spacer()
            Button {
                
                
            } label: {
                Label(
                    title: { Text("Add Tag") },
                    icon: { Image(systemName: "number") }
                )
                .labelStyle(.iconOnly)
            }
            Spacer()
            Button {
                withAnimation {
                    toolBarType = .Rhymes
                }
            } label: {
                Label(
                    title: { Text("Find Rhyme") },
                    icon: { Image(systemName: "music.mic") }
                )
                .labelStyle(.iconOnly)
            }
            
            Spacer()
            Button {
                
            } label: {
                Label(
                    title: { Text("Restyle Line") },
                    icon: { Image(systemName: "pencil.and.outline") }
                )
                .labelStyle(.iconOnly)
            }
            Spacer()
            Button {
                
            } label: {
                Label(
                    title: { Text("Generate Line") },
                    icon: { Image(systemName: "text.line.last.and.arrowtriangle.forward") }
                )
                .labelStyle(.iconOnly)
            }
            
            
        }else if toolBarType == .Rhymes{
            Button {
                toolBarType = .AllTools
                hasTappedWord = false
                self.foundRhymes = nil
                
            } label: {
                Image(systemName: "arrow.backward")
            }
            if let foundRhymes = foundRhymes{
                ScrollView(.horizontal) {
                    LazyHStack{
                        ForEach(foundRhymes, id: \.self) { rhyme in
                            Button {
                                hasTappedWord = false
                                self.foundRhymes = nil
                            } label: {
                                Text(rhyme)
                                    .padding(5)
                                    .padding(.horizontal, 5)
                                    .background(.gray2)
                                    .clipShape(Capsule())
                            }
                            .buttonStyle(.plain)
                            
                        }
                    }
                }
                .scrollIndicators(.never)
            }else{
                if hasTappedWord{
                    Text("Waiting for results...")
                        .foregroundStyle(.tertiary)
                    Spacer()
                }else{
                    Text("Tap word to find a rhyme for")
                        .foregroundStyle(.primary)
                    //TODO: Need to implement actual tapping on text logic
                        .onTapGesture {
                            hasTappedWord = true
                            foundRhymes = ["Yellow", "Jello", "Marshmallow", "Helo", "Alexello", "Santiello"]
                        }
                    Spacer()
                }
                
            }
            
            
            
        }
    }
}

#Preview {
    KeyboardToolbar_(viewModel: EditSongView.ViewModel(songId: "GSDVSVDZSD", songFolderId: "AvgVASGVsgva"))
}
