//
//  LyricsEditor.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 13/05/24.
//
import UIKit
import SwiftUI
import Combine

class HighlightView: UIView {
    var highlightColor: UIColor?
    
    override func draw(_ rect: CGRect) {
        let path = UIBezierPath(roundedRect: rect, cornerRadius: 5)
        highlightColor?.setFill()
        path.fill()
    }
}

public class RichTextView: UITextView {
    var highlightedRange: NSRange?
    
    override public func draw(_ rect: CGRect) {
        super.draw(rect)
    }
    
    ///  Set the selected range in the text view.
    open func setSelectedRange(_ range: NSRange) {
        selectedRange = range
    }
    
    override public func layoutSubviews() {
        super.layoutSubviews()
    }
}

public protocol RichTextViewRepresentable {
    var attributedString: NSAttributedString { get }
    var mutableAttributedString: NSMutableAttributedString? { get }
}

extension RichTextView: RichTextViewRepresentable {
    public var mutableAttributedString: NSMutableAttributedString? {
        textStorage
    }
}

public extension RichTextView {
    
    var attributedString: NSAttributedString {
        get { attributedText ?? NSAttributedString(string: "") }
        set { attributedText = newValue }
    }
}

typealias ViewRepresentable = UIViewRepresentable

public struct RichTextEditor: ViewRepresentable {
    public let textView = RichTextView()
    
    private var text: Binding<NSAttributedString>
    
    @ObservedObject
    private var richTextContext: RichTextContext

    public init(text: Binding<NSAttributedString>, context: RichTextContext) {
        self.text = text
        self._richTextContext = ObservedObject(wrappedValue: context)
    }
    
    public func makeUIView(context: Context) -> some UIView {
        textView.isEditable = true
        
        textView.layoutManager.showsInvisibleCharacters = false
        textView.layoutManager.showsControlCharacters = false
        
        textView.font = .systemFont(ofSize: 18)
        textView.textColor = .white
        textView.backgroundColor = .clear
        
        textView.textContainerInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        
        textView.isScrollEnabled = false
        textView.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        textView.setContentCompressionResistancePriority(.defaultLow, for: .vertical)
        
        return textView
    }
    
    public func makeCoordinator() -> RichTextCoordinator {
        RichTextCoordinator(text: text, textView: textView, context: richTextContext)
    }

    public func updateUIView(_ view: UIViewType, context: Context) {}
}

public extension RichTextEditor {
    /// Get the currently selected range.
    var selectedRange: NSRange {
        textView.selectedRange
    }
}

open class RichTextCoordinator: NSObject {
    public var text: Binding<NSAttributedString>
    public private(set) var textView: RichTextView
    public var context: RichTextContext
    
    var highlightView: HighlightView?
    var highlightedRange: NSRange?
    var originalTextAttributes: [NSAttributedString.Key: Any] = [:]
    
    /**
     The background color that was used before the currently
     highlighted range was set.
     */
    var highlightedRangeOriginalBackgroundColor: UIColor?

    /**
     The foreground color that was used before the currently
     highlighted range was set.
     */
     var highlightedRangeOriginalForegroundColor: UIColor?
    
    public var cancellables = Set<AnyCancellable>()
    
    public init(text: Binding<NSAttributedString>, textView: RichTextView, context: RichTextContext) {
        textView.attributedString = text.wrappedValue
        self.text = text
        self.textView = textView
        self.context = context
 
        super.init()
        
        self.textView.delegate = self
        
        subscribeToContextChanges()
        self.syncWithTextView()
        
        NotificationCenter.default.addObserver(self,
                                      selector: #selector(orientationDidChange),
                    name: UIDevice.orientationDidChangeNotification, object: nil)
        
        self.textView.addObserver(self, forKeyPath: "frame", options: [.old, .new], context: nil)
    }
    
    open override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if let textView = object as? UITextView, (keyPath == "frame" || keyPath == "bounds") {
            // TODO: remove?
        }
    }
    
    // TODO: remove
    deinit {
        
    }
    
    open func textViewDidChange(_ textView: UITextView) {
        syncWithTextView()
    }

    open func textViewDidChangeSelection(_ textView: UITextView) {
        syncWithTextView()
    }
    
    open func textViewDidBeginEditing(_ textView: UITextView) {
        // TODO: Need identify in docs
    }
    
    open func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        syncWithTextView()
         
        // TODO: Nees set conditional flag to switch from editing text to selecting line
        return context.isEditable
    }
    
    open func scrollViewDidChangeAdjustedContentInset(_ scrollView: UIScrollView) {
        print("scrollViewDidChangeAdjustedContentInset")
    }
    
    open override func performSelector(inBackground aSelector: Selector, with arg: Any?) {
        print("performSelector")
    }
    
    @objc func orientationDidChange(_ notification: Notification) {
        updateTextViewLayout(for: UIDevice.current.orientation)
    }
    
    func updateTextViewLayout(for orientation: UIDeviceOrientation) {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
            self.syncWithTextView()
        }
    }
}

private extension RichTextCoordinator {
    
    func subscribeToContextChanges() {
        subscribeToIsUnderlined()
        subscribeToSelectedTextLine()
    }

    func subscribeToIsUnderlined() {
        context.$isUnderlined
            .sink(
                receiveCompletion: { _ in },
                receiveValue: { [weak self] in self?.setIsUnderlined(to: $0) })
            .store(in: &cancellables)
    }
    
    func subscribeToSelectedTextLine() {
        context.$isLineSelected
            .sink(receiveCompletion: { _ in }, receiveValue: { [weak self] in self?.setHighlightedText($0) })
            .store(in: &cancellables)
    }

    func setIsUnderlined(to newValue: Bool) {
        let string = textView.attributedString
        let attributes = string.textAttributes(at: textView.selectedRange)
        let isUnderlined = (attributes[.underlineStyle] as? Int) == 1
        if newValue == isUnderlined { return }
        let value = NSNumber(value: newValue)
        textView
            .mutableAttributedString!
            .setTextAttribute(.underlineStyle, to: value, at: textView.selectedRange)
    }
    
    func setHighlightedText(_ isLineSelected: Bool) {
        resetHighlight()
        
        guard let nsRange = context.selectedLineRange, context.highlightedRange?.location != nsRange.location && context.highlightedRange?.length != nsRange.length else { return }

        context.highlightedRange = nsRange

        // Store the original text attributes
        if let originalAttributedString = textView.attributedText?.attributedSubstring(from: nsRange) {
            self.originalTextAttributes = [.foregroundColor: originalAttributedString]
        }
        
        if let textRange = textRange(from: textView.beginningOfDocument, offset: nsRange.location, length: nsRange.length) {
            // Change the background color to .accent
            let rect = textView.firstRect(for: textRange)
            let highlightView = HighlightView(frame: rect)
            highlightView.highlightColor = .accent
            highlightView.layer.cornerRadius = 5
            highlightView.clipsToBounds = true
            highlightView.backgroundColor = .clear
            highlightView.layer.zPosition = -1
            
            self.highlightView = highlightView
            textView.addSubview(highlightView)
            
            textView.selectionRects(for: textRange).forEach { rect in }
            
            // Change the text color to .white
            /*
            let attributedString = NSMutableAttributedString(attributedString: self.textView.attributedText)
            attributedString.addAttribute(.foregroundColor, value: UIColor.white, range: nsRange)
            self.textView.attributedText = attributedString
            */
        }
    }
    
    func resetHighlight() {
        // Remove layer (subview)
        highlightView?.removeFromSuperview()

        // Restore attributes of the text
        if let range = highlightedRange {
            let attributedString = NSMutableAttributedString(attributedString: textView.attributedText)
            attributedString.setAttributes(originalTextAttributes, range: range)
            textView.attributedText = attributedString
        }
    }
    
    private func textRange(from start: UITextPosition, offset: Int, length: Int) -> UITextRange? {
        if let startPosition = textView.position(from: start, offset: offset),
           let endPosition = textView.position(from: startPosition, offset: length) {
            return textView.textRange(from: startPosition, to: endPosition)
        }
        return nil
    }
}

extension RichTextCoordinator: UITextViewDelegate {}

private extension RichTextCoordinator {
    func syncWithTextView() {
        syncContextWithTextView()
        syncTextWithTextView()
        adjustTextViewSize()
    }
    
    func adjustTextViewSize() {
        DispatchQueue.main.async {
            self.context.dynamicHeight = self.textView.sizeThatFits(
                CGSize(width: self.textView.frame.width, height: .greatestFiniteMagnitude)
            ).height
        }
    }

    func syncTextWithTextView() {
        if text.wrappedValue == textView.attributedString { return }
        text.wrappedValue = textView.attributedString
    }
    
    func syncContextWithTextView() {
        let string = textView.attributedString
        let attributes = string.textAttributes(at: textView.selectedRange)
        let isUnderlined = (attributes[.underlineStyle] as? Int) == 1

        context.isUnderlined = isUnderlined
        
        let selectedString = extractTextAroundCaret(from: textView)
        context.isLineSelected = selectedString != nil
        
        if let selectedString = selectedString {
            context.selectedLine = selectedString
        }
    }
    
    func extractTextAroundCaret(from textView: UITextView) -> String? {
        guard let text = textView.text, let selectedRange = textView.selectedTextRange else {
            return nil
        }
        
        let caretPosition = selectedRange.end
        let caretPositionIndex = textView.offset(from: textView.beginningOfDocument, to: caretPosition)
        
        let beforeRange = text.startIndex..<text.index(text.startIndex, offsetBy: caretPositionIndex)
        let precedingNewlineRange = text.range(of: "\n", options: .backwards, range: beforeRange)

        let afterRange = text.index(text.startIndex, offsetBy: caretPositionIndex)..<text.endIndex
        let followingNewlineRange = text.range(of: "\n", options: [], range: afterRange)
        
        let start = precedingNewlineRange?.upperBound ?? text.startIndex
        let end = followingNewlineRange?.lowerBound ?? text.endIndex
        
        let substring = String(text[start..<end])

        // Convert the Swift range to NSRange
        let nsRange = NSRange(start..<end, in: text)
        context.selectedLineRange = nsRange

        // Set the selected range in the UITextView
        // TODO: can be implemented with native selection of the text, so it can be better for UX
        /*
        textView.selectedRange = nsRange
        */
        
        return substring
    }
}

extension RichTextCoordinator {
    /// Reset appearance for the currently highlighted range.
    func resetHighlightedRangeAppearance() {
        guard
            let range = context.highlightedRange,
            let background = highlightedRangeOriginalBackgroundColor,
            let foreground = highlightedRangeOriginalForegroundColor
        else { return }
    }
}

extension RichTextCoordinator {
    func setHighlightedRange(to range: NSRange?) {
        resetHighlightedRangeAppearance()
        guard let range = range else { return }
    }
}

public extension NSAttributedString {
    func safeRange(for range: NSRange) -> NSRange {
        NSRange(
            location: max(0, min(length-1, range.location)),
            length: min(range.length, max(0, length - range.location)))
    }
}

public extension NSAttributedString {
    func textAttribute<Value>(_ key: Key, at range: NSRange) -> Value? {
        textAttributes(at: range)[key] as? Value
    }

    func textAttributes(at range: NSRange) -> [Key: Any] {
        if length == 0 { return [:] }
        let range = safeRange(for: range)
        return attributes(at: range.location, effectiveRange: nil)
    }
}

public extension NSMutableAttributedString {
    func setTextAttribute(_ key: Key, to newValue: Any, at range: NSRange) {
        let range = safeRange(for: range)
        guard length > 0, range.location >= 0 else { return }
        beginEditing()
        enumerateAttribute(key, in: range, options: .init()) { value, range, _ in
            removeAttribute(key, range: range)
            addAttribute(key, value: newValue, range: range)
            fixAttributes(in: range)
        }
        endEditing()
    }
}

public class RichTextContext: ObservableObject {
    @Published
    public var isUnderlined = false
    
    @Published
    public var isLineSelected = false
    @Published
    public var selectedLine: String?
    @Published
    public var selectedLineRange: NSRange?
    @Published
    var dynamicHeight: CGFloat = 100
    
    /// The currently selected range, if any.
    public internal(set) var selectedRange = NSRange()

    /// The currently highlighted range, if any.
    public var highlightedRange: NSRange?
    
    public var isEditable: Bool = true
    
    public init() {}
}

struct RichTextViewWrapper: View {
    @State private var text: NSAttributedString = NSAttributedString(string: "We’re now ready to take the SwiftUI text editor for a test ride!\n\nIf we create a SwiftUI test app with a rich text binding and add a TextEditor to its content view, you’ll find that you can provide the editor with any rich text and type in the editor to edit the text.\n")
    
    @StateObject private var context = RichTextContext()
    
    var body: some View {
        NavigationStack {
            ScrollView {
                RichTextEditor(text: $text, context: context)
                    .cornerRadius(5)
                    .frame(height: context.dynamicHeight)
                    .border(Color.white)
                Spacer()
                
                if context.isLineSelected {
                    Text("\(context.selectedLine ?? "")")
                        .font(.footnote)
                        .padding()
                }
            }
            .padding()
            .background(Color.black)
        }
    }
}

#Preview {
    RichTextViewWrapper()
}
