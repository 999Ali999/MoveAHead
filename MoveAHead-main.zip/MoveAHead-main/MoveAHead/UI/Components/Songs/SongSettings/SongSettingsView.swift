//
//  SettingsView.swift
//  MoveAHead
//
//  Created by Santiago Torres Alvarez on 29/05/24.
//
import SwiftUI
import CoreHaptics

struct SongSettingsView: View {
    @Environment(ThemeManager.self) private var themeManager
    
    @StateObject var viewModel: SongSettingsViewModel
    @Binding var isSettingsShown: Bool
    
    @State private var removeUserTagConfirmDialogShown = false
    @State private var removedTag: String?
    
    @State private var engine: CHHapticEngine?
    
    @Namespace private var animation
    
    init(songEditorViewModel: SongEditorView.SongEditorViewModel, isSettingsShown: Binding<Bool>) {
        self._viewModel = StateObject(wrappedValue: SongSettingsViewModel(songEditorViewModel: songEditorViewModel))
        self._isSettingsShown = isSettingsShown
    }
    
    var body: some View {
        ZStack {
            themeManager.selectedTheme.bodyBackgroundColor
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                HStack(spacing: 0) {
                    Text("Song properties")
                        .bold()
                        .font(.title)
                        .foregroundStyle(themeManager.selectedTheme.bodyTextColor)
                        .padding(.top, 10)
                    
                    Spacer()
                    
                    Button(action: {
                        isSettingsShown = false
                    }, label: {
                        Image(systemName: "xmark.circle.fill")
                            .resizable()
                            .frame(width: 24, height: 24)
                            .foregroundColor(.gray.opacity(0.8))
                            .padding(.top, 10)
                    })
                }
                .padding(15)
                
                ScrollView(.vertical) {
                    Group {
                        HStack {
                            Text("Select a Genre")
                                .font(.title2)
                                .bold()
                                .foregroundStyle(.accent)
                                .padding(.leading, 15)
                            Spacer()
                        }
                        TagLayout(alignment: .leading, spacing: 10) {
                            ForEach(viewModel.tags, id: \.self) { tag in
                                TagView(tag: tag, isSelected: viewModel.selectedTags.contains(tag))
                                    .matchedGeometryEffect(id: tag, in: animation)
                                    .onTapGesture {
                                       // triggerHapticFeedback()
                                        viewModel.toggleTag(tag: tag)
                                    }
                            }
                        }
                        .padding([.horizontal, .bottom], 15)
                    }
                    
                    Group {
                        HStack {
                            Text("Select a Vibe")
                                .font(.title2)
                                .bold()
                                .foregroundStyle(.accent)
                                .padding(.leading, 15)
                            
                            Spacer()
                        }
                        TagLayout(alignment: .leading, spacing: 10) {
                            ForEach(viewModel.tagsVibe, id: \.self) { tag in
                                TagView(tag: tag, isSelected: viewModel.selectedTags.contains(tag))
                                    .matchedGeometryEffect(id: tag, in: animation)
                                    .onTapGesture {
                                       // triggerHapticFeedback()
                                        viewModel.toggleTag(tag: tag)
                                    }
                            }
                        }
                        .padding([.horizontal, .bottom], 15)
                    }
                    
                    if viewModel.userTags.count > 0 {
                        Group {
                            HStack {
                                Text("Custom tags")
                                    .font(.title2)
                                    .bold()
                                    .foregroundStyle(.accent)
                                    .padding(.leading, 15)
                                Spacer()
                            }
                            TagLayout(alignment: .leading, spacing: 10) {
                                ForEach(viewModel.userTags, id: \.self) { tag in
                                    TagView(tag: tag, isSelected: viewModel.selectedTags.contains(tag))
                                        .matchedGeometryEffect(id: tag + "-user-tag", in: animation)
                                        .onTapGesture {
                                           // triggerHapticFeedback()
                                            if viewModel.selectedTags.contains(tag) {
                                                removedTag = tag
                                                removeUserTagConfirmDialogShown = true
                                            }
                                        }
                                }
                            }
                            .padding([.horizontal, .bottom], 15)
                        }
                    }
                }
                .scrollClipDisabled(true)
                .scrollIndicators(.hidden)
                .clipped()
                
            }
            .onAppear(perform: prepareHaptics)
            .alert(isPresented: $removeUserTagConfirmDialogShown) {
                Alert(
                    title: Text("Delete Tag Confirmation"),
                    message: Text("You are about to delete the tag. Do you want to proceed?"),
                    primaryButton: .default(Text("Yes"), action: {
                        if let removedTag = removedTag {
                            viewModel.toggleTag(tag: removedTag)
                        }
                        removedTag = nil
                    }),
                    secondaryButton: .cancel(Text("Cancel"))
                )
            }
        }
    }
    
    func prepareHaptics() {
        guard CHHapticEngine.capabilitiesForHardware().supportsHaptics else { return }
        do {
            engine = try CHHapticEngine()
            try engine?.start()
        } catch {
            print("There was an error creating the engine: \(error.localizedDescription)")
        }
    }
    
    func triggerHapticFeedback() {
        guard CHHapticEngine.capabilitiesForHardware().supportsHaptics else { return }
        
        var events = [CHHapticEvent]()
        
        let intensity = CHHapticEventParameter(parameterID: .hapticIntensity, value: 1)
        let sharpness = CHHapticEventParameter(parameterID: .hapticSharpness, value: 1)
        let event = CHHapticEvent(eventType: .hapticTransient, parameters: [intensity, sharpness], relativeTime: 0)
        
        events.append(event)
        
        do {
            let pattern = try CHHapticPattern(events: events, parameters: [])
            let player = try engine?.makePlayer(with: pattern)
            try player?.start(atTime: 0)
        } catch {
            print("Failed to play pattern: \(error.localizedDescription).")
        }
    }
    
    @ViewBuilder
    func TagView(tag: String, isSelected: Bool) -> some View {
        HStack(spacing: 10) {
            Text(tag)
                .font(.callout)
                .fontWeight(.semibold)
        }
        .frame(height: 35)
        .foregroundStyle(isSelected ? .white : themeManager.selectedTheme.bodyTextColor)
        .padding(.horizontal, 15)
        .background(RoundedRectangle(cornerRadius: 10).fill(isSelected ? .accent : ThemeManager.shared.selectedTheme.gray2))
    }
}
