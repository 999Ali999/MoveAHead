//
//  RoundedButton.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 04/06/24.
//

import SwiftUI

struct RoundedButton: View {
    let iconName: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Image(systemName: iconName)
                .fontWeight(.semibold)
        }
        .padding(8)
        .frame(width: 34, height: 34)
        .background(Color("gray2"))
        .clipShape(Circle())
    }
}
