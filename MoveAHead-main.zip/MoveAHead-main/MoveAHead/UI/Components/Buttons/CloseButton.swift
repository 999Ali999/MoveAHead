//
//  CloseRoundedButton.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 04/06/24.
//

import SwiftUI

struct CloseButton: View {
    let action: () -> Void
    
    var body: some View {
        RoundedButton(iconName: "xmark", action: action)
            .foregroundStyle(Color("lightGray"))
    }
}
