//
//  RefreshButton.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 04/06/24.
//

import SwiftUI

struct RefreshButton: View {
    let action: () -> Void
    
    var body: some View {
        RoundedButton(iconName: "arrow.triangle.2.circlepath", action: action)
    }
}
