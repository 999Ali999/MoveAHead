//
//  BackButton.swift
//  MoveAHead
//
//  Created by Felix Parey on 22/06/24.
//

import SwiftUI

struct BackButton: View {
    let action: () -> Void
    
    var body: some View {
        RoundedButton(iconName: "chevron.backward", action: action)
            .foregroundStyle(PremiumViewModel().premiumGradient)
    }
}
