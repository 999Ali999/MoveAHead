//
//  FlatButtonStyle.swift
//  MoveAHead
//
//  Created by Felix Parey on 28/05/24.
//

import Foundation
import SwiftUI

struct FlatButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
    }
}
