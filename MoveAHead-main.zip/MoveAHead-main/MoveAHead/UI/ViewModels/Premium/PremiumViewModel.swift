//
//  PremiumViewModel.swift
//  MoveAHead
//
//  Created by Felix Parey on 21/06/24.
//

import Foundation
import SwiftUI

public enum PremiumScreenType{
    case Info, Purchase
}

public enum SubscriptionType{
    case Annual, Monthly
}

@Observable
class PremiumViewModel{

    var premiumGradient = LinearGradient(colors: [.premiumGradient1, .premiumGradient2], startPoint: .topLeading, endPoint: .bottom)
    var selectedSubscriptionType: SubscriptionType = .Annual
    var premiumScreenType: PremiumScreenType = .Info
    
    var subscriptionOptionDetails: [SubscriptionOptionDetails] = [
        .init(subscriptionType: .Annual, title: "Lyrica Premium Annual", isRecommended: true, monthlyPrice: 5.83, annualPrice: 69.99),
        .init(subscriptionType: .Monthly, title: "Lyrica Premium Monthly", isRecommended: false, monthlyPrice: 7.99)
    ]
    
    var premiumInfos: [PremiumInfo] = [
//        .init(iconName: "mic.fill", title: "Unlimited Audio Storage", description: "Store your audio in your songs for as many songs as you like."),
        .init(iconName: "pencil.and.outline", title: "Access to Restyle", description: "Use AI to restyle any line of your song to make it stand out"),
        .init(iconName: "text.line.first.and.arrowtriangle.forward", title: "AI Generate Next Line", description: "Use AI whenever you are stuck to get help in finding ideas on how to continue your song"),
//        .init (iconName: "music.mic", title: "Rhyme Generator", description: "Select a word and get rhymes for them in our pro editor."),
        .init (iconName: "number", title: "Unlimited Tags", description: "Get unlimited Tags for your songs helping you to customize AI features and filter for songs")
    ]
}

struct PremiumInfo: Identifiable {
    var id = UUID()
    var iconName: String
    var title: String
    var description: String
}

struct SubscriptionOptionDetails: Identifiable {
    var id = UUID()
    var subscriptionType: SubscriptionType
    var title: String
    var isRecommended: Bool
    var monthlyPrice: Double
    var annualPrice: Double?
}
