//
//  AlbumsViewModel.swift
//  MoveAHead
//
//  Created by Felix Parey on 21/05/24.
//

import Foundation
import SwiftUI
import FirebaseAuth

extension AlbumsView{
    
    @Observable
    final class ViewModel {
        
        static let icons = [
            "folder", "music.note",
            "music.note.list", "music.mic", "sun.max",
            "bolt", "metronome", "brain.head.profile",
            "headphones", "brain", "speaker.zzz.fill",
            "keyboard", "lightbulb", "pencil",
            "doc.append", "pencil.and.list.clipboard", "person",
            "person.2", "speaker", "book.pages"
        ]

        var songFolders: [SongFolder] = []
        var textSearch: String = ""
        
        var showSettingsCover = false
        var isAddSongFolderPopupPresented = false
        var addingSongFolderName = ""
        var addingSongIcon: String?
        
        @ObservationIgnored
        private var addingSongFolderDefaultName = "New Folder"
        
        @ObservationIgnored
        private var songFolderRepository: SongFolderRepositoryProtocol
        
        @ObservationIgnored
        private let recentlyDeletedFolderPrefix = "recently-deleted-"
        @ObservationIgnored
        private let allSongsFolderPrefix = "all-songs-"
        @ObservationIgnored
        private let singlesFolderPrefix = "singles-"
        
        @ObservationIgnored
        private let predefinedFoldersRepositoryImpl = PredefinedFoldersImpl.shared
        
        init(songFolderRepository: SongFolderRepositoryProtocol = FirestoreSongFolderRepositoryImpl.shared) {
            self.songFolderRepository = songFolderRepository
        }
        
        func fetchSongFolders() {
            print("fetchSongFolders")
            songFolderRepository.fetchSongFolders { result in
                DispatchQueue.main.async {
                    do {
                        let songFolders = try result.get()
                        let sortedSongFolders = self.sortPredefinedFolders(songFolders: songFolders)
                            .filter {
                                if $0.id.contains(self.recentlyDeletedFolderPrefix) && ($0.totalSongs ?? 0) == 0 {
                                    return false
                                }
                                return true
                            }
                        self.songFolders = sortedSongFolders
                    } catch {
                        print(error)
                    }
                }
            }
        }
        
        func addSongFolder() {
            let addingSongFolder = SongFolder(id: UUID().uuidString, createdOn: Date.now, name: addingSongFolderName, icon: addingSongIcon)
            
            songFolderRepository.addSongFolder(songFolder: addingSongFolder) { error in
                if let error = error {
                    print(error.localizedDescription)
                    return
                }
                self.addingSongIcon = "folder"
                self.hideAddSongFolderPopup()
            }
        }
        
        func removeSongFolder(songFolder: SongFolder) {
            let _ = withAnimation {
                self.songFolders.remove(at: self.songFolders.firstIndex(of: songFolder)!)
                
                if var allSongsFolder = self.songFolders.first(where: { $0.id.starts(with: allSongsFolderPrefix) }) {
                    allSongsFolder.totalSongs = (allSongsFolder.totalSongs ?? 0) - (songFolder.totalSongs ?? 0)
                    self.songFolders[self.songFolders.firstIndex(of: allSongsFolder)!] = allSongsFolder
                }
                
                if var recentlyDeletedFolder = self.songFolders.first(where: { $0.id.starts(with: recentlyDeletedFolderPrefix) }) {
                    recentlyDeletedFolder.totalSongs! += songFolder.totalSongs ?? 0
                    self.songFolders[self.songFolders.firstIndex(of: recentlyDeletedFolder)!] = recentlyDeletedFolder
                }
            } completion: {
                self.songFolderRepository.removeSongFolder(songFolder: songFolder) { error in
                    if let error = error {
                        print(error)
                        return
                    }
                }
            }
        }
        
        func showAddSongFolderPopup() {
            isAddSongFolderPopupPresented = true
            addingSongFolderName = addingSongFolderDefaultName
        }
        
        func hideAddSongFolderPopup() {
            isAddSongFolderPopupPresented = false
        }
        
        func sortPredefinedFolders(songFolders: [SongFolder]) -> [SongFolder] {
            return songFolders.sorted { (folder1, folder2) -> Bool in
                if folder1.id.starts(with: allSongsFolderPrefix) {
                    return true
                }
                if folder2.id.starts(with: allSongsFolderPrefix) {
                    return false
                }
                if folder1.id.starts(with: recentlyDeletedFolderPrefix) {
                    return false
                }
                if folder2.id.starts(with: recentlyDeletedFolderPrefix) {
                    return true
                }
                return folder1.name < folder2.name
            }
        }
        
        func isPredefinedFolder(_ songFolder: SongFolder) -> Bool {
            return songFolder.id.starts(with: recentlyDeletedFolderPrefix) || songFolder.id.starts(with: allSongsFolderPrefix) || songFolder.id.starts(with: singlesFolderPrefix)
        }
    }
    
}
