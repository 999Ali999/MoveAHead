//
//  SongsViewModel.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 14/05/24.
//

import Foundation
import SwiftUI
import Combine

extension SongsView {
    final class ViewModel: ObservableObject {
        @Published var songs: [SongFolderItem] = []
        
        @Published var searchText: String = ""
        @Published var selectedTags: [String] = []
        @Published var tags: [String] = []
        private var isInitialized = false
        private var songFilter: SongFilter = SongFilter(searchText: "", tags: [])
        
        var songFolder: SongFolder
        var selectedSong: Song?
        
        private var songFolderRepository: SongFolderRepositoryProtocol
        private var songRepository: SongRepositoryProtocol
            
        private var cancellables = Set<AnyCancellable>()
        private var searchTask: Task<Void, Never>? = nil
        
        init(songFolder: SongFolder, songFolderRepository: SongFolderRepositoryProtocol = FirestoreSongFolderRepositoryImpl.shared, songRepository: SongRepositoryProtocol = FirestoreSongRepositoryImpl.shared) {
            self.songFolder = songFolder
            self.songFolderRepository = songFolderRepository
            self.songRepository = songRepository
  
            $searchText
                .debounce(for: .milliseconds(300), scheduler: RunLoop.main)
                .removeDuplicates()
                .sink { searchText in
                    if self.isInitialized {
                        self.searchTask?.cancel()
                        self.searchTask = Task {
                            self.songFilter.searchText = searchText
                            self.fetchSongs()
                        }
                    } else {
                        self.isInitialized = true
                    }
                }
                .store(in: &cancellables)
        
            $selectedTags
                .sink { newValue in
                    self.songFilter.tags = newValue.filter({ $0 != "All Tags" })
                    self.fetchSongs()
                }
                .store(in: &cancellables)
            
            fetchSongs()
            fetchTags()
        }
        
        func fetchSongs() {
            songFolderRepository.fetchSongsByFolder(folderId: songFolder.id, filter: self.songFilter) { result in
                DispatchQueue.main.async {
                    do {
                        self.songs = try result.get()
                    } catch {
                        print(error)
                    }
                }
            }
        }
        
        func fetchTags() {
            DispatchQueue.main.async {
                self.songRepository.fetchAllTags { tags in
                    self.tags = tags
                }
            }
        }
        
        func addSong() {
            selectedSong = Song(id: UUID().uuidString, createdOn: Date.now, name: "New Song", songFolderId: songFolder.id)
        }
        
        func removeSong(songId: String?) {
            DispatchQueue.main.async {
                if let songId = songId {
                    let _ = withAnimation {
                        self.songs.remove(at: self.songs.firstIndex(where: { $0.id == songId })!)
                    } completion: {
                        self.songFolderRepository.removeSongFromFolder(songFolderId: self.songFolder.id, songId: songId) { error in
                            if let error = error {
                                print(error)
                            }
                        }
                    }
                }
            }
        }
    }
}
