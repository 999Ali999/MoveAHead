//
//  LyricsEditorViewModel.swift
//  MoveAHead
//
//  Created by Felix Parey on 16/05/24.
//
import Foundation

extension LyricsEditorView {
    @Observable
    class ViewModel {
        var sections: [SectionViewModel] = [SectionViewModel(sectionType: .Intro, textLines: [TextLineViewModel()])]
        
        init() {}
        
        func addSection(sectionId: UUID, sectionType: SongSectionType) {
            if let section = sections.first(where: { $0.id == sectionId }) {
                section.textLines   .removeLast() // TODO: A bit didn't understand about reasons for this line here.
                sections.append(SectionViewModel(sectionType: sectionType, textLines: [TextLineViewModel()]))
            }
        }
        
        func addTextline(sectionId: UUID) {
            if let section = sections.first(where: { $0.id == sectionId }) {
                section.textLines.append(TextLineViewModel())
            }
        }
    }
    
    @Observable
    class SectionViewModel: Identifiable {
        var id = UUID()
        var sectionType: SongSectionType?
        var textLines: [TextLineViewModel] = [TextLineViewModel()]
        
        init(sectionType: SongSectionType? = nil, textLines: [TextLineViewModel]) {
            self.sectionType = sectionType
            self.textLines = textLines
        }
    }
    
    @Observable
    class TextLineViewModel: Identifiable {
        var id = UUID()
        var text: String = ""
        var plusOpacity: Double = 1.0
    }
}
