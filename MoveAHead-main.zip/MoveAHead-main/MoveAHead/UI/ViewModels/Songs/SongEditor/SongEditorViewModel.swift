//
//  SongEditorViewModel.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 07/06/24.
//

import Foundation
import SwiftUI
import Combine

extension SongEditorView {
    final class SongEditorViewModel: ObservableObject {
        @Published var name: String = ""
        @Published var sections: [SectionEditorViewModel] = []
        @Published var activeSectionID: UUID?
        @Published var showSheet: Bool = false
        @Published var selectedSheet: SheetType? = nil
        @Published var editMode: EditMode = .Edit
        
        // Track the ID of the most recently added editor
        private var lastAddedSectionID: UUID?
        
        // Track the focus state of each editor
        @Published var sectionEditorFocusStates: [UUID: Bool] = [:]
        
        @Published var isSettingsShown = false
        
        @Published var isRequestingToAI = false
        
        @Published var generateResult: [String] = []
        @Published var generateSelectedTextOption: String?
        
        @Published var restyleResult: [String] = []
        @Published var originalRestyleLine: String?
        @Published var restyleSelectedTextOption: String?
        
        @Published var isShowingTagAddedToast = false
        @Published var addedTagMessage: String?
        
        private var songFolderId: String
        private var songFolderItem: SongFolderItem
        private var songRepository: SongRepositoryProtocol = FirestoreSongRepositoryImpl.shared
        private var predefinedFoldersImpl: PredefinedFoldersImpl = PredefinedFoldersImpl.shared
        private var song: Song?
        
        private let debouncer = Debouncer(delay: 0.5)
        private let debouncerRequestToAI = Debouncer(delay: 1)
        private var cancellables = Set<AnyCancellable>()
        
        private var songContentGenerator: SongContentGeneratorProtocol = OpenAISongContentGeneratorImpl.shared
        
        enum SheetType {
            case generate
            case rhyme
            case restyle
        }
        
        enum EditMode {
            case HighlightParagraph
            case Edit
        }
        
        init(songFolderId: String, songFolderItem: SongFolderItem) {
            self.songFolderId = songFolderId
            self.songFolderItem = songFolderItem
            self.name = songFolderItem.name ?? ""
        }
        
        func initSong() async {
            if songFolderId.isEmpty {
                songFolderId = predefinedFoldersImpl.singlesFolder!.id
            }
            
            if songFolderItem.id == nil {
                songFolderItem.id = UUID().uuidString
                let song = Song(id: songFolderItem.id!, createdOn: Date.now, name: "", songFolderId: songFolderId)
                
                DispatchQueue.main.async {
                    self.song = song
                    
                    let sectionEditorViewModel = SectionEditorViewModel(title: "", text: "")
                    self.sections.append(sectionEditorViewModel)
                }
                songRepository.addSong(song: song) { error in
                    if let error = error {
                        print(error.localizedDescription)
                        return
                    }
                    
                    self.subscribeToModelChanges()
                }
            }
            else if let songId = songFolderItem.id {
                do {
                    let song = try await songRepository.fetchSong(withId: songId)
                    self.song = song
                    
                    DispatchQueue.main.async {
                        self.name = song.name
                        
                        song.songSections.forEach { songSection in
                            let sectionEditorViewModel = SectionEditorViewModel(title: songSection.title ?? "", text: songSection.lyricsText ?? "")
                            self.sections.append(sectionEditorViewModel)
                        }
                        
                        self.subscribeToModelChanges()
                    }
                } catch {
                    print(error)
                }
            }
        }
        
        private func subscribeToModelChanges() {
            self.$name
                .sink { name in
                    self.debouncer.debounce {
                        self.updateSong()
                    }
                }
                .store(in: &cancellables)
        }
        
        private func updateSong() {
            if var song = self.song {
                song.name = self.name
                
                song.songSections = self.sections.map {
                    SongSection(id: $0.id.uuidString, title: $0.title, lyricsText: $0.text.string)
                }
                
                DispatchQueue.global().async {
                    self.songRepository.updateSong(song: song) { error in
                        if let error = error {
                            print(error.localizedDescription)
                            return
                        }
                    }
                }
            }
        }
        
        func setActiveSection(to sectionID: UUID) {
            activeSectionID = sectionID
        }
        
        func clearActiveSection() {
            DispatchQueue.main.async {
                self.activeSectionID = nil
            }
        }
        
        func addSection() {
            let newSection = SectionEditorViewModel(title: "", text: "")
            DispatchQueue.main.async {
                self.sections.append(newSection)
                self.debouncer.debounce {
                    self.updateSong()
                }
                
                // Set the ID of the most recently added editor
                self.lastAddedSectionID = newSection.id
                // Set the active editor to the most recently added editor
                self.activeSectionID = newSection.id
                // Set the focus state of the new editor to true
                self.sectionEditorFocusStates[newSection.id] = true
            }
        }
        
        func removeSection(sectionID: UUID) {
            DispatchQueue.main.async {
                if let index = self.sections.firstIndex(where: { $0.id == sectionID }) {
                    self.sections.remove(at: index)
                    self.debouncer.debounce {
                        self.updateSong()
                    }
                    
                    if self.activeSectionID == sectionID {
                        self.activeSectionID = nil
                    }
                    // Remove focus state for the removed editor
                    self.sectionEditorFocusStates.removeValue(forKey: sectionID)
                }
            }
        }
        
        func removeLastSection() {
            DispatchQueue.main.async {
                if let lastAddedSectionID = self.sections.last?.id {
                    self.removeSection(sectionID: lastAddedSectionID)
                    self.debouncer.debounce {
                        self.updateSong()
                    }
                }
            }
        }
        
        func openSheet(_ sheet: SheetType) {
            hideKeyboard()
            DispatchQueue.main.async {
                if sheet == .restyle {
                    self.editMode = .HighlightParagraph
                    self.selectedSheet = sheet
                    self.showSheet = true
                } else if sheet == .generate {
                    self.selectedSheet = sheet
                    self.showSheet = true
                }
            }
        }
        
        func closeSheet() {
            DispatchQueue.main.async {
                self.editMode = .Edit
                self.showSheet = false
                self.selectedSheet = nil
                
                if let activeSectionID = self.activeSectionID {
                    self.updateHighlightedRanges(nil, for: activeSectionID)
                }
            }
        }
        
        func updateTitle(_ title: String, for sectionID: UUID) {
            if let index = sections.firstIndex(where: { $0.id == sectionID }) {
                sections[index].title = title
                self.debouncer.debounce {
                    self.updateSong()
                }
            }
        }
        
        func updateText(_ text: NSAttributedString, for sectionID: UUID) {
            if let index = sections.firstIndex(where: { $0.id == sectionID }) {
                DispatchQueue.main.async {
                    self.sections[index].text = text
                    self.objectWillChange.send()
                }
                
                self.debouncer.debounce {
                    self.updateSong()
                }
            }
        }
        
        func updateHighlightedRanges(_ range: NSRange?, for sectionID: UUID) {
            DispatchQueue.main.async {
                for (index, _) in self.sections.enumerated() {
                    self.sections[index].highlightedRange = nil
                }
                
                if let index = self.sections.firstIndex(where: { $0.id == sectionID }) {
                    self.sections[index].highlightedRange = range
                }
                
                // TODO: we notify our state that something has changed in the nested fields to highlightedRange for each section and push the updates down the views.
                self.objectWillChange.send()
            }
        }
        
        func updateHighlightedText(_ text: String?, for sectionID: UUID) {
            DispatchQueue.main.async {
                for (index, _) in self.sections.enumerated() {
                    self.sections[index].highlightedText = nil
                }
                
                if let index = self.sections.firstIndex(where: { $0.id == sectionID }) {
                    self.sections[index].highlightedText = text
                }
                
                if self.selectedSheet == .restyle {
                    self.restyleLine()
                }
                
                // TODO: we notify our state that something has changed in the nested fields to highlightedRange for each section and push the updates down the views.
                self.objectWillChange.send()
            }
        }
        
        func updateSelectedRange(_ range: NSRange?, for sectionID: UUID) {
            DispatchQueue.main.async {
                if let index = self.sections.firstIndex(where: { $0.id == sectionID }) {
                    self.sections[index].selectedRange = range
                }
                
                // TODO: we notify our state that something has changed in the nested fields to highlightedRange for each section and push the updates down the views.
                self.objectWillChange.send()
            }
        }
        
        func generateNextLines() {
            var song = self.song
            let textArray = song?.songSections
            var text: [String] = []
            textArray?.forEach({ section in
                text.append(section.lyricsText ?? "")
            })
            let previousText = text.joined(separator: "\n")
            print(previousText)
                DispatchQueue.main.async {
                    print("Processing")
                    self.isRequestingToAI = true
                    self.debouncerRequestToAI.debounce {
                        Task {
                            do {
                                let result = try await self.songContentGenerator.generateNextLines(previousText: previousText)
                                print("Did Generate")
                                print(self.isRequestingToAI)
                                self.generateResult = result
                                print("AI Output: \(result)")
                              
                            } catch {
                                print(error)
                            }
                            self.isRequestingToAI = false
                        }
                    }
                }
            

        }
        
        func cancelGenerateNextLinesTask() {
            DispatchQueue.main.async {
                self.isRequestingToAI = false
            }
            self.debouncerRequestToAI.kill()
        }
        
        func insertGeneratedLine(_ newLine: String) {
            if let index = self.sections.firstIndex(where: { $0.id == activeSectionID }), var highlightedRange = self.sections[index].highlightedRange {
                DispatchQueue.main.async {
                    
                    self.generateSelectedTextOption = newLine
                    
                    let originalString = NSMutableAttributedString(string: self.sections[index].text.string)
                    let newText = NSAttributedString(string: newLine)
                    
                    // Replace the highlighted text
                    originalString.append(newText)
                    
                    // Update the section text
                    self.sections[index].text = originalString
                    
                    // Calculate the new highlighted range length
                    let newHighlightedLength = newText.length
                    let updatedRange = NSRange(location: highlightedRange.location, length: newHighlightedLength)
                    
                    // Update the section properties
                    self.sections[index].highlightedRange = updatedRange
                    self.sections[index].highlightedText = newText.string
                    
                    self.objectWillChange.send()
                }
            }
        }
        
        func restyleLine() {
            if let index = self.sections.firstIndex(where: { $0.id == activeSectionID }), let highlightedText = self.sections[index].highlightedText {
                
                DispatchQueue.main.async {
                    self.restyleResult.removeAll()
                    self.restyleSelectedTextOption = nil
                    self.isRequestingToAI = true
                    self.debouncerRequestToAI.debounce {
                        Task {
                            do {
                                var result = try await self.songContentGenerator.restyleLine(line: highlightedText)
                                // TODO: one from many possible approaches to make restyling UX smoothly.
                                self.originalRestyleLine = highlightedText
                              //  result.insert(highlightedText, at: 0)
                                self.restyleSelectedTextOption = highlightedText
                                self.restyleResult = result
                            } catch {
                                print(error)
                            }
                            self.isRequestingToAI = false
                        }
                    }
                }
            }
        }
        
        func cancelRestyleLineTask() {
            DispatchQueue.main.async {
                self.restyleResult.removeAll()
                self.isRequestingToAI = false
            }
            self.debouncerRequestToAI.kill()
        }
        
        func replaceRestyleLine(_ newLine: String) {
            if let index = self.sections.firstIndex(where: { $0.id == activeSectionID }), var highlightedRange = self.sections[index].highlightedRange {
                DispatchQueue.main.async {
                    self.restyleSelectedTextOption = newLine
                    
                    let originalString = NSMutableAttributedString(string: self.sections[index].text.string)
                    let newText = NSAttributedString(string: newLine)
                    
                    // Replace the highlighted text
                    originalString.replaceCharacters(in: highlightedRange, with: newText)
                    
                    // Update the section text
                    self.sections[index].text = originalString
                    
                    // Calculate the new highlighted range length
                    let newHighlightedLength = newText.length
                    let updatedRange = NSRange(location: highlightedRange.location, length: newHighlightedLength)
                    
                    // Update the section properties
                    self.sections[index].highlightedRange = updatedRange
                    self.sections[index].highlightedText = newText.string
                    
                    self.objectWillChange.send()
                }
            }
        }
        
        
        // Method to get a custom binding for editor text
        func binding(for section: SectionEditorViewModel) -> Binding<NSAttributedString> {
            Binding<NSAttributedString>(
                get: { section.text },
                set: { [weak self] newText in
                    guard let self = self else { return }
                    if let index = self.sections.firstIndex(where: { $0.id == section.id }) {
                        DispatchQueue.main.async {
                            self.sections[index].text = newText
                        }
                    }
                }
            )
        }
        
        func insertHashtag() {
            if let index = self.sections.firstIndex(where: { $0.id == activeSectionID }) {
                var selectedRange = self.sections[index].selectedRange ?? NSRange(location: 0, length: 0)
                let originalString = NSMutableAttributedString(string: self.sections[index].text.string)
                originalString.insert(NSAttributedString(string: "#"), at: selectedRange.lowerBound)
                
                self.sections[index].text = originalString
                
                selectedRange.location += 1
                self.sections[index].selectedRange = selectedRange
                
                self.objectWillChange.send()
            }
        }
        
        func addTag(_ tag: String, addedTagMessage: String) {
            if tag.isEmpty {
                return
            }
            
            DispatchQueue.main.async {
                let tag = tag.replacingOccurrences(of: "#", with: "")
                
                self.addedTagMessage = addedTagMessage
                self.isShowingTagAddedToast = true
                
                var tags = self.song?.tags ?? []
                
                if !tags.contains(where: { $0 == tag }) {
                    tags.append(tag)
                    self.setSongTags(tags: tags)
                }
            }
        }
        
        func getSongTags() -> [String] {
            return song?.tags ?? []
        }
        
        func setSongTags(tags: [String]) {
            self.song?.tags = tags
            self.debouncer.debounce {
                self.updateSong()
            }
        }
        
        func removeTag(_ tag: String) {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                self.songRepository.removeTagIfUnused(tag)
            }
        }
    }
}
