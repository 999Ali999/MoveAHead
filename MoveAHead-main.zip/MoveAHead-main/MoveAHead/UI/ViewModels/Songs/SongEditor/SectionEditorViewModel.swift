//
//  SectionEditorViewModel.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 07/06/24.
//

import Foundation
import Combine
import UIKit

extension SongEditorView {
    final class SectionEditorViewModel: Identifiable, Equatable {
        let id = UUID()
        var title: String
        var text: NSAttributedString
        var highlightedRange: NSRange?
        var highlightedText: String?
        var selectedRange: NSRange?
        
        private var cancellables = Set<AnyCancellable>()
        
        init(title: String, text: String) {
            self.title = title
            self.text = NSAttributedString(string: text)
        }
        
        static func == (lhs: SongEditorView.SectionEditorViewModel, rhs: SongEditorView.SectionEditorViewModel) -> Bool {
            lhs.id == rhs.id
        }
    }
}

let defaultSectionTextAttributes: [NSAttributedString.Key : Any] = {
    let paragraphStyle = NSMutableParagraphStyle()
    paragraphStyle.lineSpacing = 4
    paragraphStyle.minimumLineHeight = 24
    paragraphStyle.maximumLineHeight = 24
    return [.paragraphStyle: paragraphStyle]
}()

let defaultEditorFont = {
    let font = UIFont.systemFont(ofSize: 19)
    return font
}()
