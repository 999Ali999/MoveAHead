//
//  SettingsViewModel.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 03/06/24.
//

import Foundation

class SongSettingsViewModel: ObservableObject {
    @Published var songEditorViewModel: SongEditorView.SongEditorViewModel
    @Published var selectedTags: [String] = []
    
    @Published var tags: [String] = [
        "Pop",
        "Rock",
        "Hip-Hop",
        "Jazz",
        "Classical",
        "R&B",
        "Electronic",
        "Country",
        "Reggae",
        "Blues"
    ]
    
    @Published var tagsVibe: [String] = [
        "Happy",
        "Sad",
        "Energetic",
        "Calm",
        "Romantic",
        "Melancholic",
        "Uplifting",
        "Chill",
        "Aggressive",
        "Relaxed"
    ]
    
    @Published var userTags: [String] = []
    
    init(songEditorViewModel: SongEditorView.SongEditorViewModel) {
        self.songEditorViewModel = songEditorViewModel
        self.selectedTags = self.songEditorViewModel.getSongTags()
        
        var userTags = Set(songEditorViewModel.getSongTags())
        userTags = userTags.subtracting(tags).subtracting(tagsVibe)
        self.userTags = Array(userTags)
    }
    
    func toggleTag(tag: String) {
        if let index = selectedTags.firstIndex(of: tag) {
            songEditorViewModel.removeTag(tag)
            selectedTags.remove(at: index)
        } else {
            selectedTags.append(tag)
        }
        
        songEditorViewModel.setSongTags(tags: selectedTags)
    }
}
