//
//  AuthViewModel.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 13/05/24.
//

import Combine
import SwiftUI
import FirebaseFirestore

@MainActor
class AuthModel: ObservableObject {
    @Published 
    var isAuthenticated = false
    @Published
    var user: User?

    var isSignedIn: Bool {
        get {
            if let user = self.user {
                return user.isAnonymous == false
            }
            return false
        }
    }
    
    private var authService: AuthServiceProtocol = FirebaseAuthServiceImpl.shared
    private var albumsViewModel: AlbumsView.ViewModel
    
    init(albumsViewModel: AlbumsView.ViewModel) {
        self.albumsViewModel = albumsViewModel
    }
    
    func checkAuthentication() async {
        if let user = await authService.signInAnonymously() {
            self.user = user
            self.isAuthenticated = true
        }
    }
    
    func signInWithAppleID() async {
        do {
            try await beforeSwitchAccount()
            
            if let user = await authService.signInWithApple() {
                self.user = user
                self.isAuthenticated = true
                
                try await self.afterSwitchAccount(user.id)
                albumsViewModel.fetchSongFolders()
            }
        }
        catch {
            print(error)
        }
    }
    
    func logout() async {
        authService.signOut()
        await self.checkAuthentication()
    }
    
    private func beforeSwitchAccount() async throws {
        try await Migration.shared.exportDataToLocalCache()
    }
    
    private func afterSwitchAccount(_ userUid: String) async throws {
        try await Firestore.firestore().enableNetwork()
        try await Migration.shared.restoreDataFromLocalCacheToCloud(userUid)
    }
}
