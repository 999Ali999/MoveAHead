//
//  OnboardingViewModel.swift
//  MoveAHead
//
//  Created by Felix Parey on 06/06/24.
//

import Foundation

extension OnboardingView{
    
    @Observable
    class ViewModel{
        
        var alertPresented = false
        var onboardingState: OnboardingState
        static let onboardingContent: [OnboardingContent] = [
            OnboardingContent(iconName: "folder", heading: "Organizational Dream", text: "Organize songs into folders and add tags for easy filtering and searching"),
            OnboardingContent(iconName: "text.badge.checkmark", heading: "Simple Structuring", text: "Structure your song into customizable sections for simple differentiation between parts of your songs"),
            OnboardingContent(iconName: "sparkles", heading: "AI Assistant", text: "Get assistance to find inspiration for your lyrics with Generate next line, Restyle and Rhyme finder")
        ]
        static let accountBenefits: [String] = ["Save songs across devices", "Use subscription on other devices", "Get early access to new features"
        ]
        
        struct OnboardingContent: Identifiable{
            var id = UUID()
            var iconName: String
            var heading: String
            var text: String
        }
        
        public enum OnboardingState {
            case Info, SingIn
        }
        init(alertPresented: Bool = false, onboardingState: OnboardingState) {
            self.alertPresented = alertPresented
            self.onboardingState = onboardingState
        }
        
    }
}


