//
//  ThemeProtocol.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 14/05/24.
//

import Foundation
import SwiftUI

protocol ThemeProtocol {
    var largeTitleFont: Font { get }
    var textTitleFont: Font { get }
    var normalButtonTitleFont: Font { get }
    var boldButtonTitleFont: Font { get }
    var bodyTextFont: Font { get }
    var captionTextFont: Font { get }
    
    var primaryThemeColor: Color { get }
    var secondaryThemeColor: Color { get }
    var bodyTextColor: Color { get }
    var textBoxColor: Color { get }
    var bodyBackgroundColor: Color { get }
    var gray1: Color { get }
    var gray2: Color { get }
    var lightGray: Color { get }
    var premiumGradient: LinearGradient { get }
}
