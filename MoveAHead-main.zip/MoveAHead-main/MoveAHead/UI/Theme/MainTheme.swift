//
//  MainTheme.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 14/05/24.
//

import Foundation
import SwiftUI

struct MainTheme: ThemeProtocol {
    var largeTitleFont: Font = .custom("MartelSans-ExtraBold", size: 30.0)
    var textTitleFont: Font = .custom("MartelSans-ExtraBold", size: 24.0)
    var normalButtonTitleFont: Font = .custom("MartelSans-SemiBold", size: 20.0)
    var boldButtonTitleFont: Font = .custom("MartelSans-Bold", size: 20.0)
    var bodyTextFont: Font = .custom("MartelSans-Light", size: 18.0)
    var captionTextFont: Font = .custom("MartelSans-SemiBold", size: 20.0)
    
    var primaryThemeColor: Color { return Color("primaryThemeColor") }
    var secondaryThemeColor: Color { return Color("secondaryThemeColor") }
    var bodyTextColor: Color { return Color("bodyTextColor") }
    var textBoxColor: Color { return Color("textBoxColor") }
    var bodyBackgroundColor: Color { return Color("bodyBackgroundColor") }
    var gray1: Color { return Color("gray1") }
    var gray2: Color { return Color("gray2") }
    var lightGray: Color { return Color("lightGray") }
    var premiumGradient: LinearGradient { return LinearGradient(colors: [.yellow, .orange], startPoint: .topLeading, endPoint: .bottomTrailing) }
}
