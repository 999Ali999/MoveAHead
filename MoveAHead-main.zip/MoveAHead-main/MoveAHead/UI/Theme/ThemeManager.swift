//
//  ThemeManager.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 14/05/24.
//

import Foundation
import SwiftUI

@Observable
class ThemeManager {
    static let shared = ThemeManager()
    
    var selectedTheme: ThemeProtocol = MainTheme()
    
    func setTheme(_ theme: ThemeProtocol) {
        selectedTheme = theme
    }
    
    func setColorScheme(number: Int?) -> ColorScheme? {
        switch number {
        case 1: return .light
        case 2: return .dark
        default: return UITraitCollection.current.userInterfaceStyle == .light ? .light : .dark
        }
    }
}
