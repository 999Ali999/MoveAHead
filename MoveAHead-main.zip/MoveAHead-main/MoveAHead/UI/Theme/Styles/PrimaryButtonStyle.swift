//
//  PrimaryButtonStyle.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 14/05/24.
//

import Foundation
import SwiftUI

struct PrimaryButtonStyle: ButtonStyle {
    @Environment(ThemeManager.self) var themeManager
    
    func makeBody(configuration: Configuration) -> some View {
        HStack {
            Spacer()
            configuration.label
            Spacer()
        }
        .padding()
        .font(themeManager.selectedTheme.normalButtonTitleFont)
        .background {
            Capsule()
                .background(themeManager.selectedTheme.primaryThemeColor)
        }
    }
}
