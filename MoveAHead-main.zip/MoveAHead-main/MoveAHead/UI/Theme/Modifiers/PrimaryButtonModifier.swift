//
//  PrimaryButtonStyle.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 14/05/24.
//

import Foundation
import SwiftUI

struct PrimaryButtonModifier: ViewModifier {
    @Environment(ThemeManager.self) var themeManager
    
    func body(content: Content) -> some View {
        content
            .padding()
            .font(themeManager.selectedTheme.normalButtonTitleFont)
            .background {
                Capsule()
                    .background(themeManager.selectedTheme.primaryThemeColor)
            }
    }
}

extension View {
    func primaryButtonStyle() -> some View {
        ModifiedContent(
            content: self,
            modifier: PrimaryButtonModifier()
        )
    }
}
