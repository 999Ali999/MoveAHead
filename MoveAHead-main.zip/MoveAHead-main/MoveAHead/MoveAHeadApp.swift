//
//  MoveAHeadApp.swift
//  MoveAHead
//
//  Created by Felix Parey on 30/04/24.
//

import SwiftUI

@main
struct MoveAHeadApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    
    var themeManager: ThemeManager = ThemeManager.shared
    
    @StateObject private var authModel: AuthModel
    @StateObject private var navigationModel = NavigationModel()
    @State private var albumsViewModel: AlbumsView.ViewModel
    
    @AppStorage("FirstTimeAppLaunched") private var firstTimeAppLaunched = true
    @AppStorage("colorSchemeNumber") private var colorSchemeNumber: Int?
    
    init() {
        let albumsViewModel = AlbumsView.ViewModel()
        let authModel = AuthModel(albumsViewModel: albumsViewModel)
        self._albumsViewModel = State(wrappedValue: albumsViewModel)
        self._authModel = StateObject(wrappedValue: authModel)
    }
    
    var body: some Scene {
        WindowGroup {
            RootView(albumsViewModel: $albumsViewModel, firstTimeAppLaunched: $firstTimeAppLaunched)
                .onAppear {
                    bootstrap()
                }
                .environmentObject(navigationModel)
                .environmentObject(authModel)
                .environment(themeManager)
                .preferredColorScheme(themeManager.setColorScheme(number: colorSchemeNumber))
        }
    }
}

extension MoveAHeadApp {
    func bootstrap() {
        Task {
            await authModel.checkAuthentication()
            try! await PredefinedFoldersImpl.shared.refreshPredefinedFolders()
            
            if !firstTimeAppLaunched{
                navigationModel.restoreNavigationPath()
            }
        }
    }
}
