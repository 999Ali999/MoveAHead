//
//  AppDelegate.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 08/05/24.
//

import SwiftUI
import FirebaseCore
import FirebaseFirestore
import FirebaseAuth

class AppDelegate: NSObject, UIApplicationDelegate {
  func application(_ application: UIApplication,
                   didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
    configureFirebase()
    return true
  }
    
    private func configureFirebase() {
        FirebaseApp.configure()

        let settings = Firestore.firestore().settings
        settings.cacheSettings = PersistentCacheSettings(sizeBytes: NSNumber(value: FirestoreCacheSizeUnlimited))
        Firestore.firestore().settings = settings
        
        Firestore.firestore().disableNetwork()
    }
}


