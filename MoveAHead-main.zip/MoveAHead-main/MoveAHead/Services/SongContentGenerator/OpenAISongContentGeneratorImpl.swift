//
//  OpenAISongContentGeneratorImpl.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 16/05/24.
//

import Foundation
import OpenAI

public final class OpenAISongContentGeneratorImpl: SongContentGeneratorProtocol {
    public static var shared = OpenAISongContentGeneratorImpl()
    
    private let openAI = OpenAI(apiToken: (Bundle.main.infoDictionary?["OPENAI_API_SECRET_KEY"] as? String)!)
    
    private let genNextLinePrompt = "Given the previous lines of a song, separated by \n, generate a new line of text that fits five times. The lines: \"[line]\". Take into consideration the content of the text previously written as well as any Rhyme scheme you can detect. Also stick to the language(s) used in the song and the style of it. The output of the 5 different lines to generate must be as a JSON string array"
    
    private let generateNextLinesPrompt = "You are acting as a co-songwriter. Given the following line of a song \"[line]\", generate this line with the 5 lyrical options. Match the tone, style, and mood, and language ensuring coherence with the theme. Maintain rhythm and rhyme. The output format should be a JSON string array."
    
    private let restyleLinesPrompt = "You are acting as a co-songwriter. Given the following line of a song \"[line]\", identify the language of the line and restyle that same line with 5 lyrical options in that same language. Try to keep the original line lenght and meaning for the results. Match the tone, style, and mood, and original line language. Maintain rhythm and rhyme. Do not repeat original line. The output format should be a only plain JSON string array."

    public func generateNextLines(previousText: String) async throws -> [String] {
        let query = ChatQuery(messages: [.init(role: .user, content: genNextLinePrompt.replacingOccurrences(of: "[line]", with: previousText))!], model: .gpt3_5Turbo)
        
        let result = try await openAI.chats(query: query)

        if let choice = result.choices.first {
            if let jsonData = choice.message.content?.string?.data(using: .utf8) {
                if let lines = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String] {
                    return lines
                }
            }
        }
        
        return []
    }
    
    public func restyleLine(line: String) async throws -> [String] {
        let query = ChatQuery(messages: [.init(role: .user, content: restyleLinesPrompt.replacingOccurrences(of: "[line]", with: line))!], model: .gpt3_5Turbo)
        
        let result = try await openAI.chats(query: query)

        if let choice = result.choices.first {
            if let jsonData = choice.message.content?.string?.data(using: .utf8) {
                if let lines = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String] {
                    return lines
                }
            }
        }
        
        return []
    }
}
