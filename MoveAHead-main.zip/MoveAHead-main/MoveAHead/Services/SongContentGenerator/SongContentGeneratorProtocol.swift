//
//  GeneratorProtocol.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 15/05/24.
//

import Foundation

public struct SongContentResult {
    var content: [String]
}

public protocol SongContentGeneratorProtocol {
    func generateNextLines(previousText: String) async throws -> [String]
    func restyleLine(line: String) async throws -> [String]
}
