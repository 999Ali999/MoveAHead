//
//  GeneratorFakeImpl.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 15/05/24.
//

import Foundation

public final class SongContentGeneratorFakeImpl: SongContentGeneratorProtocol {
    public func generateNextLines(previousText: String) async throws -> [String] {
        try await Task.sleep(nanoseconds: 1_000_000_000)
        return [
            "And the stars align with our dreams, casting a silver glow upon our faces",
            "Whispers of the wind in the night, telling tales of love and sorrow long forgotten",
            "Melodies of love in the air, weaving through the trees and the whispering leaves",
            "Underneath the moonlit sky, where our hearts beat in unison with the distant stars"
        ]
    }
    
    public func restyleLine(line: String) async throws -> [String] {
        try await Task.sleep(nanoseconds: 1_000_000_000)
        return [
            "And the stars align with our dreams, casting a silver glow upon our faces",
            "Whispers of the wind in the night, telling tales of love and sorrow long forgotten",
            "Melodies of love in the air, weaving through the trees and the whispering leaves",
            "Underneath the moonlit sky, where our hearts beat in unison with the distant stars"
        ]
    }
}

