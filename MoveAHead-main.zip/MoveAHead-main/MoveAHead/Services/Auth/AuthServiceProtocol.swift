//
//  AuthServiceProtocol.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 13/05/24.
//

import Foundation
import AuthenticationServices

public protocol AuthServiceProtocol {
    func signInAnonymously() async -> User?
    func signInWithApple() async -> User?
    func signOut()
}
