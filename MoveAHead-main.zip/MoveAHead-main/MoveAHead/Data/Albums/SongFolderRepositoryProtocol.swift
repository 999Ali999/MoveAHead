//
//  ProductRepositoryInterface.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 09/05/24.
//

import Foundation

public protocol SongFolderRepositoryProtocol {
    func addSongFolder(songFolder: SongFolder, completion: @escaping (Error?) -> Void)
    func fetchSongFolders(completion: @escaping (Result<[SongFolder], Error>) -> Void)
    func fetchSongsByFolder(folderId: String, filter: SongFilter?, completion: @escaping (Result<[SongFolderItem], Error>) -> Void)
    func removeSongFolder(songFolder: SongFolder, completion: @escaping (Error?) -> Void)
    func removeSongFromFolder(songFolderId: String, songId: String, completion: @escaping (Error?) -> Void)
}
