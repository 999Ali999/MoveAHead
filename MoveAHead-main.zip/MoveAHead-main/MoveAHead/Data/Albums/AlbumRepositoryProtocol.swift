//
//  ProductRepositoryInterface.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 09/05/24.
//

import Foundation

public protocol AlbumRepositoryProtocol {
    func fetchAlbums(completion: @escaping (Result<[Album], Error>) -> Void)
    func addAlbum(album: Album, completion: @escaping (Error?) -> Void)
    func deleteAlbum(withId albumId: String, completion: @escaping (Error?) -> Void)
}
