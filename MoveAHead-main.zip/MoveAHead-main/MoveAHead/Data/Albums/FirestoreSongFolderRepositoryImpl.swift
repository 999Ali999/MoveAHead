//
//  FirestoreAlbumRepository.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 09/05/24.
//

import Foundation
import FirebaseFirestore
import FirebaseAuth
import FirebaseCore

final class FirestoreSongFolderRepositoryImpl: SongFolderRepositoryProtocol {
    static var shared: FirestoreSongFolderRepositoryImpl = FirestoreSongFolderRepositoryImpl()
    
    private let firestoreRepositoryImpl = FirestoreRepositoryImpl<SongFolder>(collectionName: String(describing: SongFolder.self).pluralize())
    private let predefinedFoldersRepositoryImpl = PredefinedFoldersImpl.shared
    
    private var usersCollection: CollectionReference {
        get {
            return Firestore.firestore().collection("users")
        }
    }
    private var songFoldersListener: ListenerRegistration?
    private var songsListener: ListenerRegistration?
    
    private var currentUserUid: String {
        get {
            return Auth.auth().currentUser?.uid ?? PredefinedFoldersImpl.localUserUid
        }
    }
    
    private var songFoldersCollection: CollectionReference {
        get {
            usersCollection.document(currentUserUid).collection("songFolders")
        }
    }
    
    public func addSongFolder(songFolder: SongFolder, completion: @escaping (Error?) -> Void) {
        let songFolder = songFolder
        
        do {
            try songFoldersCollection.document(songFolder.id).setData(from: songFolder)
            completion(nil)
        } catch {
            completion(error)
        }
    }
    
    public func fetchSongFolders(completion: @escaping (Result<[SongFolder], Error>) -> Void) {
        if songFoldersListener != nil {
            songFoldersListener?.remove()
        }
        
        let query = songFoldersCollection.order(by: "createdOn", descending: true)
        
        songFoldersListener = query.addSnapshotListener { querySnapshot, error in
            if let error = error {
                completion(.failure(error))
            } else {
                do {
                    let documents = try querySnapshot?.documents.compactMap { try $0.data(as: SongFolder.self) }
                    completion(.success(documents ?? []))
                } catch {
                    completion(.failure(error))
                }
            }
        }
    }
    
    func fetchSongsByFolder(folderId: String, filter: SongFilter?, completion: @escaping (Result<[SongFolderItem], Error>) -> Void) {
        if songsListener != nil {
            songsListener?.remove()
        }
        
        let query = songFoldersCollection.document(folderId).collection("songs").order(by: "createdOn", descending: true).order(by: "name")
        
        /*
         // TODO: for future implementation on server-side withing Elastic search etc.
         if let filter = filter {
         if !filter.searchText.isEmpty {
         let lowercasedSearchText = filter.searchText.lowercased()
         query = query.whereFilter(.andFilter([.whereField("name_insensitive", isGreaterOrEqualTo: lowercasedSearchText), .whereField("name_insensitive", isLessThanOrEqualTo: lowercasedSearchText + "\u{f8ff}")]))
         }
         if !filter.tags.isEmpty {
         query = query.whereField("tags", in: filter.tags)
         }
         }
         */
        
        songsListener = query.addSnapshotListener { querySnapshot, error in
            if let error = error {
                completion(.failure(error))
            } else {
                // TODO: client-side search for small datasets
                let documents = querySnapshot?.documents.compactMap { self.snapshotToSongFolderItem($0) }.filter({
                    if let filter = filter {
                        return (filter.searchText.isEmpty || (($0.name ?? "").lowercased().contains(filter.searchText.lowercased()))) &&
                        (filter.tags.isEmpty || ($0.tags ?? []).contains { filter.tags.contains($0) })
                    }
                    return true
                })
                completion(.success(documents ?? []))
            }
        }
    }
    
    func removeSongFolder(songFolder: SongFolder, completion: @escaping (Error?) -> Void) {
        // TODO: [bug] Possible deleting only one folder, then able to delete afters restart (or, instead, after restart doesn't delete only after creating a new one)
        
        self.predefinedFoldersRepositoryImpl.fetchOrAddAllSongsFolder { result in
            switch result {
            case .success(let allSongsFolder):
                self.predefinedFoldersRepositoryImpl.fetchOrAddSRecentlyDeletedFolder { result in
                    switch result {
                    case .success(let recentlyDeletedFolder):
                        let allSongsFolderRef = self.songFoldersCollection.document(allSongsFolder.id)
                        let recentlyDeletedFolderRef = self.songFoldersCollection.document(recentlyDeletedFolder.id)

                        self.songFoldersCollection.document(songFolder.id).collection("songs").getDocuments { querySnapshot, error in
                            if let error = error {
                                completion(error)
                                return
                            }
                            
                            let songFolderItems = querySnapshot?.documents.compactMap { self.snapshotToSongFolderItem($0) } ?? []
                            
                            let batch = Firestore.firestore().batch()
                            
                            songFolderItems.forEach { songFolderItem in
                                batch.deleteDocument(allSongsFolderRef.collection("songs").document(songFolderItem.id!))
                                let songFolderItemRef = recentlyDeletedFolderRef.collection("songs").document(songFolderItem.id!)
                                try! batch.setData(from: songFolderItem, forDocument: songFolderItemRef)
                            }
                            
                            batch.setData(["totalSongs": (allSongsFolder.totalSongs ?? 0) > 0 ?  (allSongsFolder.totalSongs ?? 0) - songFolderItems.count : 0], forDocument: allSongsFolderRef, merge: true)
                            batch.setData(["totalSongs": (recentlyDeletedFolder.totalSongs ?? 0) + songFolderItems.count], forDocument: recentlyDeletedFolderRef, merge: true)
                            
                            batch.deleteDocument(self.songFoldersCollection.document(songFolder.id))
                            
                            batch.commit { error in
                                Task {
                                    try await self.predefinedFoldersRepositoryImpl.refreshPredefinedFolders()
                                    completion(error)
                                }
                            }
                        }
                    case .failure(let error):
                        completion(error)
                    }
                }
            case .failure(let error):
                completion(error)
            }
        }
    }
    
    func removeSongFromFolder(songFolderId: String, songId: String, completion: @escaping (Error?) -> Void) {
        
        self.predefinedFoldersRepositoryImpl.fetchOrAddAllSongsFolder { result in
            switch result {
            case .success(let allSongsFolder):
                self.predefinedFoldersRepositoryImpl.fetchOrAddSRecentlyDeletedFolder { result in
                    switch result {
                    case .success(let recentlyDeletedFolder):
                        let allSongsFolderRef = self.songFoldersCollection.document(allSongsFolder.id)
                        let recentlyDeletedFolderRef = self.songFoldersCollection.document(recentlyDeletedFolder.id)
                        
                        self.songFoldersCollection.document(songFolderId).getDocument { (result, error) in
                            if let error = error {
                                completion(error)
                                return
                            }
                            
                            let songFolder = try! result!.data(as: SongFolder.self)
                            
                            self.songFoldersCollection.document(songFolderId).collection("songs").document(songId)
                                .getDocument { (result, error) in
                                    if let error = error {
                                        completion(error)
                                        return
                                    }
                                    
                                    let deletedSongFolderItemRef = recentlyDeletedFolderRef.collection("songs").document(songId)
                                    let songFolderRef = self.songFoldersCollection.document(songFolder.id)
                                    
                                    let batch = Firestore.firestore().batch()
                                    
                                    batch.setData(result?.data() ?? [:], forDocument: deletedSongFolderItemRef, merge: true)
                                    
                                    batch.setData(["totalSongs": (songFolder.totalSongs ?? 0) - 1], forDocument: songFolderRef, merge: true)
                                    
                                    batch.setData(["totalSongs": (allSongsFolder.totalSongs ?? 0) > 0 ?  (allSongsFolder.totalSongs ?? 0) - 1 : 0], forDocument: allSongsFolderRef, merge: true)
                                    batch.setData(["totalSongs": (recentlyDeletedFolder.totalSongs ?? 0) + 1], forDocument: recentlyDeletedFolderRef, merge: true)
                                    
                                    batch.deleteDocument(self.songFoldersCollection.document(songFolderId).collection("songs").document(songId))
                                    
                                    batch.commit { error in
                                        Task {
                                            try await self.predefinedFoldersRepositoryImpl.refreshPredefinedFolders()
                                            completion(error)
                                        }
                                    }
                                }
                        }

                    case .failure(let error):
                        completion(error)
                    }
                }
            case .failure(let error):
                completion(error)
            }
        }
    }
    
    private func snapshotToSongFolderItem(_ songFolderItemDocument: QueryDocumentSnapshot) -> SongFolderItem {
        let createdOnTimestamp = songFolderItemDocument["createdOn"] as? Timestamp
        let createdOn = createdOnTimestamp?.dateValue()
        return SongFolderItem(id: songFolderItemDocument.documentID, createdOn: createdOn, name: songFolderItemDocument["name"] as? String, description: songFolderItemDocument["description"] as? String, tags: songFolderItemDocument["tags"] as? [String], totalLines: songFolderItemDocument["totalLines"] as? Int)
    }
}
