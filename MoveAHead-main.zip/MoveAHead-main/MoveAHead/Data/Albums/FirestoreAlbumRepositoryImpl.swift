//
//  FirestoreAlbumRepository.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 09/05/24.
//

import Foundation
import FirebaseFirestore

public struct FirestoreAlbumRepositoryImpl: AlbumRepositoryProtocol {
    static var shared: FirestoreAlbumRepositoryImpl = FirestoreAlbumRepositoryImpl()
    private static var defaultOrderField = "createdOn"
    
    private let firestoreRepositoryImpl: FirestoreRepositoryImpl = FirestoreRepositoryImpl<Album>(collectionName: String(describing: Album.self).pluralize())
    
    public func fetchAlbums(completion: @escaping (Result<[Album], Error>) -> Void) {
        let query = firestoreRepositoryImpl.collectionReference.order(by: FirestoreAlbumRepositoryImpl.defaultOrderField, descending: true)
        firestoreRepositoryImpl.queryDocuments(byQuery: query, completion: completion)
    }
    
    public func addAlbum(album: Album, completion: @escaping (Error?) -> Void) {
        firestoreRepositoryImpl.addDocument(data: album, completion: completion)
    }
    
    public func deleteAlbum(withId albumId: String, completion: @escaping (Error?) -> Void) {
        firestoreRepositoryImpl.deleteDocument(withId: albumId, completion: completion)
    }
}
