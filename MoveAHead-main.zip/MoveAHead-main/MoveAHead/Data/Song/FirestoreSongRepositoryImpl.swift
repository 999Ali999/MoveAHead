//
//  FirestoreSongRepositoryImpl.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 14/05/24.
//

import Foundation
import FirebaseFirestore
import FirebaseAuth

final class FirestoreSongRepositoryImpl: SongRepositoryProtocol {
    static var shared: FirestoreSongRepositoryImpl = FirestoreSongRepositoryImpl()
    
    private let firestoreRepositoryImpl: FirestoreRepositoryImpl = FirestoreRepositoryImpl<Song>(collectionName: "songs")
    private let predefinedFoldersRepositoryImpl = PredefinedFoldersImpl.shared
    
    private let usersCollection = Firestore.firestore().collection("users")
    
    private var currentUserUid: String {
        get {
            Auth.auth().currentUser?.uid ?? PredefinedFoldersImpl.localUserUid
        }
    }
    
    private var songFoldersCollection: CollectionReference {
        get {
            usersCollection.document(currentUserUid).collection("songFolders")
        }
    }
    
    func addSong(song: Song, completion: @escaping (Error?) -> Void) {        
        var song = song
        song.ownerId = currentUserUid
    
        do {
            let documentId = song.id
            try firestoreRepositoryImpl.collectionReference.document(documentId).setData(from: song)
            
            if song.songFolderId.isEmpty {
                song.songFolderId = self.predefinedFoldersRepositoryImpl.singlesFolder!.id
            }
            
            songFoldersCollection.document(song.songFolderId).getDocument { songFolderSnapshot, error in
                if let error = error {
                    completion(error)
                } else if let songFolderSnapshot = songFolderSnapshot, songFolderSnapshot.exists {
                    
                    do {
                        try self.firestoreRepositoryImpl.collectionReference.document(song.id).setData(from: song)
                        
                        let songFolder = try songFolderSnapshot.data(as: SongFolder.self)
                        let newSongFolderItem = song.songFolderItem
    
                        let batch = Firestore.firestore().batch()
                        
                        try batch.setData(from: newSongFolderItem, forDocument: self.songFoldersCollection.document(song.songFolderId).collection("songs").document(song.id))
                        batch.updateData(["totalSongs": (songFolder.totalSongs ?? 0) + 1], forDocument: self.songFoldersCollection.document(song.songFolderId))
                        
                        let allSongFolderId = self.predefinedFoldersRepositoryImpl.allSongsFolder!.id
                        try batch.setData(from: newSongFolderItem, forDocument: self.songFoldersCollection.document(allSongFolderId).collection("songs").document(song.id))
                        batch.updateData(["totalSongs": (self.predefinedFoldersRepositoryImpl.allSongsFolder!.totalSongs ?? 0) + 1], forDocument: self.songFoldersCollection.document(allSongFolderId))
                        
                        try batch.setData(from: newSongFolderItem, forDocument: self.songFoldersCollection.document(song.songFolderId).collection("songs").document(song.id))

                        batch.commit { error in
                            Task {
                                try await self.predefinedFoldersRepositoryImpl.refreshPredefinedFolders()
                                completion(error)
                            }
                        }
                    } catch {
                        completion(error)
                    }
                    
                } else {
                    completion(NSError(domain: "", code: 404, userInfo: nil))
                }
            }
        } catch {
            completion(error)
        }
    }
    
    func updateSong(song: Song, completion: @escaping (Error?) -> Void) {
        var song = song
        song.ownerId = currentUserUid
        
        if song.songFolderId.isEmpty {
            song.songFolderId = self.predefinedFoldersRepositoryImpl.singlesFolder!.id
        }
        
        self.songFoldersCollection.document(song.songFolderId).collection("songs").document(song.id).getDocument { songFolderItemSnapshot, error in
            do {
                try self.firestoreRepositoryImpl.collectionReference.document(song.id).setData(from: song)
                
                let batch = Firestore.firestore().batch()
                let songFolderItem = song.songFolderItem
  
                try batch.setData(from: songFolderItem, forDocument: self.songFoldersCollection.document(song.songFolderId).collection("songs").document(song.id), merge: true)
                
                try batch.setData(from: songFolderItem, forDocument: self.songFoldersCollection.document(self.predefinedFoldersRepositoryImpl.allSongsFolder!.id).collection("songs").document(song.id), merge: true)
                
                if song.songFolderId == self.predefinedFoldersRepositoryImpl.singlesFolder?.id {
                    try batch.setData(from: songFolderItem, forDocument: self.songFoldersCollection.document(self.predefinedFoldersRepositoryImpl.singlesFolder!.id).collection("songs").document(song.id), merge: true)
                }
                
                if song.songFolderId == self.predefinedFoldersRepositoryImpl.recentlyDeletedFolder?.id {
                    try batch.setData(from: songFolderItem, forDocument: self.songFoldersCollection.document(self.predefinedFoldersRepositoryImpl.recentlyDeletedFolder!.id).collection("songs").document(song.id), merge: true)
                }
                
                self.updateTagsCollection(song.tags)
                
                batch.commit { error in
                    completion(error)
                }
            } catch {
                completion(error)
            }
        }
    }
    
    private func updateTagsCollection(_ tags: [String]) {
        let userRef = self.usersCollection.document(self.currentUserUid)
        
        userRef.getDocument { (document, error) in
            if let document = document {
                var currentTags = document.data()?["tags"] as? [String] ?? []
                
                currentTags.append(contentsOf: tags)
                let updatedTags = Array(Set(currentTags)).sorted()

                userRef.setData(["tags":updatedTags], merge: true)
            }
        }
    }
    
    func fetchSong(withId songId: String) async throws -> Song {
        let songSnapshot = try await firestoreRepositoryImpl.collectionReference.document(songId).getDocument()
        let song = try songSnapshot.data(as: Song.self)
        
        return song
    }
    
    private var fetchAllTagsListener: ListenerRegistration?
    
    func fetchAllTags(completion: @escaping (_ tags: [String]) -> Void) {
        if fetchAllTagsListener != nil {
            fetchAllTagsListener?.remove()
            fetchAllTagsListener = nil
        }
        
        let userRef = self.usersCollection.document(self.currentUserUid)
        self.fetchAllTagsListener = userRef.addSnapshotListener { (document, error) in
            if let document = document {
                let currentTags = document.data()?["tags"] as? [String] ?? []
                completion(currentTags)
            }
        }
    }
    
    func removeTagIfUnused(_ tag: String) {
        isTagUsed(tag: tag) { isUsed in
            if !isUsed {
                let userRef = self.usersCollection.document(self.currentUserUid)
                userRef.getDocument { (document, error) in
                    if let document = document {
                        var currentTags = document.data()?["tags"] as? [String] ?? []
                        
                        currentTags.removeAll { $0 == tag }
                        let updatedTags = Array(Set(currentTags)).sorted()

                        userRef.setData(["tags":updatedTags], merge: true)
                    }
                }
            }
        }
    }
    
    private func isTagUsed(tag: String, completion: @escaping (Bool) -> Void) {
        self.songFoldersCollection.document("all-songs-").collection("songs")
            .whereField("tags", arrayContains: tag)
            .getDocuments { (snapshot, error) in
                if error != nil {
                    completion(true)
                }
                else {
                    completion(!snapshot!.isEmpty)
                }
            }
    }
}
