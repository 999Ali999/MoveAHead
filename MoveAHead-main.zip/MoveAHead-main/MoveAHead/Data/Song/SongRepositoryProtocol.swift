//
//  SongRepositoryProtocol.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 14/05/24.
//

import Foundation

protocol SongRepositoryProtocol {
    func addSong(song: Song, completion: @escaping (Error?) -> Void)
    func updateSong(song: Song, completion: @escaping (Error?) -> Void)
    func fetchSong(withId songId: String) async throws -> Song
    func fetchAllTags(completion: @escaping (_ tags: [String]) -> Void)
    func removeTagIfUnused(_ tag: String) -> Void
}
