//
//  PluralizationUtils.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 13/05/24.
//

import Foundation

extension String {
    func pluralize() -> String {
        if self.isEmpty {
                return self
        }
        
        let lastChar = self.last!
        let secondToLastChar = self.dropLast().last
        
        if lastChar == "y" && !"aeiou".contains(secondToLastChar ?? Character("")) {
            return String(self.dropLast()) + "ies"
        } else if lastChar == "s" || lastChar == "x" || lastChar == "z" || (secondToLastChar == "c" && lastChar == "h") || (secondToLastChar == "s" && lastChar == "h") {
            return self + "es"
        } else {
            return self + "s"
        }
    }
}
