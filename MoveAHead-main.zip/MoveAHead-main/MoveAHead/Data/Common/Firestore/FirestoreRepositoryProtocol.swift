//
//  File.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 09/05/24.
//

import Foundation
import FirebaseFirestore

protocol FirestoreRepositoryProtocol {
    associatedtype T: Codable & Identifiable<String>
    
    func addDocument(data: T, completion: @escaping (Error?) -> Void)
    func deleteDocument(withId documentId: String, completion: @escaping (Error?) -> Void)
    func updateDocument(withId documentId: String, data: T, completion: @escaping (Error?) -> Void)
    func getDocument(withId documentId: String, completion: @escaping (Result<T, Error>) -> Void)
    func getAllDocuments(completion: @escaping (Result<[T], Error>) -> Void)
    func getDocuments(where field: String, isEqualTo value: Any, completion: @escaping (Result<[T], Error>) -> Void)
    func queryDocuments(byQuery query: Query, completion: @escaping (Result<[T], Error>) -> Void)
    func observeDocuments(completion: @escaping (Result<[T], Error>) -> Void) -> ListenerRegistration?
    func observeDocuments(byQuery query: Query, completion: @escaping (Result<[T], Error>) -> Void) -> ListenerRegistration?
}
