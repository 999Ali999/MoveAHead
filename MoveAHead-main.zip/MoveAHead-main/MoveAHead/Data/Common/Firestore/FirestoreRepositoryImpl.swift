//
//  FirestoreRepository.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 09/05/24.
//
// A quick word about mapping document IDs
// https://firebase.google.com/docs/firestore/solutions/swift-codable-data-mapping?hl=en&authuser=0#a_quick_word_about_mapping_document_ids
//
import FirebaseFirestore

class FirestoreRepositoryImpl<T: Codable & Identifiable<String>>: FirestoreRepositoryProtocol {
    public var collectionReference: CollectionReference {
        get {
            return Firestore.firestore().collection(collectionName)
        }
    }
    private var collectionName: String
    
    init(collectionName: String) {
        self.collectionName = collectionName
    }
    
    func addDocument(data: T, completion: @escaping (Error?) -> Void) {
        do {
            let documentId = data.id
            try collectionReference.document(documentId).setData(from: data)
            completion(nil)
        } catch {
            completion(error)
        }
    }
    
    func deleteDocument(withId documentId: String, completion: @escaping (Error?) -> Void) {
        collectionReference.document(documentId).delete { error in
            completion(error)
        }
    }
    
    func updateDocument(withId documentId: String, data: T, completion: @escaping (Error?) -> Void) {
        do {
            try collectionReference.document(documentId).setData(from: data)
            completion(nil)
        } catch {
            completion(error)
        }
    }
    
    func getDocument(withId documentId: String, completion: @escaping (Result<T, Error>) -> Void) {
        collectionReference.document(documentId).getDocument { documentSnapshot, error in
            if let error = error {
                completion(.failure(error))
            } else if let documentSnapshot = documentSnapshot, documentSnapshot.exists {
                do {
                    let data = try documentSnapshot.data(as: T.self)
                    completion(.success(data))
                } catch {
                    completion(.failure(error))
                }
            } else {
                completion(.failure(NSError(domain: "", code: 404, userInfo: nil)))
            }
        }
    }
    
    func getAllDocuments(completion: @escaping (Result<[T], Error>) -> Void) {
        collectionReference.getDocuments { querySnapshot, error in
            if let error = error {
                completion(.failure(error))
            } else {
                do {
                    let documents = try querySnapshot?.documents.compactMap { try $0.data(as: T.self) }
                    completion(.success(documents ?? []))
                } catch {
                    completion(.failure(error))
                }
            }
        }
    }
    
    func getDocuments(where field: String, isEqualTo value: Any, completion: @escaping (Result<[T], Error>) -> Void) {
        collectionReference.whereField(field, isEqualTo: value).getDocuments { querySnapshot, error in
            if let error = error {
                completion(.failure(error))
            } else {
                do {
                    let documents = try querySnapshot?.documents.compactMap { try $0.data(as: T.self) }
                    completion(.success(documents ?? []))
                } catch {
                    completion(.failure(error))
                }
            }
        }
    }
    
    func queryDocuments(byQuery query: Query, completion: @escaping (Result<[T], Error>) -> Void) {
        query.getDocuments { querySnapshot, error in
            if let error = error {
                completion(.failure(error))
            } else {
                do {
                    let documents = try querySnapshot?.documents.compactMap { try $0.data(as: T.self) }
                    completion(.success(documents ?? []))
                } catch {
                    completion(.failure(error))
                }
            }
        }
    }
    
    func observeDocuments(completion: @escaping (Result<[T], Error>) -> Void) -> ListenerRegistration? {
        return collectionReference.addSnapshotListener { querySnapshot, error in
            if let error = error {
                completion(.failure(error))
            } else {
                do {
                    let documents = try querySnapshot?.documents.compactMap { try $0.data(as: T.self) }
                    completion(.success(documents ?? []))
                } catch {
                    completion(.failure(error))
                }
            }
        }
    }
    
    func observeDocuments(byQuery query: Query, completion: @escaping (Result<[T], Error>) -> Void) -> ListenerRegistration? {
        return collectionReference.addSnapshotListener { querySnapshot, error in
            if let error = error {
                completion(.failure(error))
            } else {
                do {
                    let documents = try querySnapshot?.documents.compactMap { try $0.data(as: T.self) }
                    completion(.success(documents ?? []))
                } catch {
                    completion(.failure(error))
                }
            }
        }
    }
}
