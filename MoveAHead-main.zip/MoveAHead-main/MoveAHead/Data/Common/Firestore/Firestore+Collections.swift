//
//  Firestore+Collections.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 20/05/24.
//

import Foundation
import FirebaseFirestore

extension Firestore {
    var songFolders: CollectionReference {
        return self.collection("SongFolders")
    }
}
