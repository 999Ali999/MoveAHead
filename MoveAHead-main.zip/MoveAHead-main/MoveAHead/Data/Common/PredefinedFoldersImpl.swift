//
//  PredefinedFolders.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 25/05/24.
//

import Foundation
import FirebaseFirestore
import FirebaseAuth

final class PredefinedFoldersImpl {
    static var shared = PredefinedFoldersImpl()
    static let localUserUid = "local-user-uid-abcdefghijklm"
    static let allSongsFolderPrefix = "all-songs-"
    static let singlesFolderPrefix = "singles-"
    static let recentlyDeletedFolderPrefix = "recently-deleted-"
    
    var allSongsFolder: SongFolder?
    private let allSongsFolderName = "All Songs"
    
    var singlesFolder: SongFolder?
    private let singlesFolderName = "Singles"
    
    var recentlyDeletedFolder: SongFolder?
    private let recentlyDeletedFolderName = "Recently Deleted"
    
    private let recentlyDeletedFolderIcon = "trash"
    
    private var usersCollection: CollectionReference {
        get {
            Firestore.firestore().collection("users")
        }
    }
    
    private var currentUserUid: String {
        get {
            Auth.auth().currentUser?.uid ?? PredefinedFoldersImpl.localUserUid
        }
    }
    
    private var songFoldersCollection: CollectionReference {
        get {
            usersCollection.document(currentUserUid).collection("songFolders")
        }
    }
    
    private init() { }
    
    func refreshPredefinedFolders() async throws {
        // TODO: _
        do {
            try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
                self.fetchOrAddAllSongsFolder(completion: { (result1: Result<SongFolder, Error>) in
                    do {
                        self.allSongsFolder = try result1.get()
                        self.fetchOrAddSinglesFolder(completion: { (result2: Result<SongFolder, Error>) in
                            do {
                                self.singlesFolder = try result2.get()
                                self.fetchOrAddSRecentlyDeletedFolder(completion: { (result3: Result<SongFolder, Error>) in
                                    do {
                                        self.recentlyDeletedFolder = try result3.get()
                                        continuation.resume(returning: ())
                                    } catch {
                                        continuation.resume(throwing: error)
                                    }
                                })
                            } catch {
                                continuation.resume(throwing: error)
                            }
                        })
                    } catch {
                        continuation.resume(throwing: error)
                    }
                })
            }
        } catch {
            print(error)
        }
    }
    
    func updateUserData(user: FirebaseAuth.User) async throws {
        try await self.usersCollection.document(user.uid).setData(["email": user.email ?? ""])
    }
    
    func fetchOrAddAllSongsFolder(completion: @escaping (Result<SongFolder, Error>) -> Void) {
        fetchOrAddIfNotExistsFolder(folderName: allSongsFolderName, folderPrefix: PredefinedFoldersImpl.allSongsFolderPrefix, completion: completion)
    }
    
    func fetchOrAddSinglesFolder(completion: @escaping (Result<SongFolder, Error>) -> Void) {
        fetchOrAddIfNotExistsFolder(folderName: singlesFolderName, folderPrefix: PredefinedFoldersImpl.singlesFolderPrefix, completion: completion)
    }
    
    func fetchOrAddSRecentlyDeletedFolder(completion: @escaping (Result<SongFolder, Error>) -> Void) {
        fetchOrAddIfNotExistsFolder(folderName: recentlyDeletedFolderName, folderPrefix: PredefinedFoldersImpl.recentlyDeletedFolderPrefix, folderIcon: recentlyDeletedFolderIcon, completion: completion)
    }
    
    private func fetchOrAddIfNotExistsFolder(folderName: String, folderPrefix: String, folderIcon: String? = nil, completion: @escaping (Result<SongFolder, Error>) -> Void) {
        songFoldersCollection.whereField("name", isEqualTo: folderName)
            .getDocuments { querySnapshot, error in
                if let error = error {
                    completion(.failure(error))
                }
                
                let folderSnapshot = querySnapshot?.documents.first
                
                if folderSnapshot == nil {
                    let newFolder = SongFolder(id: "\(folderPrefix)", createdOn: Date.init(timeIntervalSince1970: 0), name: folderName, icon: folderIcon)
                    
                    do {
                        try self.songFoldersCollection.document(newFolder.id).setData(from: newFolder, merge: true)
                        completion(.success(newFolder))
                    } catch {
                        completion(.failure(error))
                    }
                }
                else {
                    do {
                        let newFolder = try folderSnapshot?.data(as: SongFolder.self)
                        completion(.success(newFolder!))
                    } catch {
                        completion(.failure(error))
                    }
                }
            }
    }
}
