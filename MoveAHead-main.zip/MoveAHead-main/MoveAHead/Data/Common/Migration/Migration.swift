//
//  Migration.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 22/06/24.
//

import Foundation
import FirebaseAuth
import FirebaseFirestore

class Migration {
    public static var shared = Migration()
    
    private var exportingFileName = "exporting-song-data.json"
    
    private init() {}
    
    private func exportSongFolder(_ songFolderPrefix: String) async throws -> (SongFolder, [Song]) {
        let userId = PredefinedFoldersImpl.localUserUid
        let userSongFoldersRef = Firestore.firestore().collection("users").document(userId).collection("songFolders")
        let songFolderRef = userSongFoldersRef.document(songFolderPrefix)
        
        var songFolder = try await songFolderRef.getDocument().data(as: SongFolder.self)
        let songFolderItems = try await songFolderRef
            .collection("songs")
            .getDocuments().documents.compactMap { try $0.data(as: SongFolderItem.self) }
        
        songFolder.songs = songFolderItems
        
        var songs: [Song] = []
        
        for songFolderItem in songFolderItems {
            let song = try await Firestore.firestore()
                .collection("songs")
                .document(songFolderItem.id!).getDocument().data(as: Song.self)
            songs.append(song)
        }
        
        return (songFolder, songs)
    }
    
    public func exportDataToLocalCache() async throws {
        let exportingSongData: ExportingSongs = ExportingSongs()
        
        let userId = PredefinedFoldersImpl.localUserUid
        let userSongFoldersRef = try await Firestore.firestore().collection("users").document(userId).collection("songFolders")
            .getDocuments().documents.compactMap { try $0.data(as: SongFolder.self) }
  
        for folder in userSongFoldersRef {
            let songFolderAndSongs = try await exportSongFolder(folder.id)
            exportingSongData.exportingSongs[songFolderAndSongs.0] = songFolderAndSongs.1
        }
    
        let encoder = JSONEncoder()
        let songDataEncoded = try encoder.encode(exportingSongData)
        let filePath = getDocumentsDirectory().appendingPathComponent(self.exportingFileName)
        try songDataEncoded.write(to: filePath)
    }
    
    public func restoreDataFromLocalCacheToCloud(_ userUid: String) async throws {
        let decoder = JSONDecoder()
        let filePath = getDocumentsDirectory().appendingPathComponent(self.exportingFileName)
        let data = try Data(contentsOf: filePath)
        let exportingSongData = try decoder.decode(ExportingSongs.self, from: data)
        
        let firestore = Firestore.firestore()
        let batch = firestore.batch()
        
        let userSongFoldersRef = firestore.collection("users").document(userUid).collection("songFolders")
        let songsRef = firestore.collection("songs")
        
        for songFolder in exportingSongData.exportingSongs.keys {
            let songFolderRef = userSongFoldersRef.document(songFolder.id)
            try batch.setData(from: songFolder, forDocument: songFolderRef, merge: true)
            
            let songFolderSongsRef = songFolderRef.collection("songs")
            for songFolderItem in songFolder.songs ?? [] {
                try batch.setData(from: songFolderItem, forDocument: songFolderSongsRef.document(songFolderItem.id!), merge: true)
            }
            
            let songs = exportingSongData.exportingSongs[songFolder] ?? []
            for song in songs {
                try batch.setData(from: song, forDocument: songsRef.document(song.id), merge: true)
            }
        }
        
        try await batch.commit()
    }
    
    private func getDocumentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return paths[0]
    }
    
    class ExportingSongs: Codable {
        var exportingSongs: [SongFolder: [Song]] = [:]
    }
}
