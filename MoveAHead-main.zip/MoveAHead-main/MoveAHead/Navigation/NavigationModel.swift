//
//  NavigationViewModel.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 02/06/24.
//

import SwiftUI
import Combine

class NavigationModel: ObservableObject {
    @Published var path: [NavigationDestination] = [] {
        didSet {
            saveNavigationPath()
        }
    }
    
    private var cancellables: [AnyCancellable] = []
    private var navigationDataKey = "NavigationPath"
    
    init() {
        $path
            .sink { newValue in
                // TODO: _
            }
            .store(in: &cancellables)
    }
    
    func saveNavigationPath() {
        let encoder = JSONEncoder()
        
        // Filter out paths you do not want to save
        let filteredPath = path.filter { destination in
            switch destination {
            case .songEdit:
                return false
            case .songList:
                return true
            }
        }
        
        if let encoded = try? encoder.encode(filteredPath) {
            UserDefaults.standard.set(encoded, forKey: navigationDataKey)
        }
    }
    
    func restoreNavigationPath() {
        if let savedPathData = UserDefaults.standard.data(forKey: navigationDataKey) {
            let decoder = JSONDecoder()
            if let savedPath = try? decoder.decode([NavigationDestination].self, from: savedPathData) {
                path = savedPath
            }
        }
    }
    
    enum NavigationDestination: Hashable, Codable {
        static func == (lhs: NavigationModel.NavigationDestination, rhs: NavigationModel.NavigationDestination) -> Bool {
            lhs.hashValue == rhs.hashValue
        }
        
        case songList(songFolder: SongFolder)
        case songEdit(songFolderId: String, songFolderItem: SongFolderItem)
    }
}
