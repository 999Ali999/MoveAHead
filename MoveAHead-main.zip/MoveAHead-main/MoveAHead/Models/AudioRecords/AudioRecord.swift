//
//  Item.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 08/05/24.
//

import Foundation

public struct AudioRecord: Identifiable, Codable {
    public var id: String

    init(id: String) {
        self.id = id
    }
}
