//
//  User.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 24/05/24.
//

import Foundation

public struct User: Codable, Identifiable, Hashable {
    public var id: String
    public var email: String?
    public var displayName: String?
    public var isAnonymous: Bool?
}
