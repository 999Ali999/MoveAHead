//
//  Tag.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 20/05/24.
//

import Foundation

public struct Tag {
    var id: String
    var category: String
}

public extension Tag {
    static var predefinedTags: [Tag] = []
}
