//
//  Item.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 08/05/24.
//

import Foundation

// TODO: Implementation
public struct SongChord: Identifiable, Codable {
    public var id: String
    public var name: String
    public var notes: [SongNote] = []
    
    init(id: String, name: String) {
        self.id = id
        self.name = name
    }
}
