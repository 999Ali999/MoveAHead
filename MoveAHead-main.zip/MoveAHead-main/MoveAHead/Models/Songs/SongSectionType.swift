//
//  SongSectionType.swift
//  MoveAHead
//
//  Created by Felix Parey on 16/05/24.
//

import Foundation

public enum SongSectionType: String, Codable, CaseIterable{
    case Intro = "Intro"
    case Verse = "Verse"
    case PreChorus = "Pre-Chorus"
    case Chorus = "Chorus"
    case Bridge = "Bridge"
    case Instrumental = "Instrumental"
    case Outro = "Outro"
}
