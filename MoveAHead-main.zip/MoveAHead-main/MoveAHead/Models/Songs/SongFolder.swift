//
//  Item.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 08/05/24.
//

import Foundation

public struct SongFolder: Codable {
    public var id: String
    public var createdOn: Date
    public var name: String
    public var songs: [SongFolderItem]?
    public var totalSongs: Int?
    public var icon: String?
}

extension SongFolder: Identifiable {
    
}

extension SongFolder: Hashable {
    public func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    public static func == (lhs: SongFolder, rhs: SongFolder) -> Bool {
        return lhs.id == rhs.id
    }
}
