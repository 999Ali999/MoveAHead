//
//  SongNote.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 13/05/24.
//

import Foundation

public struct SongNote: Identifiable, Codable {
    public var id: String
    public var octave: Int
}
