//
//  Item.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 08/05/24.
//

import Foundation

public struct Song: Codable {
    public var id: String
    public var createdOn: Date
    public var name: String
    public var ownerId: String?
    public var description: String? {
        get {
            if songSections.isEmpty {
                return nil
            }
            
            var resultLines: [String] = []
            
            for songSection in songSections {
                resultLines.append(contentsOf: songSection.lyricsText?.components(separatedBy: "\n") ?? [])
                if resultLines.count >= 2 {
                    break
                }
            }
            
            return resultLines.prefix(2).joined(separator: "\n")
        }
    }
    public var songFolderId: String
    public var tags: [String] = []
    public var scale: String?
    public var tempo: Float?
    public var image: String?
    public var songSections: [SongSection] = []
    public var totalLines: Int {
        get {
            songSections.reduce(0) { total, object in
                total + (object.lyricsText?.components(separatedBy: "\n").count ?? 0)
            }
        }
    }

    public var songFolderItem: SongFolderItem {
        SongFolderItem(id: id, createdOn: createdOn, name: name, description: description, tags: tags, totalLines: totalLines)
    }
}

extension Song: Identifiable {
    
}

extension Song: Hashable {
    public func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    public static func == (lhs: Song, rhs: Song) -> Bool {
        return lhs.id == rhs.id
    }
}
