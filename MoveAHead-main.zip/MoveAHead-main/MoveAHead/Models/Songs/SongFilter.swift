//
//  SongFilter.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 04/06/24.
//

import Foundation

public struct SongFilter {
    var searchText: String
    var tags: [String]
}
