//
//  SongFolderItem.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 20/05/24.
//

import Foundation

public struct SongFolderItem: Identifiable, Codable {
    public var id: String?
    public var createdOn: Date?
    public var name: String?
    public var description: String?
    public var tags: [String]?
    public var totalLines: Int?
}

extension SongFolderItem: Hashable {
    
}
