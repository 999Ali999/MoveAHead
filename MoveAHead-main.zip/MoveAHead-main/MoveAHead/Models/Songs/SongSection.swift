//
//  Item.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 08/05/24.
//

import Foundation

public typealias ChordPosition = Int

public struct ChordRelativePosition: Hashable, Codable {
    var textLineNumber: Int
    var textLineHorizontalRelativePosition: Float
    
    public static func == (lhs: Self, rhs: Self) -> Bool {
        return lhs.textLineHorizontalRelativePosition == rhs.textLineHorizontalRelativePosition
        && lhs.textLineNumber == rhs.textLineNumber
    }
}

public struct SongSection: Identifiable, Codable {
    public var id: String
    public var title: String?
    public var lyricsText: String?
    public var chords: [ChordRelativePosition: SongChord]?
}
