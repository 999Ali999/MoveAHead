//
//  Item.swift
//  MoveAHead
//
//  Created by Alexandr Chubutkin on 08/05/24.
//

import Foundation

public struct Album: Identifiable, Codable {
    public var id: String
    public var createdOn: Date
    public var name: String
    
    public init(id: String, createdOn: Date, name: String) {
        self.id = id
        self.createdOn = createdOn
        self.name = name
    }
}

extension Album: Hashable {
    
}
