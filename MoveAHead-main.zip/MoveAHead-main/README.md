# MoveAHead 

### Development 
#### Task or feature description

The branch name should reflect the task or feature you are working on. 

For example, feature/login-screen or bugfix/issue-123.

#### Branch prefixes

Use prefixes to indicate the type of changes. For example:

- **feature/** for new features.
- **bugfix/** for bug fixes.
- **hotfix/** for quick fixes on the production environment.
- **refactor/** for changes that do not affect functionality but improve code structure.
- **test/** for testing-related changes.
- **docs/** for documentation changes.

#### Task identifier

If a task management system is used, add the task identifier to the branch name. For example, feature/issue-123.

Avoid long and complex names: Use short and informative branch names to make it easier to understand and make changes.

Use dashes or underscores: Separate words in the branch name with dashes or underscores for readability. For example, feature/login-screen or bugfix/issue_123.

Avoid special characters: To ensure compatibility with various version control systems and operating systems, avoid using special characters in branch names.

##### Example of a well-named branch:

feature/user-profile

##### Example of a poorly-named branch:

new_feature_for_authentication

Adhering to these rules will help maintain order and structure in the development process and make version control system usage more efficient and convenient. 

#### Possible build issues 

##### Package.resolved file is corrupted or malformed

- In Finder, tap Shift+Cmd+. to reveal hidden files and folders.
- The Package.resolved file is inside your .xcodeproj directory at [appName].xcodeproj/project.xcworkspace/xcshareddata/swiftpm/Package.resolved
- Right click on .xcodeproj and project.xcworkspace to show package contents.
- Move the Package.resolved file to the bin, and then empty the bin.
- Reopen Xcode and open your project again. This gave me another error: the package at '/' cannot be accessed (Couldn’t read '4.5.0':
- In Xcode, File / Packages / Reset package caches. The Swift Package Manager starts working on this.
- Rebuild the project. The error had gone and my project rebuilt successfully.

[Reference Link](https://stackoverflow.com/questions/67185817/package-resolved-file-is-corrupted-or-malformed)

##### Preview screen is crashed 

- Check pass of environment objects (themes etc.)
- After added environment references, need to remove and add again all references in the view to the environment object
